package assignment4;

import java.util.Comparator;

public class PokemonCalcAttackComparator implements Comparator<Pokemon> {
    /**
     * Compares two Pokemon based on their calculated attack value.
     * Returns a negative number if the first has lower attack,
     * zero if they are equal, or a positive number if the first has higher attack.
     * Handles nulls by treating any non-null Pokemon as greater than null.
     *
     * @param p1 the first Pokemon
     * @param p2 the second Pokemon
     * @return negative, zero, or positive based on calcAttack() comparison
     */
    public int compare(Pokemon p1, Pokemon p2) {
        if (p1 == null && p2 == null) return 0;
        if (p1 == null) return -1;
        if (p2 == null) return 1;

        return Integer.compare(p1.calcAttack(), p2.calcAttack());
    }
}
