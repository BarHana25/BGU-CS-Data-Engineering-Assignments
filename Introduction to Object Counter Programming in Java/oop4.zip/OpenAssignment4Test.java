package assignment4;

import org.junit.Test;

import java.util.Comparator;
import java.util.Iterator;

import static org.junit.Assert.*;


public class OpenAssignment4Test {

    @Test(timeout = 2000)
    public void TypeCompareTest_25P() {
        Comparable<Type> fire = new Type("Fire");
        Type water = new Type("Water");
        assertTrue("Fire should be weaker than water", fire.compareTo(water) < 0);
    }


    @Test(timeout = 2000)
    public void PokemonTypeComparatorTest_25P() {
        Pokemon pokemon1 = new Pokemon("Charmander", new Type("Fire"), 50, 40, 40);
        Pokemon pokemon2 = new Pokemon("Squirtle", new Type("Water"), 50, 40, 40);
        Comparator<Pokemon> comparator = new PokemonTypeComparator();
        assertTrue(comparator.compare(pokemon1, pokemon2) < 0);
    }

    @Test(timeout = 2000)
    public void PokemonCalcAttackComparatorTest_25P() {
        Pokemon pokemon1 = new Pokemon("Charmander", new Type("Fire"), 50, 40, 40);
        Pokemon pokemon2 = new SpecialPokemon("Squirtle", new Type("Water"), 50, 40, 40, 20);
        Comparator<Pokemon> comparator = new PokemonCalcAttackComparator();
        assertTrue(comparator.compare(pokemon1, pokemon2) < 0);
    }

    @Test(timeout = 2000)
    public void PokedexIteratorTest_25P() {
        Pokemon pokemon1 = new Pokemon("Charmander", new Type("Fire"), 50, 40, 40);
        Pokedex pokedex = new Pokedex();
        pokedex.addPokemon(pokemon1);
        assertTrue("Pokedex should be iterable", pokedex instanceof Iterable<Pokemon>);
        Iterator<Pokemon> it = pokedex.iterator();
        assertTrue("iterator should have at least one pokemon", it.hasNext());
        assertEquals(it.next(), pokemon1);
        assertFalse("iterator should not have more pokemons", it.hasNext());
    }
}


