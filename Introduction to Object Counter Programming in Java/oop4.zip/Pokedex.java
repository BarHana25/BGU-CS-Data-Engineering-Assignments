package assignment4;

import java.util.HashMap;
import java.util.Iterator;

public class Pokedex implements Iterable<Pokemon> {
    private HashMap<String, Pokemon> pokemons;

    /**
     * Constructs an empty Pokedex.
     */
    public Pokedex(){
        this.pokemons = new HashMap<>();
    }

    /**
     * Constructs a deep copy of another Pokedex.
     * Each Pokemon in the original is cloned and stored under the same name.
     *
     * @param other The Pokedex to copy from.
     */
    public Pokedex(Pokedex other){
        this.pokemons = new HashMap<>();
        for (String name : other.pokemons.keySet()) {
            Pokemon otherPoke = other.pokemons.get(name);
            this.pokemons.put(name, otherPoke.clone());
        }
    }

    /**
     * Retrieves a Pokemon by its name.
     *
     * @param name The name of the Pokemon to retrieve.
     * @return The Pokemon instance stored under that name, or null if not found.
     */
    public Pokemon getByName(String name) {
        return this.pokemons.get(name);
    }

    /**
     * Adds a new Pokemon to the Pokedex.
     * If a Pokemon with the same name already exists, it is overwritten.
     * A deep copy of the Pokemon is stored.
     *
     * @param toAdd The Pokemon to add to the Pokedex.
     */
    public void addPokemon(Pokemon toAdd) {
        if (!this.pokemons.containsKey(toAdd.getName())) {
            this.pokemons.put(toAdd.getName(), toAdd.clone());
        }
    }

    /**
     * Returns an iterator over all the Pokemons in the Pokedex.
     * The order is unspecified.
     *
     * @return an Iterator of Pokemon
     */
    @Override
    public Iterator<Pokemon> iterator() {
        return this.pokemons.values().iterator();
    }

}

