package assignment4;

public class Type implements Comparable<Type> {
    private String type;
    /**
     * Returns the name of the type.
     *
     * @return the type name as a String
     */
    public String getType() {
        return this.type;
    }
    /**
     * Constructor for the Type class.
     * If the input is null, the type is set to "Water" by default.
     * Otherwise, the given value is used.
     *
     * @param type the name of the type
     */
    public Type(String type) {
        if (type == null) {
            this.type = "Water";
        } else {
            this.type = type;}
    }

    /**
     * Compares this Type object to another for equality.
     * Two Type objects are considered equal if their type names match.
     *
     * @param obj The object to compare to.
     * @return true if the other object is a Type with the same type name, false otherwise.
     */
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || !(obj instanceof Type))
            return false;
        Type other = (Type) obj;
        return this.type.equals(other.type);
    }

    /**
     * Compares this Type to another based on elemental strengths.
     * Returns a negative number if this type is weaker,
     * zero if the types are equal or unknown,
     * and a positive number if this type is stronger.
     *
     * @param other the Type to compare to
     * @return negative, zero, or positive depending on type effectiveness
     */
    @Override
    public int compareTo(Type other) {
        String otherType = other.getType();
        String thisType = this.getType();

        if (thisType.equals(otherType)) {
            return 0;
        }
        if (thisType.equals("Fire")) {
            if (otherType.equals("Water")) return -1;
            if (otherType.equals("Grass") || otherType.equals("Electric")) return 1;
        } else if (thisType.equals("Water")) {
            if (otherType.equals("Fire")) return 1;
            if (otherType.equals("Grass") || otherType.equals("Electric")) return -1;
        } else if (thisType.equals("Grass")) {
            if (otherType.equals("Fire")) return -1;
            if (otherType.equals("Electric") || (otherType).equals("Water")) return 1;
        } else if (thisType.equals("Electric")) {
            if (otherType.equals("Water")) return 1;
            if (otherType.equals("Grass") || otherType.equals("Fire")) return -1;
        }
        return 0;

    }
}

