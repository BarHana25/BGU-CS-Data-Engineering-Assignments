
package assignment4;

import org.junit.Test;
import java.util.Comparator;
import java.util.Iterator;
import static org.junit.Assert.*;

public class AdditionalAssignment4Tests {

    @Test(timeout = 2000)
    public void PokemonCloneTest() {
        Pokemon original = new Pokemon("Bulbasaur", new Type("Grass"), 60, 50, 40);
        Pokemon clone = original.clone();
        assertEquals(original, clone);
        assertNotSame(original, clone);
    }

    @Test(timeout = 2000)
    public void PokedexDeepCopyTest() {
        Pokedex original = new Pokedex();
        Pokemon pikachu = new Pokemon("Pikachu", new Type("Electric"), 55, 40, 35);
        original.addPokemon(pikachu);
        Pokedex copy = new Pokedex(original);
        assertNotSame(original.getByName("Pikachu"), copy.getByName("Pikachu"));
        assertEquals(original.getByName("Pikachu"), copy.getByName("Pikachu"));
    }

    @Test(timeout = 2000)
    public void AddDuplicatePokemonToPokedexDoesNothing() {
        Pokedex pokedex = new Pokedex();
        Pokemon p1 = new Pokemon("Eevee", new Type("Normal"), 50, 50, 50);
        Pokemon p2 = new Pokemon("Eevee", new Type("Fire"), 70, 70, 70);
        pokedex.addPokemon(p1);
        pokedex.addPokemon(p2);
        Pokemon result = pokedex.getByName("Eevee");
        assertEquals(p1, result);
    }

    @Test(timeout = 2000)
    public void PokemonSettersCorrectInvalidValues() {
        Pokemon p = new Pokemon(null, null, -10, -5, 0);
        assertEquals("Pikachu", p.getName());
        assertEquals(0, p.getAttack());
        assertEquals(0, p.getDefense());
        assertEquals(1, p.getHealth());
        assertEquals(new Type("Water"), p.getType());
    }

    @Test(timeout = 2000)
    public void TypeCompareNullOrInvalid() {
        Type fire = new Type("Fire");
        Type unknown = new Type("Rock");
        assertEquals(0, fire.compareTo(unknown));
        assertEquals(0, unknown.compareTo(fire));
    }

    @Test(timeout = 2000)
    public void SpecialPokemonCalcAttackTest() {
        SpecialPokemon sp = new SpecialPokemon("Mew", new Type("Psychic"), 10, 10, 10, 5);
        assertEquals(50, sp.calcAttack());
    }

    @Test(timeout = 2000)
    public void SpecialPokemonCloneTest() {
        SpecialPokemon sp = new SpecialPokemon("Zapdos", new Type("Electric"), 10, 10, 10, 5);
        Pokemon clone = sp.clone();
        assertTrue(clone instanceof SpecialPokemon);
        assertEquals(sp, clone);
        assertNotSame(sp, clone);
    }
    @Test(timeout = 2000)
    public void PokedexIterationContainsAllAddedPokemons() {
        Pokedex pokedex = new Pokedex();
        Pokemon p1 = new Pokemon("Charmander", new Type("Fire"), 50, 40, 40);
        Pokemon p2 = new Pokemon("Squirtle", new Type("Water"), 45, 50, 50);
        Pokemon p3 = new Pokemon("Bulbasaur", new Type("Grass"), 49, 49, 45);

        pokedex.addPokemon(p1);
        pokedex.addPokemon(p2);
        pokedex.addPokemon(p3);

        int count = 0;
        boolean found1 = false, found2 = false, found3 = false;
        for (Pokemon p : pokedex) {
            count++;
            if (p.equals(p1)) found1 = true;
            if (p.equals(p2)) found2 = true;
            if (p.equals(p3)) found3 = true;
        }

        assertEquals(3, count);
        assertTrue(found1 && found2 && found3);
    }

}
