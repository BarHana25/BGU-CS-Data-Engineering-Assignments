package assignment4;

public class Main {
    public static void main(String[] args) {
        // Create Types
        Type t1 = new Type("Fire");
        Type t2 = new Type("Water");
        Type t3 = new Type("Grass");
        Type t4 = new Type("Electric");
        Type tUnknown = new Type("Rock");

        // Compare types
        System.out.println(t1.compareTo(t2));
        System.out.println(t2.equals(new Type("Water")));

        // Create regular Pokemon
        Pokemon p1 = new Pokemon("Charmander", t1, 50, 40, 30);
        Pokemon p2 = new Pokemon(p1);
        Pokemon p3 = p1.clone();
        System.out.println(p1.equals(p3));

        // Special Pokemon
        SpecialPokemon sp = new SpecialPokemon("Zapdos", t4, 60, 60, 60, 3);
        System.out.println(sp.calcAttack());

        // Pokedex
        Pokedex pokedex = new Pokedex();
        pokedex.addPokemon(p1);
        pokedex.addPokemon(sp);
        for (Pokemon p : pokedex) {
            System.out.println(p.getName());
        }

        // Pokedex clone
        Pokedex copy = new Pokedex(pokedex);
        System.out.println(copy.getByName("Zapdos").getType().getType());

        // Comparators
        PokemonCalcAttackComparator atkComp = new PokemonCalcAttackComparator();
        PokemonTypeComparator typeComp = new PokemonTypeComparator();
        System.out.println(atkComp.compare(p1, sp));
        System.out.println(typeComp.compare(p1, sp));
    }
}
