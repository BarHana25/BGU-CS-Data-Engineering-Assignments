package assignment4;

public class SpecialPokemon extends assignment4.Pokemon {
    private int specialAttack;

    /**
     * Constructs a SpecialPokemon with all combat attributes, including special attack.
     *
     * @param name          The name of the Pokemon.
     * @param type          The type of the Pokemon.
     * @param attack        The regular attack stat.
     * @param defense       The defense stat.
     * @param health        The health stat.
     * @param specialAttack The special attack stat.
     */
    public SpecialPokemon(String name, Type type, int attack, int defense, int health, int specialAttack) {
        super(name, type, attack, defense, health);
        if (specialAttack < 0) {
            this.specialAttack = 0;
        } else {
            this.specialAttack = specialAttack;
        }
    }

    /**
     * Copy constructor. Creates a deep copy of another SpecialPokemon.
     *
     * @param specialPoke The SpecialPokemon to copy.
     */
    public SpecialPokemon(SpecialPokemon specialPoke) {
        super(specialPoke);
        this.specialAttack = specialPoke.specialAttack;
    }
    /**
     * @return The special attack stat of this SpecialPokemon.
     */
    public int getSpecialAttack() {
        return this.specialAttack;
    }

    /**
     * Calculates a derived attack value based on both the regular and special attack stats.
     *
     * @return The result of specialAttack * attack.
     */
    public int calcAttack() {
        return this.specialAttack * this.getAttack();
    }

    /**
     * Compares this SpecialPokemon to another object for equality.
     * Equality is based on all inherited stats as well as the special attack.
     *
     * @param obj The object to compare to.
     * @return true if obj is a SpecialPokemon with the same attributes, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        return super.equals(obj) &&
                this.specialAttack == ((SpecialPokemon)obj).specialAttack;
    }

    /**
     * Creates and returns a deep copy of this SpecialPokemon.
     *
     * @return A new SpecialPokemon instance with the same values as this one.
     */
    @Override
    public Pokemon clone() {
        return new SpecialPokemon(this);
    }
}
