
package assignment4;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;

public class Assignment4EdgeCaseTests {

    @Test(timeout = 2000)
    public void PokedexEmptyIterationTest() {
        Pokedex pokedex = new Pokedex();
        int count = 0;
        for (Pokemon p : pokedex) {
            count++;
        }
        assertEquals(0, count);
    }

    @Test(timeout = 2000)
    public void PokedexIterationAfterCloneTest() {
        Pokedex original = new Pokedex();
        Pokemon p1 = new Pokemon("Pidgey", new Type("Flying"), 30, 20, 35);
        original.addPokemon(p1);
        Pokedex cloned = new Pokedex(original);

        int count = 0;
        for (Pokemon p : cloned) {
            count++;
            assertEquals(p1, p);
            assertNotSame(p1, p);
        }
        assertEquals(1, count);
    }

    @Test(timeout = 2000)
    public void CalcAttackComparatorZeroAttackTest() {
        Pokemon p1 = new Pokemon("Weakmon", new Type("Grass"), 0, 30, 30);
        SpecialPokemon sp = new SpecialPokemon("Strongmon", new Type("Fire"), 50, 40, 40, 2);
        Comparator<Pokemon> comparator = new PokemonCalcAttackComparator();
        assertTrue(comparator.compare(p1, sp) < 0);
    }

    @Test(timeout = 2000)
    public void CalcAttackComparatorSpecialZeroTest() {
        Pokemon p1 = new Pokemon("Regular", new Type("Water"), 50, 40, 40);
        SpecialPokemon sp = new SpecialPokemon("Special", new Type("Electric"), 50, 40, 40, 0);
        Comparator<Pokemon> comparator = new PokemonCalcAttackComparator();
        assertTrue(comparator.compare(p1, sp) > 0);
    }

    @Test(timeout = 2000)
    public void TypeComparatorUnknownTypeTest() {
        Pokemon p1 = new Pokemon("Rocky", new Type("Rock"), 40, 40, 40);
        Pokemon p2 = new Pokemon("Normal", new Type("Normal"), 40, 40, 40);
        Comparator<Pokemon> comparator = new PokemonTypeComparator();
        assertEquals(0, comparator.compare(p1, p2));
    }

    @Test(timeout = 2000)
    public void TypeComparatorSameTypeTest() {
        Pokemon p1 = new Pokemon("Firemon1", new Type("Fire"), 60, 50, 40);
        Pokemon p2 = new Pokemon("Firemon2", new Type("Fire"), 60, 50, 40);
        Comparator<Pokemon> comparator = new PokemonTypeComparator();
        assertEquals(0, comparator.compare(p1, p2));
    }

    @Test(timeout = 2000)
    public void TypeCompareWithUnknownShouldReturnZero() {
        Type known = new Type("Fire");
        Type unknown = new Type("Rock");
        assertEquals(0, known.compareTo(unknown));
        assertEquals(0, unknown.compareTo(known));
    }
}
