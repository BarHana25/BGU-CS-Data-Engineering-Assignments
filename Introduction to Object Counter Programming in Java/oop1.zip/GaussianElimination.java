package assignment1;

public class GaussianElimination {

    public static void gaussianElimination(double[][] matrix) {
        /**
         * Performs Gaussian elimination on a given matrix.
         * The method modifies the matrix in-place to reduce it to row echelon form.
         * the input matrix is changed.
         *
         * @param matrix The matrix to be reduced
         */
        // Check if the matrix itself is null
        if (matrix == null) {
            System.out.println("Matrix is null");
            return;
        }
        int h = 0; //Initialization of the pivot row
        int k = 0; //Initialization of the pivot column
        int m = matrix.length;
        int n = matrix[0].length;
        // Check that no row is null and all rows have the same length
        for (int i = 0; i < m; i++) {
            if (matrix[i] == null) {
                System.out.println("Row " + i + " is null");
                return;
            }
            if (matrix[i].length != n) {
                System.out.println("Row " + i + " has inconsistent length");
                return;
            }
        }
        while (h < m && k < n) {
            int i_max = h;
            for (int i = h + 1; i < m; i++) {
                if (Math.abs(matrix[i][k]) > Math.abs(matrix[i_max][k])) {
                    i_max = i;
                }
            }
            if (matrix[i_max][k] == 0.0) {
                //No pivot in this column, pass to next column
                k = k+1;
            } else {
                swapRows(matrix, h ,i_max);
                // Do for all rows below pivot:
                for (int i = h+1; i < m; i++) {
                    double f = matrix[i][k]/matrix[h][k];
                    //Fill with zeros the lower part of pivot column
                    matrix[i][k] = 0.0;
                    //Do for all remaining elements in current row
                    for (int j = k+1; j < n; j++) {
                        matrix[i][j] = matrix[i][j] - f * matrix[h][j];
                    }
                }
                //Increase pivot row and column
                h = h + 1;
                k = k + 1;
            }
        }
    }

    public static void swapRows(double[][] matrix, int i, int j) {
        /**
         * Swaps two rows in a given matrix.
         *
         * @param matrix The matrix in which rows will be swapped
         * @param i The index of the first row
         * @param j The index of the second row
         */
        double[] temp = matrix[i];
        matrix[i] = matrix[j];
        matrix[j] = temp;
    }
}
