package assignment1;

public class ChessThreat {
/**
 * Checks if a chess piece of a given type is threatening a target square.
 *
 * @param type The type of the piece: 1 for bishop, 2 for rook, 3 for knight
 * @param x1 The row of the piece's current position
 * @param y1 The column of the piece's current position
 * @param x2 The row of the target square
 * @param y2 The column of the target square
 * @return true if the piece on square (x1, y1) threatens the square (x2, y2), false otherwise
*/
    public static boolean CheckThreats(int type, int x1, int y1, int x2, int y2) {

            int dx = Math.abs(x1 - x2);
            int dy = Math.abs(y1 - y2);
            // bishop
            if (type == 1 && dx == dy) {
                return true;
            }
            //rook
            if (type == 2 && (x1 == x2 || y1 == y2)) {
                return true;
            }
            //knight
            if (type == 3 && ((dx == 2 && dy == 1) || (dx == 1 && dy == 2))) {
                return true;
            }
            //otherwise
            return false;
        }
}
