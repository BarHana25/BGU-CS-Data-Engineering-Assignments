package pokemon;

import java.io.Serializable;

public class Pokemon implements  Serializable{
    private String name;
    private int attack;
    private int defense;
    private int health;
    private Type type;

    /**
     * Default constructor.
     * Initializes the Pokemon as Magikarp with default values.
     */
    public Pokemon() {
        this.name = "Magikarp";
        this.attack = 10;
        this.defense = 55;
        this.health = 20;
        this.type = new Type("Water");
    }
    /**
     * Sets the name of the Pokemon.
     * If the name is null, a PokemonException is thrown.
     *
     * @param name the name to set
     * @throws PokemonException if the name is null
     */

    public void setName(String name) throws PokemonException {
        if ( name == null) {
            throw new PokemonException("bad name: Empty", true);
        } else {this.name = name;
        }
    }

    /**
     * Returns the name of the Pokemon.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the attack value.
     * If the value is negative, a PokemonException is thrown.
     *
     * @param attack the attack value
     * @throws PokemonException if the value is negative
     */
    public void setAttack(int attack) throws PokemonException {
        if (attack < 0) {
            throw new PokemonException(attack);
        } else {
            this.attack = attack;
        }
    }

    /**
     * Returns the attack value.
     *
     * @return the attack
     */
    public int getAttack() {
        return this.attack;
    }

    /**
     * Sets the defense value.
     * If the value is negative, a PokemonException is thrown.
     *
     * @param defense the defense value
     * @throws PokemonException if the defense is negative
     */
    public void setDefense(int defense) throws PokemonException {
        if (defense < 0) {
            throw new PokemonException(defense);
        } else {
            this.defense = defense;
        }
    }

    /**
     * Returns the defense value.
     *
     * @return the defense
     */
    public int getDefense() {
        return this.defense;
    }
    /**
     * Sets the health value.
     * If the value is less than 1, a PokemonException is thrown.
     *
     * @param health the health value
     * @throws PokemonException if the health is less than 1
     */
    public void setHealth(int health) throws PokemonException {
        if (health < 1) {
            throw new PokemonException(health);
        } else {
            this.health = health;
        }
    }

    /**
     * Returns the health value.
     *
     * @return the health
     */
    public int getHealth() {
        return this.health;
    }
    /**
     * Sets the Pokemon's type.
     * If the input is null, sets to new Type("Water").
     * Otherwise, sets a deep copy of the provided Type.
     *
     * @param type the Type to set
     */
    public void setType(Type type) {
        if (type == null) {
            this.type = new Type("Water");
        } else {
            this.type = new Type(type.getType());
        }
    }

    /**
     * Returns a copy of the Pokemon's Type.
     *
     * @return the Type (deep copy)
     */
    public Type getType() {
        return new Type(this.type.getType());
    }

    /**
     * Full constructor.
     * Initializes all fields using setter methods.
     *
     * @param name the name
     * @param type the type
     * @param attack the attack value
     * @param defense the defense value
     * @param health the health value
     * @throws PokemonException if any of the parameters are invalid
     */
    public Pokemon(String name, Type type, int attack, int defense, int health) throws PokemonException {
        setName(name);
        setAttack(attack);
        setDefense(defense);
        setHealth(health);
        setType(type);
    }

    /**
     * Copy constructor.
     * Creates a deep copy of another Pokemon.
     *
     * @param other the Pokemon to copy
     * @throws PokemonException if the copied values are invalid
     */
    public Pokemon(Pokemon other) throws PokemonException{
        setName(other.getName());
        setAttack(other.getAttack());
        setDefense(other.getDefense());
        setHealth(other.getHealth());
        setType(new Type(other.getType().getType()));
    }
    /**
     * Returns the current attack value.
     * This method may be extended in the future.
     *
     * @return the attack value
     */
    public int calcAttack() {
        return this.attack;
    }

    /**
     * Checks if this Pokemon is equal to another object.
     * Equality is based on name, type, attack, defense, and health.
     *
     * @param obj The object to compare to.
     * @return true if obj is a Pokemon with the same attributes, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Pokemon other = (Pokemon) obj;
        return this.getName().equals(other.getName()) &&
                this.getType().equals(other.getType()) &&
                this.getAttack() == other.getAttack() &&
                this.getDefense() == other.getDefense() &&
                this.getHealth() == other.getHealth();
    }

    /**
     * Creates and returns a deep copy of this Pokemon.
     * <p>
     * This method uses the copy constructor to ensure that
     * all fields are duplicated properly, including complex objects.
     *
     * @return A new Pokemon instance with the same values as this one.
     */
    @Override
    public Pokemon clone()  {
        try {
            return new Pokemon(this);
        } catch (PokemonException e) {
            throw new RuntimeException("Cloning failed: " + e.getMessage(), e);
        }
    }

}
