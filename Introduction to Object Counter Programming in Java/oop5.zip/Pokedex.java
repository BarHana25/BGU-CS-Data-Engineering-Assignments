package pokemon;

import java.util.HashMap;
import java.util.Iterator;
import java.io.Serializable;

public class Pokedex implements Iterable<Pokemon>, Serializable {
    private HashMap<String, Pokemon> pokemons;

    /**
     * Constructs an empty Pokedex.
     */
    public Pokedex(){
        this.pokemons = new HashMap<>();
    }

    /**
     * Constructs a deep copy of another Pokedex.
     * Each Pokemon in the original is cloned and stored under the same name.
     *
     * @param other The Pokedex to copy from.
     */
    public Pokedex(Pokedex other){
        this.pokemons = new HashMap<>();
        for (String name : other.pokemons.keySet()) {
            Pokemon otherPoke = other.pokemons.get(name);
            this.pokemons.put(name, otherPoke.clone());
        }
    }

    /**
     * Retrieves a Pokemon by its name.
     *
     * @param name The name of the Pokemon to retrieve.
     * @return The Pokemon instance stored under that name, or null if not found.
     */
    public Pokemon getByName(String name) throws PokemonException {
        if (!this.pokemons.containsKey(name)) {
            throw new PokemonException(name);
        }
        return this.pokemons.get(name);    }

    /**
     * Adds a new Pokemon to the Pokedex.
     * The Pokemon is stored under its name as a deep copy.
     * If a Pokemon with the same name already exists in the Pokedex,
     * a PokemonException is thrown to prevent duplicates.
     *
     * @param toAdd The Pokemon to add to the Pokedex.
     * @throws PokemonException If a Pokemon with the same name already exists.
     */
    public void addPokemon(Pokemon toAdd) throws PokemonException {
        if (this.pokemons.containsKey(toAdd.getName())) {
            throw new PokemonException(toAdd.getName());
        }
        this.pokemons.put(toAdd.getName(), toAdd.clone());
    }

    /**
     * Returns an iterator over all the Pokemons in the Pokedex.
     * The order is unspecified.
     *
     * @return an Iterator of Pokemon
     */
    @Override
    public Iterator<Pokemon> iterator() {
        return this.pokemons.values().iterator();
    }

}

