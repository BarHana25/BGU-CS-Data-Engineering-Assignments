package pokemon;

import org.junit.Assert;
import org.junit.Test;

import java.io.*;

import static junit.framework.TestCase.*;

public class OpenAssignment5Test {
    SpecialPokemon GetCharizard() {
        try {
            return new SpecialPokemon("Charizard", new Type("Fire"), 20, 30, 40, 50);
        } catch (PokemonException ignored) {
        }
        return null;
    }

    @Test(timeout = 2000)
    public void PokemonErrorNameExceptioninCtrTest_20P() {
        boolean eThrow = false;
        try {
            new Pokemon(null, new Type("Water"), 20, 30, 40);
        } catch (PokemonException e) {
            assertEquals("Problem with PokemonException", "bad name: Empty", e.getMessage());
            eThrow = true;
        }
        if (!eThrow) {
            Assert.fail("No exception was thrown");
        }
    }

    @Test(timeout = 2000)
    public void PokemonErrorNameExceptionInPokedexTest_20P() {
        boolean eThrow = false;
        Pokedex pokedex = new Pokedex();
        try {
            pokedex.getByName("Charmander");
        } catch (PokemonException e) {
            assertEquals("Problem with PokemonException", "bad name: Charmander", e.getMessage());
            eThrow = true;
        }
        if (!eThrow) {
            Assert.fail("No exception was thrown");
        }
    }

    @Test(timeout = 2000)
    public void PokemonErrorIntegerExceptionTest_15P() {
        boolean eThrow = false;
        try {
            new Pokemon("Pikachu", new Type("Electric"), -1, 10, 10);
        } catch (PokemonException e) {
            assertEquals("Problem with PokemonException", "bad parameter: -1", e.getMessage());
            eThrow = true;
        }
        if (!eThrow) {
            Assert.fail("No exception was thrown");
        }
    }

    @Test(timeout = 2000)
    public void SaveToTextFileTest_15P() throws PokemonException {
        SpecialPokemon charizard = GetCharizard();
        File testTxt = new File("charizard.text");
        charizard.saveToFile(testTxt);
        Assert.assertTrue("error on saveToTextfile", testTxt.exists());
    }

    @Test(timeout = 2000)
    public void ReadFromTextFileTest_15P() throws PokemonException {
        File testTxt = new File("C:\\Users\\yehez\\Desktop\\BGU\\סמסטר ב\\מונחה עצמים\\projects\\asingment5\\test.txt");
        SpecialPokemon pokemon = new SpecialPokemon(testTxt);
        Assert.assertEquals("reading did not work", GetCharizard(), pokemon);
    }

    @Test(timeout = 2000)
    public void SerializePokedexTest_15P() {
        Pokedex pokedex = new Pokedex();
        Pokedex pokedex2 = null;
        try {
            pokedex.addPokemon(GetCharizard());
        } catch (PokemonException e) {
            Assert.fail("Should not fail adding a pokemon");
        }
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("test.ser"))) {
            out.writeObject(pokedex);
        } catch (IOException e) {
            Assert.fail("File writing failed - Are you sure everything that needs to be Serializable is?");
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("test.ser"))) {
            pokedex2 = (Pokedex) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            Assert.fail("File reading failed");
        }
        Pokemon pokemon = null;
        try {
            pokemon = pokedex2.getByName("Charizard");
        } catch (PokemonException e) {
            Assert.fail("Charizard should be in read Pokedex");
        }

        Assert.assertEquals("reading did not work", GetCharizard(), pokemon);
    }
}
