package pokemon;


import java.util.Comparator;

public class PokemonTypeComparator implements Comparator<Pokemon> {
    /**
     * Compares two Pokemon based on the effectiveness of their types.
     * Returns a negative number if the first type is weaker,
     * zero if the types are equal or unknown,
     * and a positive number if the first type is stronger.
     * Handles nulls by treating any non-null Pokemon as greater than null.
     *
     * @param p1 the first Pokemon
     * @param p2 the second Pokemon
     * @return negative, zero, or positive depending on type comparison
     */
    public int compare( Pokemon p1, Pokemon p2 ) {
        if ( p1 == null && p2 ==null)
            return 0;
        if (p1 == null)
            return -1;
        if (p2 == null)
            return 1;
        return p1.getType().compareTo(p2.getType());
    }

}

