package pokemon;

public class PokemonException extends Exception {
    public PokemonException(String pokemonName) {
        super("bad name: " + pokemonName);
    }

    public PokemonException(int parameter) {
        super("bad parameter: " + parameter);
    }
    /**
     * Constructs an exception with a custom message.
     * Use this if you want to pass the full message directly ("bad name: Empty").
     *
     * @param message the full message
     * @param useRaw   parameter used only to differentiate the constructor
     */
    public PokemonException(String message, boolean useRaw) {
        super(message);
    }
}

