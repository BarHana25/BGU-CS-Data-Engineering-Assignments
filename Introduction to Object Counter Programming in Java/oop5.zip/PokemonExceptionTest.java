package pokemon;

import org.junit.Test;
import static org.junit.Assert.*;

public class PokemonExceptionTest {

    @Test
    public void testNameConstructor() {
        PokemonException ex = new PokemonException("Pikachu");
        assertEquals("bad name: Pikachu", ex.getMessage());
    }

    @Test
    public void testParameterConstructor() {
        PokemonException ex = new PokemonException(-42);
        assertEquals("bad parameter: -42", ex.getMessage());
    }

    @Test
    public void testCustomMessageConstructor() {
        PokemonException ex = new PokemonException("bad name: Empty", true);
        assertEquals("bad name: Empty", ex.getMessage());
    }
}
