package pokemon;

import java.util.HashMap;
import java.util.Iterator;
import java.io.Serializable;

public class Pokedex implements Iterable<Pokemon>, Serializable {
    private HashMap<String, Pokemon> pokemons;
    private MyForest<Pokemon> evolutions;

    /**
     * Constructs an empty Pokedex.
     */
    public Pokedex(){
        this.pokemons = new HashMap<>();
        this.evolutions = new MyForest<>();
    }
    /**
     * Constructs a deep copy of another Pokedex.
     * Each Pokemon is cloned and added to a new evolution forest,
     * preserving parent-child evolution relationships.
     *
     * @param other The Pokedex to copy from.
     */
    public Pokedex(Pokedex other) {
        this.pokemons = new HashMap<>();
        for (String name : other.pokemons.keySet()) {
            Pokemon otherPoke = other.pokemons.get(name);
            this.pokemons.put(name, otherPoke.clone());
        }
        this.evolutions = new MyForest<>();
        // Reconstruct evolution tree using only cloned pokemons
        for (Pokemon p : this.pokemons.values()) {
            Pokemon otherPoke = this.pokemons.get(p.getName());
            boolean foundParent = false;
            for (Pokemon possibleParent : other.pokemons.values()) {
                if (other.evolutions.areRelated(possibleParent, p)
                        && other.evolutions.getTree(possibleParent).isPredecessorOf(possibleParent, p)) {
                    Pokemon parent = this.pokemons.get(possibleParent.getName());
                    evolutions.add(parent, otherPoke);
                    foundParent = true;
                    break;
                }
            }
            if (!foundParent) {
                evolutions.add(otherPoke); // Add as a new tree root
            }
        }
    }
    /**
     * Retrieves a Pokemon by its name.
     *
     * @param name The name of the Pokemon to retrieve.
     * @return The Pokemon instance stored under that name.
     * @throws PokemonException If no Pokemon with that name exists.
     */
    public Pokemon getByName(String name) throws PokemonException {
        if (!this.pokemons.containsKey(name)) {
            throw new PokemonException(name);
        }
        return this.pokemons.get(name);    }

    /**
     * Adds a new Pokemon to the Pokedex as a root in the evolution tree.
     * The Pokemon is stored under its name as a deep copy.
     * If a Pokemon with the same name already exists in the Pokedex,
     * a PokemonException is thrown to prevent duplicates.
     *
     * @param toAdd The Pokemon to add to the Pokedex.
     * @throws PokemonException If the Pokemon is null or already exists in the Pokedex.
     */
    public void addPokemon(Pokemon toAdd) throws PokemonException {
        addPokemon(toAdd, null); // using the general version
    }

    /**
     * Returns an iterator over all the Pokemons in the Pokedex.
     * The order is unspecified.
     *
     * @return an Iterator of Pokemon
     */
    @Override
    public Iterator<Pokemon> iterator() {
        return this.pokemons.values().iterator();
    }
    /**
     * Adds a new Pokemon to the Pokedex and connects it in the evolution tree.
     * The Pokemon is stored under its name as a deep copy.
     * If  parent is null, the Pokemon is added as a root.
     * If parent is specified but not found in the Pokedex, the Pokemon is not linked in the evolution tree.
     * @param toAdd  The Pokemon to add to the Pokedex.
     * @param parent The name of the parent Pokemon to connect to in the evolution tree, or null to add as root.
     * @throws PokemonException If the Pokemon is null or already exists in the Pokedex.
     */
    public void addPokemon(Pokemon toAdd, String parent) throws PokemonException {
        // add to dictionary
        if (toAdd == null) {
            throw new PokemonException("null");
        }
        if (this.pokemons.containsKey(toAdd.getName())) {
            throw new PokemonException(toAdd.getName());
        }
        this.pokemons.put(toAdd.getName(), toAdd.clone());
        // add to tree
        if (parent == null) {
            this.evolutions.add(toAdd); // add as root
        } else {
            Pokemon pPoke = this.pokemons.get(parent);
            if (pPoke == null) {
                evolutions.add(pPoke, toAdd);// if parent exists, connect
            }
        }
    }
    /**
     * Returns a tree of names representing the evolution tree that starts from a given Pokemon name.
     * Converts the full tree of Pokemon objects into a tree of names.
     *
     * @param name the name of the root Pokemon
     * @return a MyTree<String> representing the evolution tree by name, or null if not found
     */
    public MyTree<String> getEvolutionTreeByName(String name){
        Pokemon rootPoke = this.pokemons.get(name);
        if (rootPoke == null) {
            return null;
        }
        MyTree<Pokemon> originalTree = evolutions.getTree(rootPoke);
        if (originalTree == null) {
            return null;
        }
        MyTree<String> strTree = new MyTree<>(name);
        copySubtreeNames(rootPoke, name, originalTree, strTree);
        return strTree;
    }
    /**
     * Recursively copies an evolution subtree from a Pokemon tree into a String tree.
     * @param curr       the current Pokemon node being visited
     * @param currName   the name of the current node
     * @param originalTree the original tree of Pokemon objects
     * @param strTree    the new tree that stores only names
     */
    private void copySubtreeNames(Pokemon curr, String currName,MyTree<Pokemon> originalTree, MyTree<String> strTree) {
        for (Pokemon child : originalTree.getChildren(curr)) {
            String childName = child.getName();
            strTree.add(currName, childName);
            copySubtreeNames(child, currName, originalTree, strTree);
        }
    }
}

