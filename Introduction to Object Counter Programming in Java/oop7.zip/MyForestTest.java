package pokemon;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.io.Serializable;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.Assert.*;

public class MyForestTest {
    MyForest<String> forest;

    @Before
    public void setUp() {
        forest = new MyForest<>();
    }


    @Test
    public void testAddRoot() {
        assertTrue(forest.add("A"));
        assertTrue(forest.exists("A"));
    }

    @Test
    public void testAddChild() {
        forest.add("A");
        assertTrue(forest.add("A", "B"));
        assertTrue(forest.exists("B"));
    }

    @Test
    public void testAddNonexistentParent() {
        assertFalse(forest.add("X", "Y"));
    }

    @Test
    public void testRemoveLeaf() {
        forest.add("R");
        forest.add("R", "C");
        assertTrue(forest.remove("C"));
        assertFalse(forest.exists("C"));
    }

    @Test
    public void testRemoveRoot() {
        forest.add("R");
        assertTrue(forest.remove("R"));
        assertFalse(forest.exists("R"));
    }

    @Test
    public void testRemoveNonexistent() {
        assertFalse(forest.remove("Z"));
    }

    @Test
    public void testAreRelated() {
        forest.add("A");
        forest.add("A", "B");
        assertTrue(forest.areRelated("A", "B"));
        assertTrue(forest.areRelated("B", "A"));
        assertFalse(forest.areRelated("A", "C"));
    }

    @Test
    public void testGetTree() {
        forest.add("Root");
        MyTree<String> t = forest.getTree("Root");
        assertNotNull(t);
        assertEquals("Root", t.getData());
        assertNull(forest.getTree("Nope"));
    }

    // from original test
    @Test
    public void forestAddRootTest_13P() {
        MyForest<String> forest = new MyForest<>();
        assertTrue(forest.add("Pikachu"));
    }

    @Test
    public void forestAddChildTest_13P() {
        MyForest<String> forest = new MyForest<>();
        assertTrue(forest.add("Pikachu"));
        assertTrue(forest.add("Pikachu", "Raichu"));
    }

    @Test
    public void forestRemoveTest_13P() {
        MyForest<String> forest = new MyForest<>();
        forest.add("Bulbasaur");
        forest.remove("Bulbasaur");
        assertFalse(forest.exists("Bulbasaur"));
    }

    @Test
    public void forestRelatedTest_13P() {
        MyForest<String> forest = new MyForest<>();
        forest.add("Charmander");
        forest.add("Charmander", "Charmeleon");
        forest.areRelated("Charmander", "Charmeleon");
    }

    @Test
    public void forestExistsTest_12P() {
        MyForest<String> forest = new MyForest<>();
        forest.add("Squirtle");
        assertFalse(forest.exists("Blastoise"));
    }

    @Test
    public void forestGetTreeTest_12P() {
        MyForest<String> forest = new MyForest<>();
        forest.add("Eevee");
        MyTree<String> tree = forest.getTree("Eevee");
        assertNotNull(tree);
    }
}

