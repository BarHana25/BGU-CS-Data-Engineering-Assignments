
package pokemon;

import org.junit.Assert;
import org.junit.Test;

import java.io.*;

import static org.junit.Assert.*;

public class CustomDebugTests {

    @Test(timeout = 2000)
    public void testPokedexSerialization() {
        Pokedex pokedex = new Pokedex();
        try {
            pokedex.addPokemon(new Pokemon("Testmon", new Type("Normal"), 10, 10, 10));
            FileOutputStream fileOut = new FileOutputStream("pokedex.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(pokedex);
            out.close();
            fileOut.close();
            assertTrue(true); // passed
        } catch (IOException e) {
            fail("Serialization failed: " + e.getMessage());
        } catch (PokemonException e) {
            fail("PokemonException should not be thrown.");
        }
    }

    @Test(timeout = 2000)
    public void testCharizardEvolutionTreeAppears() {
        Pokedex pokedex = new Pokedex();
        try {
            SpecialPokemon charizard = new SpecialPokemon("Charizard", new Type("Fire"), 20, 30, 40, 50);
            pokedex.addPokemon(charizard); // use version without parent
        } catch (PokemonException e) {
            fail("Should not throw PokemonException");
        }

        MyTree<String> tree = pokedex.getEvolutionTreeByName("Charizard");

        assertNotNull("Expected tree for Charizard but got null", tree);
        assertEquals("Charizard", tree.getData());
    }
}
