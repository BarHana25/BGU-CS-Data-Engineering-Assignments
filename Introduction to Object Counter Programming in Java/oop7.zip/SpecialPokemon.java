package pokemon;


import java.io.*;


public class SpecialPokemon extends pokemon.Pokemon implements Serializable {
    private int specialAttack;

    /**
     * Constructs a SpecialPokemon with all combat attributes, including special attack.
     *
     * @param name          The name of the Pokemon.
     * @param type          The type of the Pokemon.
     * @param attack        The regular attack stat.
     * @param defense       The defense stat.
     * @param health        The health stat.
     * @param specialAttack The special attack stat.
     */
    public SpecialPokemon(String name, Type type, int attack, int defense, int health, int specialAttack) throws PokemonException {
        super(name, type, attack, defense, health);
        if (specialAttack < 0) {
            throw new PokemonException(specialAttack);
        } else {
            this.specialAttack = specialAttack;
        }
    }

    /**
     * Copy constructor. Creates a deep copy of another SpecialPokemon.
     *
     * @param specialPoke The SpecialPokemon to copy.
     */
    public SpecialPokemon(SpecialPokemon specialPoke) throws PokemonException {
        super(specialPoke);
        this.specialAttack = specialPoke.specialAttack;
    }
    /**
     * @return The special attack stat of this SpecialPokemon.
     */
    public int getSpecialAttack() {
        return this.specialAttack;
    }

    /**
     * Calculates a derived attack value based on both the regular and special attack stats.
     *
     * @return The result of specialAttack * attack.
     */
    public int calcAttack() {
        return this.specialAttack * this.getAttack();
    }

    /**
     * Compares this SpecialPokemon to another object for equality.
     * Equality is based on all inherited stats as well as the special attack.
     *
     * @param obj The object to compare to.
     * @return true if obj is a SpecialPokemon with the same attributes, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        return super.equals(obj) &&
                this.specialAttack == ((SpecialPokemon)obj).specialAttack;
    }

    /**
     * Creates and returns a deep copy of this SpecialPokemon.
     *
     * @return A new SpecialPokemon instance with the same values as this one.
     */
    @Override
    public Pokemon clone() {
        try {
            return new SpecialPokemon(this);
        } catch (PokemonException e) {
            throw new RuntimeException("Cloning failed: " + e.getMessage(), e);
        }
    }
    /**
     * Saves this SpecialPokemon's attributes to a text file.
     * The file will contain each attribute on a separate line in the following format:
     * Name: <name>
     * Type: <type>
     * Attack: <attack>
     * Defense: <defense>
     * Health: <health>
     * Special Attack: <specialAttack>
     *
     * @param file The file to which the data should be saved.
     */
    public void saveToFile(File file) {
        try (PrintWriter writer = new PrintWriter(file)) {
            //fix assignment 5:not  written according to format expected
            writer.println("<Name:" + this.getName() +
                    "Type:" + this.getType() +
                    "Attack:" + this.getAttack() +
                    "Defense:" + this.getDefense() +
                    "Health:" + this.getHealth() +
                    "SpecialAttack:|" + this.getSpecialAttack() + ">");
        } catch (FileNotFoundException e) {
            System.err.println("error on saveToTextfile: " + e.getMessage());
        }
    }
    /**
     * Constructs a SpecialPokemon by reading its data from a formatted text file.
     * The file must contain exactly six lines with labels and values in the following order:
     * Name: <name>
     * Type: <type>
     * Attack: <attack>
     * Defense: <defense>
     * Health: <health>
     * Special Attack: <specialAttack>
     *
     * @param file The text file containing the SpecialPokemon's data.
     * @throws PokemonException If any value is invalid or missing.
     * @throws RuntimeException If an I/O error occurs while reading the file.
     */
    public SpecialPokemon(File file) throws PokemonException {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            // Read each line in order, matching the structure saved by saveToFile
            String name = reader.readLine().split(": ")[1];
            String typeStr = reader.readLine().split(": ")[1];
            int attack = Integer.parseInt(reader.readLine().split(": ")[1]);
            int defense = Integer.parseInt(reader.readLine().split(": ")[1]);
            int health = Integer.parseInt(reader.readLine().split(": ")[1]);
            int specialAttack = Integer.parseInt(reader.readLine().split(": ")[1]);
            // Check values according to constructor rules
            if (name == null) {
                throw new PokemonException("bad name: Empty", true);
            }
            if (attack < 0) throw new PokemonException(attack);
            if (defense < 0) throw new PokemonException(defense);
            if (health < 1) throw new PokemonException(health);
            if (specialAttack < 0) throw new PokemonException(specialAttack);
            // Initialize the object using setters
            this.setName(name);
            this.setType(new Type(typeStr));
            this.setAttack(attack);
            this.setDefense(defense);
            this.setHealth(health);
            this.specialAttack = specialAttack;

        }catch (IOException e) {
            // Convert checked IOException to unchecked RuntimeException
            throw new RuntimeException("File reading failed", e);
        }

    }


}
