package pokemon;

import org.junit.Test;
import static org.junit.Assert.*;

public class TestsForA6 {

    @Test
    public void testChildDirectlyUnderRoot() {
        MyTree<String> tree = new MyTree<>("root");
        tree.add("root", "child");
        assertTrue(tree.isSuccessorOf("child", "root"));
    }

    @Test
    public void testChildDeeperDescendant() {
        MyTree<String> tree = new MyTree<>("root");
        tree.add("root", "mid");
        tree.add("mid", "child");
        assertTrue(tree.isSuccessorOf("child", "root"));
    }

    @Test
    public void testChildNotInTree() {
        MyTree<String> tree = new MyTree<>("root");
        tree.add("root", "child1");
        assertFalse(tree.isSuccessorOf("ghost", "root"));
    }

    @Test
    public void testParentNotInTree() {
        MyTree<String> tree = new MyTree<>("root");
        tree.add("root", "child1");
        assertFalse(tree.isSuccessorOf("child1", "ghost"));
    }

    @Test
    public void testChildNotADescendant() {
        MyTree<String> tree = new MyTree<>("root");
        tree.add("root", "child1");
        tree.add("root", "child2");
        assertFalse(tree.isSuccessorOf("child1", "child2"));
    }

    @Test
    public void testAddAndExists() {
        MyTree<String> tree = new MyTree<>("root");
        assertTrue(tree.add("root", "a"));
        assertTrue(tree.add("a", "b"));
        assertTrue(tree.exists("b"));
        assertFalse(tree.exists("x"));
    }

    @Test
    public void testRemoveLeafNode() {
        MyTree<String> tree = new MyTree<>("root");
        tree.add("root", "a");
        assertTrue(tree.remove("a"));
        assertFalse(tree.exists("a"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveRootThrowsException() {
        MyTree<String> tree = new MyTree<>("root");
        tree.remove("root");
    }

    @Test
    public void testSizeCalculation() {
        MyTree<String> tree = new MyTree<>("root");
        tree.add("root", "a");
        tree.add("a", "b");
        tree.add("a", "c");
        assertEquals(4, tree.size());
    }

    @Test
    public void testGetSubtreeAndData() {
        MyTree<String> tree = new MyTree<>("root");
        tree.add("root", "a");
        tree.add("a", "b");
        MyTree<String> subtree = tree.get("a");
        assertEquals("a", subtree.getData());
        assertTrue(subtree.exists("b"));
    }

    @Test
    public void testIsPredecessorOf() {
        MyTree<String> tree = new MyTree<>("root");
        tree.add("root", "a");
        tree.add("a", "b");
        assertTrue(tree.isPredecessorOf("a", "b"));
        assertTrue(tree.isPredecessorOf("root", "b"));
        assertFalse(tree.isPredecessorOf("b", "root"));
    }
}
