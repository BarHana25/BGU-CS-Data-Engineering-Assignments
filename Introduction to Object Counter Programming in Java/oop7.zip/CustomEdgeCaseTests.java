package pokemon;

import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;

public class CustomEdgeCaseTests {

    @Test(timeout = 2000)
    public void testAddDuplicateRootToForest() {
        MyForest<String> forest = new MyForest<>();
        assertTrue(forest.add("Pikachu"));
        assertFalse("Adding duplicate root should return false", forest.add("Pikachu"));
    }

    @Test(timeout = 2000)
    public void testAddChildToNonexistentParent() {
        MyForest<String> forest = new MyForest<>();
        assertFalse("Should not allow adding child to nonexistent parent", forest.add("GhostParent", "Haunter"));
    }

    @Test(timeout = 2000)
    public void testRemoveNonexistentElementFromForest() {
        MyForest<String> forest = new MyForest<>();
        forest.add("Charmander");
        assertFalse("Removing nonexistent element should return false", forest.remove("Bulbasaur"));
    }

    @Test(timeout = 2000)
    public void testGetTreeOfNonexistentPokemonInPokedex() {
        Pokedex pokedex = new Pokedex();
        MyTree<String> tree = pokedex.getEvolutionTreeByName("Missingno");
        assertNull("Should return null for non-existing pokemon", tree);
    }

    @Test(timeout = 2000)
    public void testPokemonAddedWithNullParentCreatesNewTree() {
        Pokedex pokedex = new Pokedex();
        try {
            Pokemon magikarp = new Pokemon("Magikarp", new Type("Water"), 10, 20, 30);
            pokedex.addPokemon(magikarp, null); // null parent means new tree
            MyTree<String> tree = pokedex.getEvolutionTreeByName("Magikarp");
            assertNotNull("Tree should exist for Magikarp", tree);
            assertEquals("Magikarp should be root", "Magikarp", tree.getData());
        } catch (PokemonException e) {
            Assert.fail("Pokemon creation failed unexpectedly");
        }
    }
}
