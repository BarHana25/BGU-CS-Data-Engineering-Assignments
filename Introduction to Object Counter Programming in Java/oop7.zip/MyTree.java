package pokemon;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MyTree<T> implements Serializable {
    private Node root;
    /**
     * Internal class representing a node in the tree.
     */
    private class Node implements Serializable {
        T data;
        Node parent;
        List<Node> children;
        Node(T data) {
            this.data = data;
            this.children = new ArrayList<>();
        }
    }
    /**
     * Creates a new tree with a single root node.
     * @param element the value to store at the root
     */
    public MyTree(T element) {
        this.root = new Node(element);
    }
    /**
     * Helper method to find a node with the given value in the subtree starting at 'curr'.
     */
    private Node findNode(Node curr, T element) {
        if (curr == null) {
            return null;
        }
        if (curr.data.equals(element)) {
            return curr;
        }
        for (Node child : curr.children) {
            Node found = findNode(child, element);
            if (found != null) {
                return found;
            }
        }
        return null;
    }
    /**
     * Removes a node (and all its subtree) from the tree.
     * You can't remove the root node.
     * @param element the value to remove
     * @return true if removed, false if not found
     */
    public boolean remove(T element) {
        Node removeNode = findNode(root, element);
        if (removeNode == null) {
            return false;
        }
        if (removeNode == root) {
            throw new IllegalArgumentException();
        }
        Node parent = removeNode.parent;
        parent.children.remove(removeNode);
        return true;
    }
    /**
     * Internal constructor used when creating a subtree.
     */
    private  MyTree(Node node){
        this.root = node;
    }
    /**
     * Gets a subtree that starts with the given element.
     * @param element the root value of the desired subtree
     * @return a new MyTree starting at that node, or null if not found
     */
    public MyTree<T> get(T element) {
        Node node = findNode(root, element);
        if (node == null) {
            return null;
        }
        return new MyTree<>(node);
    }
    /**
     * Adds a new child node to the given parent node.
     * @param parent the value of the parent node
     * @param element the value to add as a child
     * @return true if added successfully, false if parent not found
     */
    public boolean add(T parent, T element) {
        Node pNode = findNode(root, parent);
        if (pNode == null) {
            return false;
        }
        Node newNode = new Node(element);
        newNode.parent = pNode;
        pNode.children.add(newNode);
        return true;
    }
    /**
     * Checks whether the element exists in the tree.
     * @param element The value to search for
     * @return true if found, false otherwise
     */
    public boolean exists(T element) {
        return findNode(root, element) != null;
    }    /**
     * Checks whether the given child is a descendant of the parent.
     * @param child The supposed descendant
     * @param parent The supposed ancestor
     * @return true if child is in parent's subtree
     */
    public boolean isSuccessorOf(T child, T parent) {
        Node pNode = findNode(root, parent);
        if (pNode == null) {
            return false;
        }
        return findNode(pNode, child) != null;
    }
    /**
     * Checks whether the given parent is an ancestor of the child.
     * This walks up the tree from child to root.
     * @param parent The supposed ancestor
     * @param child The supposed descendant
     * @return true if parent is on the path from child to root
     */
    public boolean isPredecessorOf(T parent, T child) {
        Node cNode = findNode(root, child);
        if (cNode == null) {
            return false;
        }
        Node curr = cNode.parent;
        while (curr != null) {
            if (curr.data.equals(parent)) {
                return true;
            }
            curr = curr.parent;
        }
        return false;
    }
    /**
     * Recursively counts the number of nodes in the tree starting from a given node.
     * @param node The node to start counting from
     * @return The number of nodes in the subtree
     */
    private int size(Node node) {
        int counter = 1;
        for (Node child : node.children) {
            counter += size(child);
        }
        return counter;
    }
    /**
     * Returns the total number of nodes in the tree.
     * @return Tree size
     */
    public int size() {
        return size(root);
    }
    /**
     * Returns the value stored at the root of the tree.
     * @return The root data
     */
    public T getData() {
        return root.data;
    }
    /**
     * Returns the direct children of the specified parent node.
     * @param parent The value of the parent node
     * @return List of the data of each child node
     */
    public List<T> getChildren(T parent){
        Node pNode = findNode(root, parent);
        List<T> children = new ArrayList<>();
        if (pNode != null) {
            for (Node child : pNode.children) {
                children.add(child.data);
            }
        }
        return children;
    }
}
