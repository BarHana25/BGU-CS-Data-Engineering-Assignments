package pokemon;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/**
 * A forest is a collection of general trees (each represented by MyTree<T>).
 * This class allows adding elements with or without parent, removing nodes,
 * checking existence, and testing hierarchical relationships.
 *
 * @param <T> the type of elements stored in the trees
 */
public class MyForest<T> implements Serializable {
    /**
     * The list of root trees (each one is a separate tree in the forest).
     */
    private List<MyTree<T>> forest;
    /**
     * Constructs an empty forest.
     */
    public MyForest() {
        this.forest = new ArrayList<>();
    }
    /**
     * Adds a new element as a root in the forest (a new tree).
     * This is a shorthand for add(null, element).
     * @param element the value to add as a new tree
     * @return true if added, false if already exists in forest
     */
    public boolean add(T element) {
        return add(null, element);
    }
    /**
     * Adds an element to the forest.
     * If parent is null, it is added as a new tree root.
     * If parent exists in any tree, element is added as its child.
     * @param parent the parent to attach to (or null for root)
     * @param element the element to add
     * @return true if added successfully, false otherwise
     */
    public boolean add(T parent, T element) {
        if (exists(element)) {
            return false; // element already in forest
        }
        if (parent == null) {
            MyTree<T> newTree = new MyTree<>(element);
            forest.add(newTree);
            return true;
        }
        for (MyTree<T> tree : forest) {
            if (tree.add(parent, element)) {
                return true; // added to existing tree
            }
        }
        return false; // parent not found
    }
    /**
     * Removes an element and its entire subtree from the forest.
     * If the element is the root of a tree, removes the entire tree.
     * @param element the element to remove
     * @return true if removed, false if not found
     */
    public boolean remove(T element) {
        Iterator<MyTree<T>> iterator = forest.iterator();
        while (iterator.hasNext()) {
            MyTree<T> tree = iterator.next();
            if (tree.getData().equals(element)) {
                iterator.remove();// remove whole tree
                return true;
            }
            try {
                if (tree.remove(element)) {
                    return true; // removed internal node
                }
            } catch (IllegalArgumentException e) {
                // ignore if tree throws because element is root
            }
        }
        return false; // element not found
    }
    /**
     * Checks if two elements are related in any tree.
     * This includes parent-child and ancestor-descendant relationships.
     * @param element1 first element
     * @param element2 second element
     * @return true if related, false otherwise
     */
    public boolean areRelated(T element1, T element2) {
        for (MyTree<T> tree : forest) {
            if (tree.exists(element1) && tree.exists(element2)) {
                if (tree.isPredecessorOf(element1, element2) || tree.isPredecessorOf(element2, element1)) {
                    return true;
                }
            }
        }
        return false;
    }
    /**
     * Checks if an element exists in any of the trees in the forest.
     * @param element the element to search for
     * @return true if found, false otherwise
     */
    public boolean exists(T element) {
        for (MyTree<T> tree : forest) {
            if (tree.exists(element)) {
                return true;
            }
        }
        return false;
    }
    /**
     * Returns the full tree that contains the given element.
     * This is the tree whose root includes the element (either directly or deeper).
     * @param element the element to locate
     * @return the MyTree containing the element, or null if not found
     */
    public MyTree<T> getTree(T element){
        for (MyTree<T> tree : forest) {
            if (tree.exists(element)) {
                return tree;
            }
        }
        return null;
    }
}