package pokemon;
import org.junit.jupiter.api.*;
import java.io.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

public class MyTreeTest {
    MyTree<String> tree;

    @BeforeEach
    void setUp() {
        tree = new MyTree<>("root");
    }

    @Test
    void testSizeSingle() {
        assertEquals(1, tree.size());
    }

    @Test
    void testAddAndSize() {
        assertTrue(tree.add("root", "child"));
        assertEquals(2, tree.size());
    }

    @Test
    void testExists() {
        tree.add("root", "c1");
        assertTrue(tree.exists("c1"));
        assertFalse(tree.exists("nope"));
    }

    @Test
    void testSuccessorPredecessor() {
        tree.add("root", "c1");
        tree.add("c1", "gc");
        assertTrue(tree.isSuccessorOf("gc", "root"));
        assertTrue(tree.isPredecessorOf("root", "gc"));
        assertFalse(tree.isSuccessorOf("root", "gc"));
    }

    @Test
    void testRemoveLeaf() {
        tree.add("root", "child");
        assertTrue(tree.remove("child"));
        assertFalse(tree.exists("child"));
    }

    @Test
    void testRemoveNonexistent() {
        assertFalse(tree.remove("nope"));
    }

    @Test
    //FAILED
    void testRemoveRootThrows() {
        assertThrows(IllegalArgumentException.class, () -> tree.remove("root"));
    }

    @Test
    void testGetData() {
        assertEquals("root", tree.getData());
    }

    @Test
    void testSubtreeIsolation() {
        tree.add("root", "c1");
        MyTree<String> sub = tree.get("c1");
        sub.add("c1", "newChild");
        assertTrue(tree.exists("newChild"), "Modification of subtree should affect original");
    }
}


