
package pokemon;

import org.junit.Test;

import java.io.*;

import static org.junit.Assert.*;

public class CustomDeserializeTest {

    @Test(timeout = 2000)
    public void testDeserializePokedexAndGetPokemon() {
        Pokedex original = new Pokedex();
        try {
            original.addPokemon(new Pokemon("Ditto", new Type("Normal"), 5, 5, 5));

            // Serialize
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("pokedex_ditto.ser"));
            out.writeObject(original);
            out.close();

            // Deserialize
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("pokedex_ditto.ser"));
            Pokedex loaded = (Pokedex) in.readObject();
            in.close();

            assertNotNull(loaded.getEvolutionTreeByName("Ditto"));
            assertEquals("Ditto", loaded.getEvolutionTreeByName("Ditto").getData());

        } catch (Exception e) {
            fail("Serialization/deserialization failed: " + e.getMessage());
        }
    }
}
