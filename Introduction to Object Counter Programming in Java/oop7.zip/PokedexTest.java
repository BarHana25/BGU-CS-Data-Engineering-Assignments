package pokemon;

import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import static org.junit.Assert.*;

public class PokedexTest {
    @Test
    public void testAddAndGetByName() throws PokemonException {
        Pokedex pk = new Pokedex();
        Pokemon p = new Pokemon("Alpha", new Type("Grass"),1,1,1);
        pk.addPokemon(p);
        Pokemon q = pk.getByName("Alpha");
        assertEquals(p, q);
        assertSame(p, q);
    }

    @Test
    public void testAddDuplicateThrows() throws PokemonException {
        Pokedex pk = new Pokedex();
        assertThrows(PokemonException.class, () -> {
            pk.addPokemon(new Pokemon("A", new Type("Electric"),1,1,1));
            pk.addPokemon(new Pokemon("A", new Type("Water"),1,1,1));
        });
    }

    @Test
    public void testGetByNameThrows() throws PokemonException {
        Pokedex pk = new Pokedex();
        assertThrows(PokemonException.class, () -> pk.getByName("NoOne"));
    }

    @Test
    public void testIterableOrder() throws PokemonException {
        Pokedex pk = new Pokedex();
        pk.addPokemon(new Pokemon("B", new Type("Fire"),1,1,1));
        pk.addPokemon(new Pokemon("A", new Type("Grass"),1,1,1));
        Iterator<Pokemon> it = pk.iterator();
        List<String> names = new ArrayList<>();
        it.forEachRemaining(p -> names.add(p.getName()));
        assertEquals(Arrays.asList("A","B"), names);
    }

    /*//@Test
    public void testEvolutionTreeOperations() throws PokemonException {
        Pokedex pk = new Pokedex();
        pk.addPokemon(new Pokemon("P", new Type("Water"),1,1,1));
        pk.addPokemon("Qa", "P");
        MyTree<String> t = pk.getEvolutionTreeByName("P");
        assertTrue(t.exists("Qa"));
    }*/

    /*@Test
    public void testCopyConstructorIsolation() throws PokemonException {
        Pokedex orig = new Pokedex();
        orig.addPokemon(new Pokemon("O", new Type("Fire"),1,1,1));
        orig.addPokemon("C", "O");
        Pokedex copy = new Pokedex(orig);
        orig.addPokemon("X", "O");
        assertNull(copy.getEvolutionTreeByName("X"));
    }
*/
    @Test
    public void testSerialization() throws Exception {
        Pokedex pk = new Pokedex();
        pk.addPokemon(new Pokemon("S", new Type("Grass"),1,1,1));
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        ObjectOutputStream oout = new ObjectOutputStream(bout);
        oout.writeObject(pk);
        oout.close();

        ObjectInputStream oin = new ObjectInputStream(new ByteArrayInputStream(bout.toByteArray()));
        Pokedex pk2 = (Pokedex) oin.readObject();
        assertNotNull(pk2.getByName("S"));
    }
}
