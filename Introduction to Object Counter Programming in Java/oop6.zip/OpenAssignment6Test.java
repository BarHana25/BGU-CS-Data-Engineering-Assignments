package assignment6;

import org.junit.Test;

import static junit.framework.TestCase.*;

public class OpenAssignment6Test {

    private MyTree<String> buildSimpleTree() {
        MyTree<String> tree = new MyTree<>("root");
        tree.add("root", "child1");
        tree.add("root", "child2");
        return tree;
    }

    @Test(timeout = 2000)
    public void testAddAndExists_15P() {
        MyTree<String> tree = buildSimpleTree();
        assertTrue(tree.exists("child1"));
        assertTrue(tree.exists("child2"));
        assertFalse(tree.exists("nonexistent"));
    }

    @Test(timeout = 2000)
    public void testGet_15P() {
        MyTree<String> tree = buildSimpleTree();
        assertNotNull(tree.get("child2"));
        assertNull(tree.get("nonexistent"));
    }

    @Test(timeout = 2000)
    public void testRemove_15P() {
        MyTree<String> tree = buildSimpleTree();
        assertTrue(tree.remove("child2"));
        assertFalse(tree.exists("child2"));
        assertEquals(2, tree.size());
    }

    @Test(timeout = 2000)
    public void testIsPredecessorOf_15P() {
        MyTree<String> tree = buildSimpleTree();
        assertTrue(tree.isPredecessorOf("root", "child1"));
        assertFalse(tree.isPredecessorOf("child1", "child2"));
    }

    @Test(timeout = 2000)
    public void testIsSuccessorOf_15P() {
        MyTree<String> tree = buildSimpleTree();
        assertTrue(tree.isSuccessorOf("child2", "root"));
        assertFalse(tree.isSuccessorOf("child1", "child2"));
    }

    @Test(timeout = 2000)
    public void testSize_15P() {
        MyTree<String> tree = buildSimpleTree();
        assertEquals(3, tree.size());
    }

    @Test(timeout = 2000)
    public void testGetData_10P() {
        MyTree<String> tree = buildSimpleTree();
        assertEquals("root", tree.getData());
    }
}

