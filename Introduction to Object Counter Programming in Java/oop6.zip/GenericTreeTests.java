package assignment6;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Objects;

public class GenericTreeTests {

    private static class Point {
        int x, y;
        Point(int x, int y) { this.x = x; this.y = y; }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Point point = (Point) o;
            return x == point.x && y == point.y;
        }

        @Override
        public int hashCode() {
            return Objects.hash(x, y);
        }
    }

    private enum Color { RED, GREEN, BLUE }

    @Test
    public void testGenericTreeWithCustomClass() {
        Point origin = new Point(0, 0);
        Point a = new Point(1, 0);
        Point b = new Point(2, 3);

        MyTree<Point> tree = new MyTree<>(origin);
        assertTrue(tree.add(origin, a));
        assertTrue(tree.add(a, b));
        assertTrue(tree.exists(b));
        assertTrue(tree.isSuccessorOf(b, origin));
        assertFalse(tree.isSuccessorOf(origin, b));
    }

    @Test
    public void testGenericTreeWithIntegers() {
        MyTree<Integer> tree = new MyTree<>(1);
        tree.add(1, 2);
        tree.add(2, 3);
        assertTrue(tree.exists(3));
        assertTrue(tree.isSuccessorOf(3, 1));
        assertFalse(tree.isPredecessorOf(3, 1));
    }

    @Test
    public void testGenericTreeWithDoubles() {
        MyTree<Double> tree = new MyTree<>(1.1);
        tree.add(1.1, 2.2);
        tree.add(2.2, 3.3);
        assertTrue(tree.exists(2.2));
        assertEquals(3, tree.size());
    }

    @Test
    public void testGenericTreeWithEnum() {
        MyTree<Color> tree = new MyTree<>(Color.RED);
        tree.add(Color.RED, Color.GREEN);
        tree.add(Color.GREEN, Color.BLUE);
        assertTrue(tree.isSuccessorOf(Color.BLUE, Color.RED));
        assertTrue(tree.isPredecessorOf(Color.GREEN, Color.BLUE));
    }
}
