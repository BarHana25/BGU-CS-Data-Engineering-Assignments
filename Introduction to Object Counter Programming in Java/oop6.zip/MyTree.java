package assignment6;

import java.util.ArrayList;
import java.util.List;

public class MyTree<T> {
    private Node root;
    /**
     * Internal class representing a node in the tree.
     */
    private class Node {
        T data;
        Node parent;
        List<Node> children;
        Node(T data) {
            this.data = data;
            this.children = new ArrayList<>();
        }
    }
    /**
     * Creates a new tree with a single root node.
     * @param element the value to store at the root
     */
    public MyTree(T element) {
        this.root = new Node(element);
    }
    /**
     * Helper method to find a node with the given value in the subtree starting at 'curr'.
     */
    private Node findNode(Node curr, T element) {
        if (curr == null) {
            return null;
        }
        if (curr.data.equals(element)) {
            return curr;
        }
        for (Node child : curr.children) {
            Node found = findNode(child, element);
            if (found != null) {
                return found;
            }
        }
        return null;
    }
    /**
     * Removes a node (and all its subtree) from the tree.
     * You can't remove the root node.
     * @param element the value to remove
     * @return true if removed, false if not found
     */
    public boolean remove(T element) {
        Node removeNode = findNode(root, element);
        if (removeNode == null) {
            return false;
        }
        if (removeNode == root) {
            throw new IllegalArgumentException();
        }
        Node parent = removeNode.parent;
        parent.children.remove(removeNode);
        return true;
    }
    /**
     * Internal constructor used when creating a subtree.
     */
    private  MyTree(Node node){
        this.root = node;
    }
    /**
     * Gets a subtree that starts with the given element.
     * @param element the root value of the desired subtree
     * @return a new MyTree starting at that node, or null if not found
     */
    public MyTree<T> get(T element) {
        Node node = findNode(root, element);
        if (node == null) {
            return null;
        }
        return new MyTree<>(node);
    }
    /**
     * Adds a new child node to the given parent node.
     * @param parent the value of the parent node
     * @param element the value to add as a child
     * @return true if added successfully, false if parent not found
     */
    public boolean add(T parent, T element) {
        Node pNode = findNode(root, parent);
        if (pNode == null) {
            return false;
        }
        Node newNode = new Node(element);
        newNode.parent = pNode;
        pNode.children.add(newNode);
        return true;
    }
    /**
     * Checks if an element exists in the tree.
     */
    public boolean exists(T element) {
        return findNode(root, element) != null;
    }
    /**
     * Checks if 'child' is a descendant (successor) of 'parent'.
     */
    public boolean isSuccessorOf(T child, T parent) {
        Node pNode = findNode(root, parent);
        if (pNode == null) {
            return false;
        }
        return findNode(pNode, child) != null;
    }
    /**
     * Checks if 'parent' is an ancestor (predecessor) of 'child'.
     */
    public boolean isPredecessorOf(T parent, T child) {
        Node cNode = findNode(root, child);
        if (cNode == null) {
            return false;
        }
        Node curr = cNode.parent;
        while (curr != null) {
            if (curr.data.equals(parent)) {
                return true;
            }
            curr = curr.parent;
        }
        return false;
    }
    /**
     * Helper method to calculate size from a given node.
     */
    private int size(Node node) {
        int counter = 1;
        for (Node child : node.children) {
            counter += size(child);
        }
        return counter;
    }
    /**
     * Returns the number of nodes in the tree.
     */
    public int size() {
        return size(root);
    }
    /**
     * Returns the value stored at the root of the tree.
     */
    public T getData() {
        return root.data;
    }
}
