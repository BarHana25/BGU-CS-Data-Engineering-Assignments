package assingment3;

public class Type {
    private String type;
    /**
     * Returns the name of the type.
     *
     * @return the type name as a String
     */
    public String getType() {
        return this.type;
    }
    /**
     * Constructor for the Type class.
     * If the input is null, the type is set to "Water" by default.
     * Otherwise, the given value is used.
     *
     * @param type the name of the type
     */
    public Type(String type) {
        if (type == null) {
            this.type = "Water";
        } else {
            this.type = type;}
    }

    /**
     * Compares this Type object to another for equality.
     * Two Type objects are considered equal if their type names match.
     *
     * @param obj The object to compare to.
     * @return true if the other object is a Type with the same type name, false otherwise.
     */
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || !(obj instanceof Type))
            return false;
        Type other = (Type) obj;
        return this.type.equals(other.type);
    }
}
