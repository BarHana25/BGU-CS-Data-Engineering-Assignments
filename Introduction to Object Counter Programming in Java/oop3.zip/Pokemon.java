package assingment3;

public class Pokemon {
    private String name;
    private int attack;
    private int defense;
    private int health;
    private Type type;

    /**
     * Default constructor.
     * Initializes the Pokemon as Magikarp with default values.
     */
    public Pokemon() {
        this.name = "Magikarp";
        this.attack = 10;
        this.defense = 55;
        this.health = 20;
        this.type = new Type("Water");
    }
    /**
     * Sets the name of the Pokemon.
     * If the name is null, sets it to "Pikachu".
     *
     * @param name the name to set
     */
    public void setName(String name) {
        if ( name == null) {
            this.name = "Pikachu";
        } else {this.name = name;
        }
    }

    /**
     * Returns the name of the Pokemon.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the attack value.
     * Negative values are corrected to 0.
     *
     * @param attack the attack value
     */
    public void setAttack(int attack) {
        if (attack < 0) {
            this.attack = 0;
        } else {
            this.attack = attack;
        }
    }

    /**
     * Returns the attack value.
     *
     * @return the attack
     */
    public int getAttack() {
        return this.attack;
    }

    /**
     * Sets the defense value.
     * Negative values are corrected to 0.
     *
     * @param defense the defense value
     */
    public void setDefense(int defense) {
        if (defense < 0) {
            this.defense = 0;
        } else {
            this.defense = defense;
        }
    }

    /**
     * Returns the defense value.
     *
     * @return the defense
     */
    public int getDefense() {
        return this.defense;
    }
    /**
     * Sets the health value.
     * Values less than 1 are corrected to 1.
     *
     * @param health the health value
     */
    public void setHealth(int health) {
        if (health < 1) {
            this.health = 1;
        } else {
            this.health = health;
        }
    }

    /**
     * Returns the health value.
     *
     * @return the health
     */
    public int getHealth() {
        return this.health;
    }
    /**
     * Sets the Pokemon's type.
     * If the input is null, sets to new Type("Water").
     * Otherwise, sets a deep copy of the provided Type.
     *
     * @param type the Type to set
     */
    public void setType(Type type) {
        if (type == null) {
            this.type = new Type("Water");
        } else {
            this.type = new Type(type.getType());
        }
    }

    /**
     * Returns a copy of the Pokemon's Type.
     *
     * @return the Type (deep copy)
     */
    public Type getType() {
        return new Type(this.type.getType());
    }

    /**
     * Full constructor.
     * Initializes all fields using setter methods.
     *
     * @param name the name
     * @param type the type
     * @param attack the attack value
     * @param defense the defense value
     * @param health the health value
     */
    public Pokemon(String name, Type type, int attack, int defense, int health) {
        setName(name);
        setAttack(attack);
        setDefense(defense);
        setHealth(health);
        setType(type);
    }

    /**
     * Copy constructor.
     * Creates a deep copy of another Pokemon.
     *
     * @param other the Pokemon to copy
     */
    public Pokemon(Pokemon other) {
        setName(other.getName());
        setAttack(other.getAttack());
        setDefense(other.getDefense());
        setHealth(other.getHealth());
        setType(new Type(other.getType().getType()));
    }
    /**
     * Returns the current attack value.
     * This method may be extended in the future.
     *
     * @return the attack value
     */
    public int calcAttack() {
        return this.attack;
    }

    /**
     * Checks if this Pokemon is equal to another object.
     * Equality is based on name, type, attack, defense, and health.
     *
     * @param obj The object to compare to.
     * @return true if obj is a Pokemon with the same attributes, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Pokemon other = (Pokemon) obj;
        return this.getName().equals(other.getName()) &&
                this.getType().equals(other.getType()) &&
                this.getAttack() == other.getAttack() &&
                this.getDefense() == other.getDefense() &&
                this.getHealth() == other.getHealth();
    }

    /**
     * Creates and returns a deep copy of this Pokemon.
     * <p>
     * This method uses the copy constructor to ensure that
     * all fields are duplicated properly, including complex objects.
     *
     * @return A new Pokemon instance with the same values as this one.
     */
    @Override
    public Pokemon clone() {
        return new Pokemon(this);
    }

}
