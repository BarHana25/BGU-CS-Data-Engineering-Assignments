package assingment3;

import org.junit.Test;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

public class OpenAssignment3Test {

    //Helpers

    Pokemon GetPokemon1() {
        return new Pokemon("Balbasaur", new Type("Grass"), 49, 49, 45);
    }

    Pokemon GetPokemon2() {
        return new Pokemon("Squirtle", new Type("Water"), 48, 65, 44);
    }

    Pokemon GetSpecialPokemon1() {
        return new SpecialPokemon("Wartortle", new Type("Water"), 48, 80, 59, 5);
    }

    SpecialPokemon GetSpecialPokemon2() {
        return new SpecialPokemon("Blastoise", new Type("Water"), 83, 100, 79, 6);
    }

    @Test(timeout = 2000)
    public void PokedexConstructorTest_12P() {
        Pokedex pokedex = new Pokedex();
        assertNotNull("Problem with default constructor.", pokedex);
    }

    @Test(timeout = 2000)
    public void PokedexAddTest_11P() {
        Pokedex pokedex = new Pokedex();
        Pokemon pokemon1 = GetPokemon1();
        Pokemon pokemon2 = new Pokemon(pokemon1);
        Pokemon pokemon3 = GetPokemon2();
        Pokemon specialPokemon1 = GetSpecialPokemon1();
        SpecialPokemon specialPokemon2 = GetSpecialPokemon2();

        pokedex.addPokemon(pokemon1);
        pokedex.addPokemon(pokemon2);
        pokedex.addPokemon(pokemon3);
        pokedex.addPokemon(specialPokemon1);
        pokedex.addPokemon(specialPokemon2);

        assertEquals("Problem with addPokemon function.", pokemon1.getAttack(), pokedex.getByName(pokemon1.getName()).getAttack());
        assertEquals("Problem with addPokemon function.", pokemon1.getAttack(), pokedex.getByName(pokemon1.getName()).getAttack());
        assertEquals("Problem with addPokemon function.", specialPokemon1.getAttack(), pokedex.getByName(specialPokemon1.getName()).getAttack());
        assertEquals("Problem with addPokemon function.", specialPokemon2.getAttack(), pokedex.getByName(specialPokemon2.getName()).getAttack());
    }

    @Test(timeout = 2000)
    public void PokedexCopyConstructorTest_11P() {
        Pokedex pokedex1 = new Pokedex();
        assertNotEquals(pokedex1, null);

        Pokemon pokemon1 = GetPokemon1();
        Pokemon pokemon3 = GetPokemon2();
        Pokemon specialPokemon1 = GetSpecialPokemon1();
        SpecialPokemon specialPokemon2 = GetSpecialPokemon2();

        pokedex1.addPokemon(pokemon1);
        pokedex1.addPokemon(pokemon3);
        pokedex1.addPokemon(specialPokemon1);
        pokedex1.addPokemon(specialPokemon2);
        Pokedex pokedex2 = new Pokedex(pokedex1);

        assertEquals("Problem with copy constructor.", pokedex1.getByName(pokemon1.getName()).getAttack(), pokedex2.getByName(pokemon1.getName()).getAttack());
        assertEquals("Problem with copy constructor.", pokedex1.getByName(specialPokemon1.getName()).getAttack(), pokedex2.getByName(specialPokemon1.getName()).getAttack());
        assertEquals("Problem with copy constructor.", pokedex1.getByName(specialPokemon2.getName()).getAttack(), pokedex2.getByName(specialPokemon2.getName()).getAttack());
    }


    @Test(timeout = 2000)
    public void SpecialTypeIsPokemonTest_11P() {
        SpecialPokemon specialPokemon = new SpecialPokemon("Charizard", new Type("Fire"), 20, 30, 100, 5);
        assertTrue("Problem with Special Pokemon", specialPokemon instanceof SpecialPokemon);
        assertTrue("Problem with Special Pokemon", specialPokemon instanceof Pokemon);
    }

    @Test(timeout = 2000)
    public void GetSpecialAttackTest_11P() {
        SpecialPokemon specialPokemon = new SpecialPokemon("Charizard", new Type("Fire"), 20, 30, 100, 5);
        assertEquals("Problem with Special Pokemon", 5, specialPokemon.getSpecialAttack());
    }

    @Test(timeout = 2000)
    public void OverriddenCalcAttackTest_11P() {
        SpecialPokemon specialPokemon = new SpecialPokemon("Charizard", new Type("Fire"), 20, 30, 100, 5);
        assertEquals("Problem with Special Pokemon", 20 * 5, specialPokemon.calcAttack());
    }

    @Test(timeout = 2000)
    public void SpecialPokemonEqualsSpecialPokemonTest_11P() {
        Type electric = new Type("Electric");
        SpecialPokemon p1 = new SpecialPokemon("Pikachu", electric, 55, 40, 100, 80);
        SpecialPokemon p2 = new SpecialPokemon("Pikachu", electric, 55, 40, 100, 80);

        assertEquals("Problem with equal function.", p1, p2);
    }

    @Test(timeout = 2000)
    public void PokemonNotEqualsSpecialPokemonTest_11P() {
        Type electric = new Type("Electric");
        Pokemon basePikachu = new Pokemon("Pikachu", electric, 55, 40, 100);
        SpecialPokemon specialPikachu1 = new SpecialPokemon("Pikachu", electric, 55, 40, 100, 80);
        assertNotEquals("Problem with equal function.", basePikachu, specialPikachu1);
    }

    @Test(timeout = 2000)
    public void PokemonEqualsPokemonTest_11P() {

        Type electric = new Type("Electric");
        Pokemon p1 = new Pokemon("Pikachu", electric, 55, 40, 100);
        Pokemon p2 = new Pokemon("Pikachu", electric, 55, 40, 100);

        assertEquals("Problem with equal function.", p1, p2);
    }
}
