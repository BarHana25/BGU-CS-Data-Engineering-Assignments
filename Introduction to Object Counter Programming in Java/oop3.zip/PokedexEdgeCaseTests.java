package assingment3;

import org.junit.Test;
import static org.junit.Assert.*;

public class PokedexEdgeCaseTests {

    @Test
    public void testNullNameDefaultsToPikachu() {
        Pokedex pokedex = new Pokedex();
        Pokemon p = new Pokemon(null, new Type("Fire"), 50, 50, 50);
        pokedex.addPokemon(p);

        // אנחנו מצפים שהוא יישמר בשם "Pikachu"
        Pokemon stored = pokedex.getByName("Pikachu");

        assertNotNull(stored);
        assertEquals("Pikachu", stored.getName());
    }


    @Test
    public void testAddPokemonEmptyName() {
        Pokedex pokedex = new Pokedex();
        Pokemon p = new Pokemon("", new Type("Electric"), 30, 40, 60);
        pokedex.addPokemon(p);
        assertEquals(p, pokedex.getByName(""));
    }

    @Test
    public void testAddTwoWithSameNameDifferentType() {
        Pokedex pokedex = new Pokedex();
        Pokemon p1 = new Pokemon("Pika", new Type("Electric"), 50, 40, 60);
        Pokemon p2 = new Pokemon("Pika", new Type("Water"), 20, 20, 20);
        pokedex.addPokemon(p1);
        pokedex.addPokemon(p2); // second should overwrite
        assertEquals(p2, pokedex.getByName("Pika"));
    }

    @Test
    public void testCloneIndependence() {
        Pokedex pokedex = new Pokedex();
        Pokemon original = new Pokemon("Bulba", new Type("Grass"), 40, 50, 60);
        pokedex.addPokemon(original);
        Pokemon fromDex = pokedex.getByName("Bulba");
        fromDex = new Pokemon("Bulba", new Type("Poison"), 1, 1, 1);
        assertNotEquals(fromDex, pokedex.getByName("Bulba"));
    }

    @Test
    public void testEqualsBetweenPokemonAndSpecialPokemon() {
        Pokemon p = new Pokemon("Mew", new Type("Psychic"), 90, 90, 90);
        SpecialPokemon sp = new SpecialPokemon("Mew", new Type("Psychic"), 90, 90, 90, 10);
        assertNotEquals(p, sp);
        assertNotEquals(sp, p);
    }

    @Test
    public void testAddSameObjectTwice() {
        Pokedex pokedex = new Pokedex();
        Pokemon p = new Pokemon("Charm", new Type("Fire"), 30, 20, 40);
        pokedex.addPokemon(p);
        pokedex.addPokemon(p);
        assertEquals(p.getName(), pokedex.getByName("Charm").getName());
    }

    @Test
    public void testGetByNameNotFound() {
        Pokedex pokedex = new Pokedex();
        assertNull(pokedex.getByName("Missingno"));
    }

    @Test
    public void testSpecialPokemonCalcAttack() {
        SpecialPokemon sp = new SpecialPokemon("Zapdos", new Type("Electric"), 50, 50, 100, 3);
        assertEquals(150, sp.calcAttack());
    }

    @Test
    public void testEqualsNullAndDifferentType() {
        Pokemon p = new Pokemon("Ghost", new Type("Dark"), 30, 40, 50);
        assertNotEquals(p, null);
        assertNotEquals(p, "not a pokemon");
    }

    @Test
    public void testPokedexCopyIsIndependent() {
        Pokedex original = new Pokedex();
        Pokemon p = new Pokemon("Lapras", new Type("Water"), 60, 70, 80);
        original.addPokemon(p);

        Pokedex copy = new Pokedex(original);
        Pokemon fromCopy = copy.getByName("Lapras");
        Pokemon fromOriginal = original.getByName("Lapras");

        assertEquals(fromOriginal, fromCopy);

        // mutate the clone from copy
        Pokemon mutated = new Pokemon("Lapras", new Type("Ice"), 0, 0, 0);
        copy.addPokemon(mutated);

        assertNotEquals(original.getByName("Lapras"), copy.getByName("Lapras"));
    }


    @Test
    public void testTypeNullFallback() {
        Type t = new Type(null);
        assertEquals("Water", t.getType());
    }
} 
