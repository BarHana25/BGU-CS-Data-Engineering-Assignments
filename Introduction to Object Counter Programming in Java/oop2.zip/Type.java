package pokemon;

public class Type {
    private String type;
    /**
     * Returns the name of the type.
     *
     * @return the type name as a String
     */
    public String getType() {
        return this.type;
    }
    /**
     * Constructor for the Type class.
     * If the input is null, the type is set to "Water" by default.
     * Otherwise, the given value is used.
     *
     * @param type the name of the type
     */
    public Type(String type) {
        if (type == null) {
            this.type = "Water";
        } else {
            this.type = type;}
    }
}
