package pokemon;

import java.util.ArrayList;

public class Pokedex {
    private ArrayList<Pokemon> pokemons;

    /**
     * Default constructor.
     * Initializes an empty list of Pokemon.
     */
    public Pokedex() {
        this.pokemons = new ArrayList<>();
    }

    /**
     * Copy constructor.
     * Creates a deep copy of another Pokedex, including all its Pokemon.
     *
     * @param other the Pokedex to copy
     */
    public Pokedex(Pokedex other) {
        this.pokemons = new ArrayList<>();
        for (Pokemon poke : other.pokemons) {
            Pokemon copy = new Pokemon(poke);
            this.pokemons.add(copy);
        }
    }

    /**
     * Adds a Pokemon to the Pokedex.
     * - If the Pokemon is null, it is ignored.
     * - If a Pokemon with the same name already exists, it is not added.
     * - Otherwise, a deep copy of the Pokemon is added.
     *
     * @param pokemon the Pokemon to add
     */
    public void addPokemon(Pokemon pokemon) {
        if (pokemon == null) {
            return;
        }
        for (Pokemon poke : pokemons) {
            if (poke.getName().equals(pokemon.getName())) {
                return;
            }
        }
        pokemons.add(new Pokemon(pokemon));
    }

    /**
     * Retrieves a Pokemon from the Pokedex by its name.
     * Returns null if no Pokemon with the given name is found.
     *
     * @param name the name of the Pokemon to search for
     * @return the Pokemon with the matching name, or null if not found
     */
    public Pokemon getByName(String name) {
        for (Pokemon pokemon : pokemons) {
            if (pokemon.getName().equals(name)) {
                return pokemon;
            }
        }
        return null;
    }
}
