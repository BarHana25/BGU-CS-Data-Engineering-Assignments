package pokemon;

import org.junit.Assert;
import org.junit.Test;

public class OpenPokemonTest {

    Pokemon GetPokemon1() {
        return new Pokemon("Balbasaur", new Type("Grass"), 49, 49, 45);
    }

    Pokemon GetPokemon3() {
        return new Pokemon();
    }

    @Test(timeout = 2000)
    public void typeCtrTest_9P() {
        Type type = new Type("Dragon");
        Assert.assertEquals("Dragon", type.getType());
    }

    @Test(timeout = 2000)
    public void PokemonCtrTest_9P() {
        Pokemon pokemon = GetPokemon1();
        Assert.assertEquals("Problem with constructor.", "Balbasaur", pokemon.getName());
        Assert.assertEquals("Problem with constructor.", "Grass", pokemon.getType().getType());
        Assert.assertEquals("Problem with constructor.", 49, pokemon.getAttack());
        Assert.assertEquals("Problem with constructor.", 49, pokemon.getDefense());
        Assert.assertEquals("Problem with constructor.", 45, pokemon.getHealth());
    }

    @Test(timeout = 2000)
    public void PokemonCopyCtrTest_9P() {
        Pokemon pokemon1 = GetPokemon1();
        Pokemon pokemon2 = new Pokemon(pokemon1);
        Assert.assertEquals(pokemon1.getName(), pokemon2.getName());
        Assert.assertEquals(pokemon1.getType().getType(), pokemon2.getType().getType());
        Assert.assertEquals(pokemon1.getAttack(), pokemon2.getAttack());
        Assert.assertEquals(pokemon1.getDefense(), pokemon2.getDefense());
        Assert.assertEquals(pokemon1.getHealth(), pokemon2.getHealth());
    }

    @Test(timeout = 2000)
    public void PokemonDefCtrTest_9P() {
        Pokemon pokemon1 = GetPokemon3();
        Assert.assertEquals("Magikarp", pokemon1.getName());
        Assert.assertEquals("Water", pokemon1.getType().getType());
        Assert.assertEquals(10, pokemon1.getAttack());
        Assert.assertEquals(55, pokemon1.getDefense());
        Assert.assertEquals(20, pokemon1.getHealth());
    }

    @Test(timeout = 2000)
    public void PokemonSetNameTest_9P() {
        Pokemon pokemon1 = GetPokemon3();
        pokemon1.setName("Test");
        Assert.assertEquals("Test", pokemon1.getName());
    }

    @Test(timeout = 2000)
    public void PokemonSetTypeTest_9P() {
        Pokemon pokemon1 = GetPokemon3();
        pokemon1.setType(new Type("Test"));
        Assert.assertEquals("Test", pokemon1.getType().getType());
    }

    @Test(timeout = 2000)
    public void PokemonSetAttackTest_9P() {
        Pokemon pokemon1 = GetPokemon3();
        pokemon1.setAttack(154);
        Assert.assertEquals(154, pokemon1.getAttack());
    }

    @Test(timeout = 2000)
    public void PokemonSetHealthTest_9P() {
        Pokemon pokemon1 = GetPokemon3();
        pokemon1.setHealth(154);
        Assert.assertEquals(154, pokemon1.getHealth());
    }

    @Test(timeout = 2000)
    public void PokemonSetDefenceTest_9P() {
        Pokemon pokemon1 = GetPokemon3();
        pokemon1.setDefense(154);
        Assert.assertEquals(154, pokemon1.getDefense());
    }

    @Test(timeout = 2000)
    public void PokemonCalcAttackTest_9P() {
        Pokemon pokemon1 = GetPokemon1();
        Assert.assertEquals(49, pokemon1.calcAttack());
    }

    @Test(timeout = 2000)
    public void PokedexAddAndGetTest_10P() {
        Pokedex pokedex = new Pokedex();
        pokedex.addPokemon(GetPokemon1());
        Pokemon pokemon = pokedex.getByName("Balbasaur");
        Assert.assertEquals("Balbasaur", pokemon.getName());
    }
}
