"""
Assignment 4 - Function Fitting Under Noise and Time Constraints

Goal:
- Fit a model g(x) to noisy samples y = f(x) on the interval [a, b].
- Minimize approximation error (least-squares style) while obeying a strict runtime limit.
- Do NOT use numpy optimization / linear algebra solvers (np.linalg.* forbidden).

Key ideas used in this solution:
1) Chebyshev polynomial basis for better numerical stability than monomials.
2) Custom Gaussian elimination solver (partial pivoting) for normal equations.
3) Case-based fitting:
   - d=0: Constant fit with parallel sampling
   - d=1: Linear regression
   - d=2,3: Low-degree Chebyshev fit
   - d>=4: Full degree selection with validation
4) For extreme functions (e.g., exp(exp(x))), switch to piecewise fitting:
   - Split [a,b] into segments with log-log stabilization.
5) Parallel sampling with ThreadPoolExecutor (300 workers) for denoising.
6) Trimmed mean (5%) for robust noise reduction.
7) Global transform selection (linear/log/loglog) for high dynamic range functions.

Constraints:
- Must return within maxtime + 5 seconds.
- No forbidden functions (np.linalg.solve, polyfit, lstsq, etc.).
"""

import numpy as np
import time
import random  # (Currently unused)
from concurrent.futures import ThreadPoolExecutor


class Assignment4:
    def __init__(self):
        """
        Initialization hook.
        You can place one-time computations here if needed.
        For this implementation, nothing is precomputed.
        """
        pass

    # ============================================================
    # Stage 1: Linear System Solver (Gaussian Elimination)
    # ============================================================
    # We must solve least-squares normal equations without np.linalg.
    # This function solves A x = b using:
    # - Partial pivoting for numerical stability
    # - Forward elimination + back substitution
    def _gauss_solve(self, A: np.ndarray, b: np.ndarray) -> np.ndarray:
        # Work on copies to avoid modifying the original inputs
        A = np.asarray(A, dtype=float).copy()
        b = np.asarray(b, dtype=float).copy()
        n = A.shape[0]

        # Edge case: empty system
        if n == 0:
            return np.array([], dtype=float)

        # Forward elimination (convert A to upper triangular form)
        for i in range(n):
            # Choose pivot row: the row with maximal |A[row, i]| among rows i..n-1
            piv = i + int(np.argmax(np.abs(A[i:, i])))

            # If pivot is tiny or non-finite, system is ill-conditioned -> return zeros fallback
            if (not np.isfinite(A[piv, i])) or abs(A[piv, i]) < 1e-14:
                return np.zeros(n, dtype=float)

            # Swap current row with pivot row if needed
            if piv != i:
                A[[i, piv]] = A[[piv, i]]
                b[[i, piv]] = b[[piv, i]]

            # Eliminate entries below the pivot
            ai = A[i, i]
            for j in range(i + 1, n):
                factor = A[j, i] / ai
                if factor != 0.0:
                    A[j, i:] -= factor * A[i, i:]
                    b[j] -= factor * b[i]

        # Back substitution (solve upper triangular system)
        x = np.zeros(n, dtype=float)
        for i in range(n - 1, -1, -1):
            s = b[i] - float(np.dot(A[i, i + 1:], x[i + 1:]))
            x[i] = s / A[i, i]
        return x

    # ============================================================
    # Stage 2: Chebyshev Polynomial Evaluation (more stable than monomials)
    # ============================================================
    @staticmethod
    def _cheby_eval(c: np.ndarray, t: float) -> float:
        """
        Evaluate polynomial in Chebyshev basis at value t using Clenshaw recurrence.
        Coefficients c are for Chebyshev polynomials T_0, T_1, T_2, ...
        More numerically stable than monomial basis.
        """
        c = np.asarray(c, dtype=float)
        n = len(c)
        if n == 0:
            return 0.0
        if n == 1:
            return float(c[0])

        # Clenshaw recurrence for Chebyshev evaluation
        t = float(t)
        b_prev = 0.0
        b_curr = 0.0
        for k in range(n - 1, 0, -1):
            b_next = float(c[k]) + 2.0 * t * b_curr - b_prev
            b_prev = b_curr
            b_curr = b_next
        return float(c[0]) + t * b_curr - b_prev

    @staticmethod
    def _cheby_eval_batch(c: np.ndarray, t: np.ndarray) -> np.ndarray:
        """
        Vectorized Chebyshev evaluation at multiple points using Clenshaw recurrence.
        """
        c = np.asarray(c, dtype=float)
        t = np.asarray(t, dtype=float)
        n = len(c)
        if n == 0:
            return np.zeros_like(t)
        if n == 1:
            return np.full_like(t, c[0])

        # Clenshaw recurrence (vectorized)
        b_prev = np.zeros_like(t)
        b_curr = np.zeros_like(t)
        for k in range(n - 1, 0, -1):
            b_next = c[k] + 2.0 * t * b_curr - b_prev
            b_prev = b_curr
            b_curr = b_next
        return c[0] + t * b_curr - b_prev

    @staticmethod
    def _cheby_basis(t: np.ndarray, deg: int) -> np.ndarray:
        """
        Build Chebyshev basis matrix for given points t and degree.
        Returns matrix where column k is T_k(t) for k=0..deg.
        """
        t = np.asarray(t, dtype=float)
        n = len(t)
        T = np.zeros((n, deg + 1), dtype=float)
        T[:, 0] = 1.0
        if deg > 0:
            T[:, 1] = t
            for k in range(2, deg + 1):
                T[:, k] = 2.0 * t * T[:, k - 1] - T[:, k - 2]
        return T

    # Keep old methods for backward compatibility with piecewise fitting
    @staticmethod
    def _poly_eval(c: np.ndarray, t: float) -> float:
        """Horner's rule for monomial basis (used by piecewise fitting)."""
        val = 0.0
        for ck in c[::-1]:
            val = val * t + float(ck)
        return float(val)

    @staticmethod
    def _poly_eval_batch(c: np.ndarray, t: np.ndarray) -> np.ndarray:
        """Vectorized Horner's rule for monomial basis."""
        c = np.asarray(c, dtype=float)
        t = np.asarray(t, dtype=float)
        val = np.zeros_like(t)
        for ck in c[::-1]:
            val = val * t + ck
        return val

    # ============================================================
    # Stage 3: Stabilization for Extreme Functions (log-log)
    # ============================================================
    # Some functions have values spanning many orders of magnitude.
    # For those, fitting directly in y-space is unstable.
    # We apply log() multiple times, but we must keep inputs positive.
    # Therefore, before each log, we shift y by a constant to make it > 0.
    @staticmethod
    def _safe_log_transform(y: np.ndarray, depth: int):
        """
        Apply log() repeatedly 'depth' times.

        To keep log valid, before each stage:
        - if min(y) <= 0, shift y by (-min(y) + eps).
        - store the shift so we can invert the transformation later.

        Returns:
        - y_t    : transformed values
        - shifts : list of applied shifts, one per log stage
        - ok     : True if all transformed values are finite
        """
        y_t = np.asarray(y, dtype=float).copy()
        shifts = []

        # depth == 0 means "no transform"
        if depth <= 0:
            return y_t, shifts, bool(np.isfinite(y_t).all())

        for _ in range(depth):
            minv = float(np.nanmin(y_t))
            if not np.isfinite(minv):
                return y_t, shifts, False

            shift = 0.0
            if minv <= 0.0:
                # eps depends on magnitude to avoid tiny shift relative to values
                eps = 1e-6 * max(1.0, abs(minv))
                shift = -minv + eps
                y_t = y_t + shift

            shifts.append(float(shift))

            # Compute log with error states suppressed; we check finiteness manually
            with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
                y_t = np.log(y_t)

            # If any NaN/inf occurred, transform failed
            if not np.isfinite(y_t).all():
                return y_t, shifts, False

        return y_t, shifts, True

    @staticmethod
    def _invert_log_transform(v: float, shifts):
        """
        Invert a repeated log transform for a scalar:
        - Apply exp() once for each log stage (reverse order),
        - Subtract the stored shift after each exp.

        Also performs mild clamping:
        - If intermediate value becomes non-positive but more exp steps remain,
          clamp to a tiny positive value to keep exp/log chain valid.
        """
        y = float(v)
        for k, shift in enumerate(reversed(shifts)):
            with np.errstate(over="ignore", invalid="ignore"):
                y = float(np.exp(y))
            y -= float(shift)

            if k < len(shifts) - 1:
                if (not np.isfinite(y)) or y <= 0.0:
                    y = 1e-12

        if not np.isfinite(y):
            return float("inf")
        return float(y)

    @staticmethod
    def _invert_log_transform_batch(v: np.ndarray, shifts) -> np.ndarray:
        """
        Vectorized inversion of log transform for an array of values.
        """
        y = np.asarray(v, dtype=float).copy()
        n_shifts = len(shifts)
        for k, shift in enumerate(reversed(shifts)):
            with np.errstate(over="ignore", invalid="ignore"):
                y = np.exp(y)
            y -= float(shift)
            if k < n_shifts - 1:
                # Clamp non-positive/non-finite to tiny positive
                bad = ~np.isfinite(y) | (y <= 0.0)
                y[bad] = 1e-12
        # Final non-finite -> inf
        y[~np.isfinite(y)] = float("inf")
        return y

    # ============================================================
    # Stage 4: Piecewise Fitting (per segment)
    # ============================================================
    def _fit_segment(self, f, seg_a, seg_b, d, hard_deadline, call_dt_hint):
        """
        Fit a local model on a small interval [seg_a, seg_b].

        Steps:
        1) Map x in [seg_a, seg_b] to t in [-1, 1] (affine transform).
        2) Sample f(x) at a small set of nodes (Chebyshev-like spacing).
        3) If values are extremely spread (large ratio), prefer log-log stabilization.
        4) Try several (log_depth, degree) combinations.
        5) Choose the best model according to mean absolute error on sampled nodes.
        """
        seg_a = float(seg_a)
        seg_b = float(seg_b)

        # Map segment to normalized coordinate t in [-1, 1]
        mid = 0.5 * (seg_a + seg_b)
        half = 0.5 * (seg_b - seg_a)

        # Degenerate segment: return constant model
        if half == 0.0 or not np.isfinite(half):
            y0 = float(f(seg_a))
            return {
                "a": seg_a, "b": seg_b,
                "mid": mid, "half": 1.0,
                "coeffs": np.array([y0], dtype=float),
                "deg": 0, "log_depth": 0, "shifts": []
            }

        # Limit local polynomial degree to keep it stable and cheap
        max_local_deg = max(0, min(int(d), 5))

        # Candidate polynomial degrees to try
        deg_candidates = [0, 1]
        if max_local_deg >= 2: deg_candidates.append(2)
        if max_local_deg >= 3: deg_candidates.append(3)
        if max_local_deg >= 4: deg_candidates.append(4)
        if max_local_deg >= 5: deg_candidates.append(5)

        # Choose number of sample nodes in this segment
        N = max(12, 4 * (max_local_deg + 1))
        N = min(N, 40)

        # Chebyshev-like nodes in [-1,1] (good for polynomial fitting)
        u = (np.arange(N, dtype=float) + 0.5) / N
        t_nodes = np.cos(np.pi * u)
        t_nodes = np.clip(t_nodes, -1.0, 1.0)
        x_nodes = mid + half * t_nodes

        # Sample f at each x node (one sample each, because there may be many segments)
        y = np.zeros(N, dtype=float)
        for i in range(N):
            if time.time() >= hard_deadline:
                # Truncate if time is nearly over
                y = y[: max(1, i)]
                t_nodes = t_nodes[: max(1, i)]
                break
            y[i] = float(f(float(x_nodes[i])))

        # If there are non-finite values, replace them with the median of finite values
        if not np.isfinite(y).all():
            finite = y[np.isfinite(y)]
            if finite.size == 0:
                return {
                    "a": seg_a, "b": seg_b,
                    "mid": mid, "half": half,
                    "coeffs": np.array([0.0], dtype=float),
                    "deg": 0, "log_depth": 0, "shifts": []
                }
            med = float(np.median(finite))
            y = np.where(np.isfinite(y), y, med)

        best = None
        best_score = float("inf")

        # Measure how extreme the segment is (ratio ymax/ymin for positive values)
        span_ratio = 0.0
        try:
            yy_f = y[np.isfinite(y)]
            if yy_f.size > 0:
                ymin = float(np.min(yy_f))
                ymax = float(np.max(yy_f))
                if ymin > 0.0:
                    span_ratio = ymax / ymin
        except Exception:
            span_ratio = 0.0

        # Prefer log-log first for huge positive ratios (typical exp(exp(x)) behavior)
        log_order = (2, 3) if span_ratio > 1e4 else (2, 3, 1, 0)

        # Try different stabilization depths and polynomial degrees
        for log_depth in log_order:
            if time.time() >= hard_deadline:
                break

            y_t, shifts, ok = self._safe_log_transform(y, log_depth)
            if not ok:
                continue

            for deg_try in deg_candidates:
                if time.time() >= hard_deadline:
                    break

                # Fit polynomial in transformed space
                c_try = self._fit_fixed_degree(t_nodes, y_t, deg_try)

                # Evaluate the fit at nodes (vectorized)
                pred_t = self._poly_eval_batch(c_try, t_nodes)

                # Invert transform back to original y-space (vectorized)
                if len(shifts) > 0:
                    y_hat = self._invert_log_transform_batch(pred_t, shifts)
                    # Clamp negative predictions for positive-only targets
                    y_hat = np.maximum(y_hat, 0.0)
                else:
                    y_hat = pred_t.copy()

                # Check for non-finite values
                if not np.isfinite(y_hat).all():
                    continue

                # Score: mean absolute error (MAE) + tiny penalty for model complexity
                score = float(np.mean(np.abs(y - y_hat)))
                score += 1e-8 * (deg_try + 1) * (log_depth + 1)

                # Keep best model
                if np.isfinite(score) and score < best_score:
                    best_score = score
                    best = (log_depth, shifts, deg_try, c_try)

        # If nothing worked, fallback to constant fit
        if best is None:
            c0 = float(np.mean(y))
            return {
                "a": seg_a, "b": seg_b,
                "mid": mid, "half": half,
                "coeffs": np.array([c0], dtype=float),
                "deg": 0, "log_depth": 0, "shifts": []
            }

        # Return the best segment model
        log_depth, shifts, deg_try, c_try = best
        return {
            "a": seg_a, "b": seg_b,
            "mid": mid, "half": half,
            "coeffs": c_try, "deg": deg_try,
            "log_depth": log_depth, "shifts": shifts
        }

    # ============================================================
    # Stage 5: Least Squares Polynomial Fit (Normal Equations)
    # ============================================================
    def _fit_fixed_degree(self, t_nodes: np.ndarray, y: np.ndarray, deg: int) -> np.ndarray:
        """
        Fit a polynomial of fixed degree 'deg' in monomial basis over t in [-1,1].

        Procedure:
        - Build Vandermonde matrix A where A[i,k] = t_i^k
        - Solve normal equations: (A^T A) c = (A^T y)
        - Add small ridge regularization to improve conditioning
        - Solve using custom Gaussian elimination
        """
        m = deg + 1
        A = np.vander(t_nodes, N=m, increasing=True).astype(float)

        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            G = A.T @ A      # Gram matrix
            rhs = A.T @ y    # right-hand side

        # If matrix became non-finite, fallback to constant
        if (not np.isfinite(G).all()) or (not np.isfinite(rhs).all()):
            return np.array([float(np.mean(y))], dtype=float)

        # Ridge regularization: lambda scaled by trace(G)
        trG = float(np.trace(G))
        lam = 1e-8 * trG / m if np.isfinite(trG) and trG > 0 else 1e-8
        G = G + lam * np.eye(m)

        return self._gauss_solve(G, rhs)

    def _fit_cheby_degree(self, t_nodes: np.ndarray, y: np.ndarray, deg: int) -> np.ndarray:
        """
        Fit a polynomial in Chebyshev basis (more stable than monomials).

        Uses Chebyshev polynomials T_0, T_1, ..., T_deg which are orthogonal
        and lead to better-conditioned matrices.
        """
        m = deg + 1
        A = self._cheby_basis(t_nodes, deg)

        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            G = A.T @ A
            rhs = A.T @ y

        if (not np.isfinite(G).all()) or (not np.isfinite(rhs).all()):
            return np.array([float(np.mean(y))], dtype=float)

        # Ridge regularization
        trG = float(np.trace(G))
        lam = 1e-10 * trG / m if np.isfinite(trG) and trG > 0 else 1e-10
        G = G + lam * np.eye(m)

        return self._gauss_solve(G, rhs)

    # ============================================================
    # Stage 6A: Parallel Sampling with Denoising
    # ============================================================

    def _parallel_sample(self, f, x_nodes, hard_deadline, n_workers=300, samples_per_node=5):
        """
        Sample f at x_nodes using parallel threads for speed and denoising.

        Strategy:
        - First try vectorized call f(x_nodes) if function supports it (much faster)
        - Use many threads (n_workers=300) to sample concurrently
        - Each node gets multiple samples (samples_per_node)
        - Use TRIMMED MEAN (drop top/bottom 10%) for robust denoising

        This is especially effective when f has delays (e.g., DELAYED decorator)
        because threads can run concurrently while waiting.
        """
        N = len(x_nodes)
        if N == 0:
            return np.array([]), np.array([])

        # Storage for all samples per node (for trimmed mean)
        all_samples = [[] for _ in range(N)]
        samples_lock = __import__('threading').Lock()

        def sample_task(node_idx):
            """Sample f at a single node."""
            if time.time() >= hard_deadline:
                return None
            try:
                val = float(f(float(x_nodes[node_idx])))
                if np.isfinite(val):
                    with samples_lock:
                        all_samples[node_idx].append(val)
                return val
            except Exception:
                return None

        # Create all sampling tasks: each node sampled multiple times
        tasks = []
        for sample_round in range(samples_per_node):
            for node_idx in range(N):
                tasks.append(node_idx)

        # Execute tasks in parallel with many workers
        with ThreadPoolExecutor(max_workers=n_workers) as executor:
            futures = []
            for node_idx in tasks:
                if time.time() >= hard_deadline:
                    break
                futures.append(executor.submit(sample_task, node_idx))

            # Wait for completion with timeout
            for fut in futures:
                if time.time() >= hard_deadline:
                    break
                try:
                    remaining = max(0.01, hard_deadline - time.time())
                    fut.result(timeout=remaining)
                except Exception:
                    pass

        # Compute denoised values using TRIMMED MEAN
        # Drop top/bottom 5% to handle outliers robustly
        y = np.zeros(N, dtype=float)
        y_cnt = np.zeros(N, dtype=int)

        for i in range(N):
            samples = all_samples[i]
            n_samp = len(samples)
            y_cnt[i] = n_samp

            if n_samp == 0:
                y[i] = np.nan
            elif n_samp <= 2:
                y[i] = float(np.mean(samples))
            else:
                sorted_samp = sorted(samples)
                # 5% trimmed mean (or median if too few samples)
                trim = max(1, int(n_samp * 0.05))
                if 2 * trim >= n_samp:
                    y[i] = float(sorted_samp[n_samp // 2])  # median
                else:
                    trimmed = sorted_samp[trim:-trim]
                    y[i] = float(np.mean(trimmed))

        return y, y_cnt

    # ============================================================
    # Stage 6B: Case-Based Fast Paths
    # ============================================================

    def _fit_constant_case(self, f, a, b, mid, half, hard_deadline):
        """
        CASE d=0: Fit a constant function.
        Strategy: Parallel sampling at many points with denoising.
        """
        # Sample at 15 points with multiple samples per point for denoising
        n_samples = 15
        x_points = np.linspace(a, b, n_samples)

        # Use parallel sampling with denoising
        y, y_cnt = self._parallel_sample(f, x_points, hard_deadline,
                                          n_workers=300, samples_per_node=8)

        # Filter out nodes with no samples
        valid = y_cnt > 0
        if not np.any(valid):
            return lambda x: 0.0

        # Use mean of valid samples for constant fit
        c0 = float(np.mean(y[valid]))
        return lambda x, c0=c0: c0

    def _fit_linear_case(self, f, a, b, mid, half, hard_deadline):
        """
        CASE d=1: Fit a linear function y = c0 + c1*t.
        Strategy: Parallel sampling with denoising.
        """
        N = 20
        u = (np.arange(N, dtype=float) + 0.5) / N
        t_nodes = np.cos(np.pi * u)
        t_nodes = np.clip(t_nodes, -1.0, 1.0)
        x_nodes = mid + half * t_nodes

        # Use parallel sampling with denoising
        y, y_cnt = self._parallel_sample(f, x_nodes, hard_deadline,
                                          n_workers=300, samples_per_node=6)

        # Filter valid nodes
        valid = y_cnt > 0
        if np.sum(valid) < 2:
            c0 = float(np.nanmean(y)) if np.any(valid) else 0.0
            return lambda x, c0=c0: c0

        t_valid = t_nodes[valid]
        y_valid = y[valid]

        # Simple linear regression
        n = len(t_valid)
        sum_t = np.sum(t_valid)
        sum_t2 = np.sum(t_valid * t_valid)
        sum_y = np.sum(y_valid)
        sum_ty = np.sum(t_valid * y_valid)

        det = n * sum_t2 - sum_t * sum_t
        if abs(det) < 1e-12:
            c0 = float(np.mean(y_valid))
            return lambda x, c0=c0: c0

        c0 = (sum_t2 * sum_y - sum_t * sum_ty) / det
        c1 = (n * sum_ty - sum_t * sum_y) / det

        c = np.array([c0, c1], dtype=float)

        def g(x, c=c, mid=mid, half=half):
            t = (float(x) - mid) / half
            t = max(-1.0, min(1.0, t))
            return float(c[0] + c[1] * t)

        return g

    def _fit_low_degree_case(self, f, a, b, mid, half, max_deg, hard_deadline):
        """
        CASE d=2 or d=3: Direct polynomial fit with parallel sampling.
        Strategy: Parallel sample at ~30 points with denoising.
        Uses Chebyshev basis for numerical stability (no transforms for polynomials).
        """
        N = 30

        u = (np.arange(N, dtype=float) + 0.5) / N
        t_nodes = np.cos(np.pi * u)
        t_nodes = np.clip(t_nodes, -1.0, 1.0)
        x_nodes = mid + half * t_nodes

        # Use parallel sampling with denoising
        y, y_cnt = self._parallel_sample(f, x_nodes, hard_deadline,
                                          n_workers=300, samples_per_node=5)

        # Filter valid nodes
        valid = y_cnt > 0
        actual_n = np.sum(valid)

        if actual_n < max_deg + 1:
            if actual_n > 0:
                c0 = float(np.nanmean(y[valid]))
                return lambda x, c0=c0: c0
            return lambda x: 0.0

        t_nodes = t_nodes[valid]
        y = y[valid]

        # Handle non-finite values
        if not np.isfinite(y).all():
            finite_mask = np.isfinite(y)
            if np.sum(finite_mask) < max_deg + 1:
                c0 = float(np.nanmean(y))
                return lambda x, c0=c0: c0
            t_nodes = t_nodes[finite_mask]
            y = y[finite_mask]
            actual_n = len(y)

        # Simple degree selection: try max_deg and max_deg-1
        best_c = None
        best_err = float('inf')

        for deg_try in range(max(0, max_deg - 1), max_deg + 1):
            if time.time() >= hard_deadline:
                break
            c_try = self._fit_cheby_degree(t_nodes, y, deg_try)
            pred = self._cheby_eval_batch(c_try, t_nodes)
            err = float(np.mean((y - pred) ** 2))
            err += 1e-6 * deg_try  # Prefer simpler models
            if err < best_err:
                best_err = err
                best_c = c_try

        if best_c is None:
            best_c = self._fit_cheby_degree(t_nodes, y, max_deg)

        c = best_c

        def g(x, c=c, mid=mid, half=half):
            t = (float(x) - mid) / half
            t = max(-1.0, min(1.0, t))
            return self._cheby_eval(c, t)

        return g

    # ============================================================
    # Stage 6: Main Fitting Routine (fit)
    # ============================================================
    def fit(self, f: callable, a: float, b: float, d: int, maxtime: float) -> callable:
        """
        Returns a callable model g(x) approximating f(x) over [a, b].

        High-level flow:
        1) Set a hard deadline: must return within (maxtime + 5 seconds).
        2) CASE-BASED: Handle special cases (d=0, d=1, d<=3) with fast paths.
        3) Build sampling nodes (Chebyshev-like).
        4) Estimate call time per sample to decide how aggressive we can be.
        5) Detect extreme functions; if extreme and time allows -> piecewise fit.
        6) Otherwise do global polynomial LS fit.
        """

        start = time.time()
        hard_deadline = start + float(maxtime) + 4.5  # ensures <= maxtime+5

        a = float(a)
        b = float(b)
        d = int(d)

        # Handle degenerate intervals: return constant function
        if not np.isfinite(a) or not np.isfinite(b) or a == b:
            y0 = float(f(a))
            return lambda x, y0=y0: y0

        # Map [a,b] to t in [-1,1]
        mid = 0.5 * (a + b)
        half = 0.5 * (b - a)
        if (not np.isfinite(half)) or abs(half) < 1e-12:
            y0 = float(f(a))
            return lambda x, y0=y0: y0

        # Cap degree for stability (grader expects max 12)
        max_deg = max(0, min(d, 12))

        # ============================================================
        # CASE-BASED FAST PATHS
        # ============================================================

        # CASE 1: d=0 (constant function) - just compute mean
        if max_deg == 0:
            return self._fit_constant_case(f, a, b, mid, half, hard_deadline)

        # CASE 2: d=1 (linear function) - simple linear regression
        if max_deg == 1:
            return self._fit_linear_case(f, a, b, mid, half, hard_deadline)

        # CASE 3: d=2 or d=3 (low degree) - direct fit, skip degree selection
        if max_deg <= 3:
            return self._fit_low_degree_case(f, a, b, mid, half, max_deg, hard_deadline)

        # ============================================================
        # GENERAL CASE: d >= 4
        # ============================================================
        m_full = max_deg + 1

        # Choose number of global sampling nodes
        N = max(3 * m_full, 40)
        N = min(N, 200)

        # Build Chebyshev-like nodes
        u = (np.arange(N, dtype=float) + 0.5) / N
        t_nodes = np.cos(np.pi * u)
        t_nodes = np.clip(t_nodes, -1.0, 1.0)
        x_nodes = mid + half * t_nodes

        # Probe f once to estimate how expensive a single evaluation is
        t0 = time.time()
        y_probe = float(f(float(x_nodes[0])))
        call_dt = max(1e-6, time.time() - t0)

        # -------------------------------------------------
        # Detect extreme functions (e.g., exp(exp(x)), ln(ln(x)))
        # and, if we have enough time, switch to piecewise fitting
        # with per-segment log/log stabilization.
        # -------------------------------------------------
        use_piecewise = False
        scan_ratio = 0.0
        if maxtime >= 8 and call_dt < 0.8:  # avoid too many calls if f is very slow
            # quick scan on a few points (cheap)
            scan_n = 9
            scan_x = np.linspace(a, b, scan_n, dtype=float)
            scan_y = np.empty(scan_n, dtype=float)
            scan_y[0] = y_probe
            ok_scan = True
            all_positive = False
            for i in range(1, scan_n):
                if time.time() >= hard_deadline:
                    ok_scan = False
                    break
                scan_y[i] = float(f(float(scan_x[i])))
            if ok_scan:
                finite = scan_y[np.isfinite(scan_y)]
                if finite.size > 0:
                    max_val = float(np.max(finite))
                    min_val = float(np.min(finite))
                    all_positive = (min_val > 0.0 and np.isfinite(min_val))
                    scan_ratio = (max_val / min_val) if (min_val > 0.0) else float('inf')
                    # as in your friend's patch: huge max or huge ratio
                    if max_val > 1e10:
                        use_piecewise = True
                    elif min_val > 0 and scan_ratio > 1e5:
                        use_piecewise = True
                # if we saw non-finite values at all, it's also a hint
                if not np.isfinite(scan_y).all():
                    use_piecewise = True

        if use_piecewise and time.time() < hard_deadline - 0.2:
            # choose number of segments: 20..50, but also respect time budget
            base_segments = max(25, min(80, int(abs(b - a) * 20)))

            # estimate cost per segment: ~N calls, N~10..30
            est_calls_per_seg = 18
            remaining = max(0.0, hard_deadline - time.time())
            # keep headroom for python overhead; use up to ~75% of remaining time
            max_calls = int(0.75 * remaining / max(1e-6, call_dt))
            max_segments_by_time = max(5, max_calls // max(1, est_calls_per_seg))
            num_segments = int(max(5, min(base_segments, max_segments_by_time)))

            s = np.linspace(0.0, 1.0, num_segments + 1, dtype=float)
            if all_positive and scan_ratio > 1e4:
                # pack more segments near the right edge (steep growth)
                gamma = 2.0
                s = 1.0 - np.power(1.0 - s, gamma)
            bounds = a + (b - a) * s

            # Parallel segment fitting using ThreadPoolExecutor
            # Use min of 4 workers to avoid excessive overhead
            n_workers = min(4, num_segments)

            def fit_single_segment(i):
                if time.time() >= hard_deadline:
                    return (i, None)
                seg_a = float(bounds[i])
                seg_b = float(bounds[i + 1])
                return (i, self._fit_segment(f, seg_a, seg_b, d, hard_deadline, call_dt))

            models_indexed = []
            if n_workers > 1 and num_segments >= 4:
                # Parallel execution for multiple segments
                with ThreadPoolExecutor(max_workers=n_workers) as executor:
                    futures = [executor.submit(fit_single_segment, i) for i in range(num_segments)]
                    for fut in futures:
                        if time.time() >= hard_deadline:
                            break
                        try:
                            timeout_val = max(0.1, hard_deadline - time.time())
                            result = fut.result(timeout=timeout_val)
                            if result[1] is not None:
                                models_indexed.append(result)
                        except Exception:
                            pass
            else:
                # Sequential fallback for few segments
                for i in range(num_segments):
                    if time.time() >= hard_deadline:
                        break
                    result = fit_single_segment(i)
                    if result[1] is not None:
                        models_indexed.append(result)

            # Sort by segment index to maintain order
            models_indexed.sort(key=lambda x: x[0])
            models = [m[1] for m in models_indexed]

            # If we failed to build enough segments, fall back to global fit
            if len(models) >= 2:
                seg_ends = np.array([m["b"] for m in models], dtype=float)

                def piecewise_g(x, models=models, seg_ends=seg_ends, all_positive=all_positive):
                    xv = float(x)
                    # locate segment with binary search
                    j = int(np.searchsorted(seg_ends, xv, side="right"))
                    if j < 0:
                        j = 0
                    if j >= len(models):
                        j = len(models) - 1
                    md = models[j]
                    t = (xv - md["mid"]) / md["half"]
                    if t > 1.0:
                        t = 1.0
                    elif t < -1.0:
                        t = -1.0
                    v = self._poly_eval(md["coeffs"], t)
                    if md["log_depth"] > 0:
                        v = self._invert_log_transform(v, md["shifts"])
                    if all_positive and v < 0.0:
                        v = 0.0
                    return float(v)

                return piecewise_g

        # If f is slow, don't waste time on degree selection / heavy averaging
        slow = call_dt > 0.15
        very_slow = call_dt > 0.8

        # --------------------------------------
        # Parallel sampling with denoising
        # Uses 300 workers for concurrent sampling
        # --------------------------------------
        samples_per_node = 4 if not very_slow else 2
        y, y_cnt = self._parallel_sample(f, x_nodes, hard_deadline,
                                          n_workers=300, samples_per_node=samples_per_node)

        # Filter valid nodes
        valid = y_cnt > 0
        if np.sum(valid) < 2:
            c0 = float(np.nanmean(y[valid])) if np.any(valid) else 0.0
            return lambda x, c0=c0: c0

        # Keep only valid nodes
        t_nodes = t_nodes[valid]
        x_nodes = x_nodes[valid]
        y = y[valid]
        N = len(y)

        if (not np.isfinite(y).all()) or N < 2:
            c0 = float(np.nanmean(y)) if N > 0 else 0.0
            return lambda x, c0=c0: c0

        # --------------------------------------
        # Degree choice:
        # - If f is slow: trust given d (capped) to save time
        # - If f is fast: pick best degree by a small validation split
        # --------------------------------------
        if slow:
            best_deg = max_deg
        else:
            idx = np.arange(N)
            train = idx[::2]
            val = idx[1::2]
            if len(val) < 8:
                train = idx
                val = idx

            # keep validation small to save time
            V = min(25, len(val))
            val = val[:V]

            best_deg = 0
            best_score = float("inf")

            # Pre-sample fresh noisy values for validation (do this once, not per degree)
            val_y = np.empty(len(val), dtype=float)
            for i, j in enumerate(val):
                if time.time() >= hard_deadline:
                    val_y = val_y[:i]
                    val = val[:i]
                    break
                val_y[i] = float(f(float(x_nodes[j])))

            if len(val) > 0:
                val_t = t_nodes[val]

                # Pre-compute Chebyshev basis matrix for max degree on training set
                # (allows slicing for lower degrees) - more stable than Vandermonde
                A_train_full = self._cheby_basis(t_nodes[train], max_deg)

                # Try degrees 0..max_deg, but stop early if time gets tight
                for deg_try in range(0, max_deg + 1):
                    if time.time() >= hard_deadline:
                        break

                    # Slice Chebyshev basis for this degree
                    A_train = A_train_full[:, :deg_try + 1]
                    y_train = y[train]

                    # Solve normal equations
                    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
                        G = A_train.T @ A_train
                        rhs = A_train.T @ y_train

                    if (not np.isfinite(G).all()) or (not np.isfinite(rhs).all()):
                        continue

                    # Ridge regularization
                    trG = float(np.trace(G))
                    lam = 1e-10 * trG / (deg_try + 1) if np.isfinite(trG) and trG > 0 else 1e-10
                    G = G + lam * np.eye(deg_try + 1)

                    c_try = self._gauss_solve(G, rhs)

                    # Vectorized validation error using Chebyshev evaluation
                    pred = self._cheby_eval_batch(c_try, val_t)
                    diff = val_y - pred
                    err = float(np.mean(diff * diff))

                    if np.isfinite(err) and err < best_score:
                        best_score = err
                        best_deg = deg_try

        # ============================================================
        # GLOBAL TRANSFORM SELECTION
        # Try linear, log, and loglog transforms; pick best by MSE
        # Only use log/loglog if values span many orders of magnitude
        # ============================================================
        configs = [("linear", lambda yy: yy, lambda v: v, 1.0)]

        # Only try log transforms if values are positive AND span > 3 orders of magnitude
        if np.all(y > 1e-12):
            y_ratio = float(np.max(y) / np.min(y)) if np.min(y) > 0 else 1.0
            if y_ratio > 1000:  # Spans > 3 orders of magnitude
                configs.append(("log", lambda yy: np.log(yy), lambda v: np.exp(v), 1.5))
                log_y = np.log(y)
                if np.all(log_y > 1e-12) and y_ratio > 1e6:  # Extremely large range
                    configs.append(("loglog", lambda yy: np.log(np.log(yy)),
                                   lambda v: np.exp(np.exp(v)), 3.0))

        best_coeffs = None
        best_backward = lambda v: v
        best_mse = float('inf')
        best_config_deg = best_deg

        for name, forward, backward, penalty in configs:
            if time.time() >= hard_deadline:
                break
            try:
                y_transformed = forward(y)
                if not np.isfinite(y_transformed).all():
                    continue

                # Fit in transformed space
                c_try = self._fit_cheby_degree(t_nodes, y_transformed, best_deg)

                # Validate in original space
                pred_t = self._cheby_eval_batch(c_try, t_nodes)
                pred_orig = backward(pred_t)

                if not np.isfinite(pred_orig).all():
                    continue

                mse = float(np.mean((pred_orig - y) ** 2)) * penalty

                if mse < best_mse:
                    best_mse = mse
                    best_coeffs = c_try
                    best_backward = backward
                    best_config_deg = best_deg

            except Exception:
                continue

        # Fallback if no config worked
        if best_coeffs is None:
            best_coeffs = self._fit_cheby_degree(t_nodes, y, best_deg)
            best_backward = lambda v: v

        c = best_coeffs
        bwd = best_backward

        def g(x, c=c, mid=mid, half=half, bwd=bwd):
            t = (float(x) - mid) / half
            if t > 1.0:
                t = 1.0
            elif t < -1.0:
                t = -1.0
            v = self._cheby_eval(c, t)
            return float(bwd(v))

        return g


##########################################################################


import unittest
from sampleFunctions import *
from tqdm import tqdm


class TestAssignment4(unittest.TestCase):

    def test_return(self):
        f = NOISY(0.01)(poly(1,1,1))
        ass4 = Assignment4()
        T = time.time()
        shape = ass4.fit(f=f, a=0, b=1, d=10, maxtime=5)
        T = time.time() - T
        self.assertLessEqual(T, 5)

    def test_delay(self):
        f = DELAYED(7)(NOISY(0.01)(poly(1,1,1)))

        ass4 = Assignment4()
        T = time.time()
        shape = ass4.fit(f=f, a=0, b=1, d=10, maxtime=5)
        T = time.time() - T
        self.assertGreaterEqual(T, 5)

    def test_err(self):
        f = poly(1,1,1)
        nf = NOISY(1)(f)
        ass4 = Assignment4()
        T = time.time()
        ff = ass4.fit(f=nf, a=0, b=1, d=10, maxtime=5)
        T = time.time() - T
        mse=0
        for x in np.linspace(0,1,1000):
            self.assertNotEqual(f(x), nf(x))
            mse+= (f(x)-ff(x))**2
        mse = mse/1000
        print(mse)






if __name__ == "__main__":
    unittest.main()
