def bulbs_condition(lightbulb_array, switch_location):
    """

    :param lightbulb_array:List of booleans representing lightbulb states (True for ON, False for OFF).
    :param switch_location: Index of the switch to change
    :return: A new list representing the updated state of the lightbulbs.
    """
    new_array = lightbulb_array[:] #   # create a copy of the input array to avoid changes in the original array
   #Turn the light on/off
    if new_array[switch_location] == True:
        new_array[switch_location] = False
    else:
        new_array[switch_location] = True
    #Turn the left light on/off if it is present
    if switch_location > 0:
        new_array[switch_location - 1] = not new_array[switch_location - 1]
    #Turn the right light on/off if it is present
    if switch_location < len(new_array)-1:
        new_array[switch_location + 1] = not new_array[switch_location + 1]
    return new_array


def lightbulb_solver_with_steps(lightbulb_array,target_array):

    def helper_to_find_steps(array_current_state, switch_location, used_switches):
        # If the current state matches the target, return True
        if array_current_state == target_array:
            return used_switches
        # If all switches have been checked without getting the target, return False
        if switch_location >= len(array_current_state):
            return [-1]
        # Try to change the current switch and proceed with recursion
        if not used_switches or switch_location > used_switches[-1]:
            array_new_state = bulbs_condition(array_current_state, switch_location)
            steps = helper_to_find_steps(array_new_state, switch_location + 1,used_switches + [switch_location])
            if steps != [-1]:
                return steps

        # Try to skip the current switch and proceed with recursion
        return helper_to_find_steps(array_current_state,switch_location + 1, used_switches)

    # Start the recursive from the first switch
    steps = helper_to_find_steps(lightbulb_array, 0,[])
    if steps != [-1]:
        return steps
    else:
        return [-1]

