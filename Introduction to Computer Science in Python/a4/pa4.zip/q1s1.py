def bulbs_condition(lightbulb_array, switch_location):
    """

    :param lightbulb_array:List of booleans representing lightbulb states (True for ON, False for OFF).
    :param switch_location: Index of the switch to change
    :return: A new list representing the updated state of the lightbulbs.
    """
    new_array = lightbulb_array[:] #   # create a copy of the input array to avoid changes in the original array
   #Turn the light on/off
    if new_array[switch_location] == True:
        new_array[switch_location] = False
    else:
        new_array[switch_location] = True
    #Turn the left light on/off if it is present
    if switch_location > 0:
        new_array[switch_location - 1] = not new_array[switch_location - 1]
    #Turn the right light on/off if it is present
    if switch_location < len(new_array)-1:
        new_array[switch_location + 1] = not new_array[switch_location + 1]
    return new_array


def lightbulb_solver(lightbulb_array,target_array):
    """
     Determines if the initial lightbulb state can be changed to the target state.
    :param lightbulb_array: List of booleans representing the target state.
    :param target_array:List of booleans representing the target state.
    :return:True if the target state can be achieved, False otherwise.
    """
    def helper_to_solver(array_current_state, switch_location):
        """
        Checks different ways to change the state of the array.
        :param array_current_state:Current state of the lightbulbs.
        :param switch_location:Index of the switch being evaluated.
        :return:True if the array can be changed to the target array, False otherwise.
        """
        # If the current state matches the target, return True
        if array_current_state == target_array:
            return True
        # If all switches have been checked without getting the target, return False
        if switch_location >= len(array_current_state):
            return False
        # Try to change the current switch and proceed with recursion
        array_new_state = bulbs_condition(array_current_state, switch_location)
        if helper_to_solver(array_new_state, switch_location + 1):
            return True
        # Try to skip the current switch and proceed with recursion
        return helper_to_solver(array_current_state,switch_location + 1)

    # Start the recursive from the first switch
    return helper_to_solver(lightbulb_array, 0)




