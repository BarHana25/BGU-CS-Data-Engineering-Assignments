def divide_pancakes_extended(pancakes, total_size):
    def find_diners(start_pancake, current_plate_size, used_pancakes, current_diners):
        if current_plate_size == total_size:
            return current_diners + 1
        if current_plate_size > total_size or start_pancake == len(pancakes):
            return current_diners

        not_take = find_diners(start_pancake + 1, current_plate_size, used_pancakes, current_diners)

        if start_pancake not in used_pancakes:
            used_pancakes.append(start_pancake)
            if current_plate_size + pancakes[start_pancake] == total_size:
                take = find_diners(0, 0, used_pancakes, current_diners + 1)
            else:
                take = find_diners(start_pancake + 1, current_plate_size + pancakes[start_pancake], used_pancakes,
                                   current_diners)
            used_pancakes.remove(start_pancake)
            return max(not_take, take)

        return not_take

    return find_diners(0, 0, [], 0)
