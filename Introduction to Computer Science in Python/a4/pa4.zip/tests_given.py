from q1s1 import lightbulb_solver
from q1s2 import lightbulb_solver_with_steps
from q2 import divide_pancakes_extended
from q3 import create_words

import ast
import inspect

def has_default_values(node, parent_function=None):
    """
    Recursively checks if the AST node or any of its children contain default values for parameters.

    Args:
        node (ast.AST): The AST node to check.
        parent_function (str): The name of the parent function.

    Returns:
        tuple: (bool, str, str, int, str) - True if the node or any of its children contain default values,
               variable name, the value it is set to, line number, and function name.
    """
    if isinstance(node, ast.FunctionDef):
        for arg, default in zip(node.args.args, node.args.defaults):
            if not isinstance(default, ast.Constant) or default.value is not None:
                return True, arg.arg, ast.dump(default), node.lineno, parent_function
    for child in ast.iter_child_nodes(node):
        has_default, var_name, value, lineno, func_name = has_default_values(child, parent_function)
        if has_default:
            return has_default, var_name, value, lineno, func_name
    return False, None, None, None, None

def check_no_default_values(func):
    """
    Checks if the given function or any called functions contain any default values for parameters.

    Args:
        func (function): The function to check.

    Raises:
        AssertionError: If the function or any called functions contain default values for parameters.
    """
    source = ast.parse(inspect.getsource(func))
    has_default, var_name, value, lineno, func_name = has_default_values(source, func.__name__)
    if has_default:
        raise AssertionError(
            f"""The function {func.__name__} contains default values for parameters.
                Variable: {var_name}, Value: {value}, Line number: {lineno}, Function name: {func_name}\n"""
        )

    # Check called functions
    for node in ast.walk(source):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            called_func_name = node.func.id
            try:
                called_func = eval(called_func_name)
                if inspect.isfunction(called_func):
                    check_no_default_values(called_func)
            except (NameError, TypeError):
                pass

def has_loops(node, parent_function=None):
    """
    Recursively checks if the AST node or any of its children contain loops or calls to loop-implementing built-ins.

    Args:
        node (ast.AST): The AST node to check.
        parent_function (str): The name of the parent function.

    Returns:
        tuple: (bool, str, int, str) - True if the node or any of its children contain loops or calls to loop-implementing built-ins,
               type of loop or built-in, line number, and function name.
    """
    # List of built-in functions and methods that implement loops internally
    loop_builtins = {
        'map', 'filter', 'reduce', 'sum', 'min', 'max', 'sorted', 'reversed', 'all', 'any', 'zip', 'enumerate',
        'list', 'set', 'dict', 'tuple', 'range', 'open', 'iter', 'next', 'join', 'split', 'replace', 'find', 'index',
        'count', 'extend', 'append', 'insert', 'remove', 'pop', 'clear', 'copy', 'update', 'keys', 'values', 'items'}

    if isinstance(node, (ast.For, ast.While, ast.In, ast.ListComp, ast.DictComp, ast.SetComp, ast.GeneratorExp, ast.comprehension, ast.Invert, ast.NotIn)):
        return True, type(node).__name__, node.lineno, parent_function

    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in loop_builtins:
        return True, f"builtin {node.func.id}", node.lineno, parent_function

    for child in ast.iter_child_nodes(node):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
            has_loop, loop_type, lineno, func_name = has_loops(child, child.name)
            if has_loop:
                return has_loop, loop_type, lineno, func_name
        else:
            has_loop, loop_type, lineno, func_name = has_loops(child, parent_function)
            if has_loop:
                return has_loop, loop_type, lineno, func_name

    return False, None, None, None


def check_no_loops(func):
    """
    Checks if the given function contains any loops or calls any functions that contain loops or loop-implementing built-ins.

    Args:
        func (function): The function to check.

    Raises:
        AssertionError: If the function contains loops or calls any functions that contain loops or loop-implementing built-ins.
    """
    source = ast.parse(inspect.getsource(func))
    has_loop, loop_type, lineno, func_name = has_loops(source)
    if has_loop:
        raise AssertionError(
            f"""The function {func.__name__} contains loops or calls functions that contain loops or loop-implementing built-ins. 
                Loop type: {loop_type}, Line number: {lineno}, Function name: {func_name}\n"""

                # Traceback:\n{''.join(traceback.format_list(traceback.extract_stack()[:-1]))}"""
        )

def test_lightbulb_solver():
    check_no_loops(lightbulb_solver)
    check_no_default_values(lightbulb_solver)
    # Existing Test Cases
    assert lightbulb_solver([False, False, False, False, False], [False, False, False, False, True]) == False
    assert lightbulb_solver([True, True], [False, True]) == False
    assert lightbulb_solver([True, False, False, False, False, False], [False, True, False, True, True, True]) == True
    assert lightbulb_solver([True, False, False], [True, False, True]) == True

    # Additional Test Cases
    assert lightbulb_solver([False, False, False], [False, False, False]) == True
    assert lightbulb_solver([True, True, True], [True, True, True]) == True
    assert lightbulb_solver([True, False, True], [False, True, False]) == True
    assert lightbulb_solver([False, True, False], [True, False, True]) == True

def test_lightbulb_solver_with_steps():
    check_no_loops(lightbulb_solver_with_steps)
    check_no_default_values(lightbulb_solver_with_steps)
    # Existing Test Cases
    assert lightbulb_solver_with_steps([True, False, True], [True, True, True]) == [0, 1, 2]
    assert lightbulb_solver_with_steps([True, False, False, False, False, False], [False, True, False, True, True, True]) == [0, 4]
    assert lightbulb_solver_with_steps([False, False, False, False, False], [False, False, False, False, True]) == [-1]

    # Additional Test Cases
    assert lightbulb_solver_with_steps([False, False, False], [False, False, False]) == []
    assert lightbulb_solver_with_steps([True, True, True], [True, True, True]) == []
    assert lightbulb_solver_with_steps([True, False, True], [False, True, False]) == [1]
    assert lightbulb_solver_with_steps([False, True, False], [True, False, True]) == [1]

def test_divide_pancakes_extended():
    check_no_loops(divide_pancakes_extended)
    check_no_default_values(divide_pancakes_extended)
    # Existing Test Cases
    assert divide_pancakes_extended([1, 1, 4, 2, 3, 3, 2, 5], 6) == 3
    assert divide_pancakes_extended([1, 2, 2, 2, 3], 5) == 2
    assert divide_pancakes_extended([10, 5, 5], 10) == 2

    # Additional Test Cases
    assert divide_pancakes_extended([1, 2, 3, 4, 5], 5) == 3
    assert divide_pancakes_extended([1, 1, 1, 1, 1], 2) == 2
    assert divide_pancakes_extended([6, 6, 6], 6) == 3
    assert divide_pancakes_extended([1, 2, 3, 4, 5], 10) == 1
    assert divide_pancakes_extended([1, 1, 1, 1, 1, 1], 3) == 2
    assert divide_pancakes_extended([2, 2, 2, 2, 2, 2], 4) == 3
    assert divide_pancakes_extended([5, 5, 5, 5, 5], 5) == 5
    assert divide_pancakes_extended([1, 2, 3, 4, 5, 6], 7) == 3
    assert divide_pancakes_extended([1, 1, 1, 1, 1, 1, 1, 1], 2) == 4
    assert divide_pancakes_extended([3, 3, 3, 3, 3, 3], 6) == 3

    assert divide_pancakes_extended([1, 2, 3, 4, 5, 6, 7, 8], 15) == 2

    assert divide_pancakes_extended([1, 1, 1, 1, 1, 1, 1, 1, 1, 1], 2) == 5
    assert divide_pancakes_extended([2, 3, 5, 7, 11, 13], 10) == 1

    assert divide_pancakes_extended([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], 3) == 4

    assert divide_pancakes_extended([4, 4, 4, 4, 4, 4, 4, 4], 8) == 4
    assert divide_pancakes_extended([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 19) == 2
    assert divide_pancakes_extended([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], 2) == 7
    assert divide_pancakes_extended([2, 4, 6, 8, 10, 12], 14) == 3

def test_create_words():
    check_no_loops(create_words)
    check_no_default_values(create_words)
    words = {'hi': 1, 'hello': 40, 'world': 10, 'this': 4, 'a': 6, 'test': 7}

    # Existing Test Cases
    assert create_words(words, ['h', 'e', 'l', 'o', 't', 'i', 's', 'w', 'r', 'd']) == 'world'
    assert create_words(words, ['h', 'e', 'l', 'l', 'o']) == 'hello'
    assert create_words(words, ['a', 't', 'e', 's', 't']) == 'test'
    assert create_words(words, ['x', 'y', 'z']) == ''

    # Additional Test Cases
    assert create_words(words, ['h', 'i']) == 'hi'
    assert create_words(words, ['t', 'h', 'i', 's']) == 'this'
    assert create_words(words, ['a']) == 'a'
    assert create_words(words, ['h', 'e', 'l', 'l', 'o', 'w', 'o', 'r', 'l', 'd']) == 'hello'
    assert create_words(words, ['t', 'e', 's', 't']) == 'test'
    assert create_words(words, ['h', 'e', 'l', 'l', 'o', 't', 'h', 'i', 's']) == 'hello'
    assert create_words(words, ['w', 'o', 'r', 'l', 'd']) == 'world'
    assert create_words(words, ['h', 'e', 'l', 'l', 'o', 'w', 'o', 'r', 'l', 'd', 't', 'e', 's', 't']) == 'hello'
    assert create_words(words, ['h', 'e', 'l', 'l', 'o', 'w', 'o', 'r', 'l', 'd', 't', 'e', 's', 't', 'a']) == 'hello'
    assert create_words(words, ['h', 'e', 'l', 'l', 'o', 'w', 'o', 'r', 'l', 'd', 't', 'e', 's', 't', 'a', 'b',
                                'c']) == 'hello'
    assert create_words(words,
                        ['h', 'e', 'l', 'l', 'o', 'w', 'o', 'r', 'l', 'd', 't', 'e', 's', 't', 'a', 'b', 'c', 'd', 'e',
                         'f']) == 'hello'
    assert create_words(words,
                        ['h', 'e', 'l', 'l', 'o', 'w', 'o', 'r', 'l', 'd', 't', 'e', 's', 't', 'a', 'b', 'c', 'd', 'e',
                         'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
                         'y', 'z']) == 'hello'

if __name__ == "__main__":
    test_lightbulb_solver()
    test_lightbulb_solver_with_steps()
    test_divide_pancakes_extended()
    test_create_words()
    print("All tests passed!")
