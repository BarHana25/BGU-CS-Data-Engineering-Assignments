def create_words(words, cards):
    """
    Finds the highest scoring word that can be created using the cards.
    :param words:A dictionary where keys are valid words and values are their scores.
    :param cards:A list of characters representing available letters.
    :return: The highest scoring word that can be formed using the letters in 'cards'.
    """
    def find_words(start_card, current_word, used_cards, best_word, max_score):
        """
        Checks all possible combinations of letters to form words.
        :param start_card:The starting index in the cards list.
        :param current_word:The word created so far during recursion.
        :param used_cards:A list indicating which cards have already been used.
        :param best_word: The best word found so far.
        :param max_score:The score of the best word found so far.
        :return:The word with the most points
        """
        # Check if the current word is valid and update score
        score = words.get(current_word, 0)
        best_word = current_word
        max_score = score
        # Stop if the index go over the number of cards
        if start_card >= len(cards):
            return best_word, max_score
        # Try to use the current card
        take_word, take_score = "", 0
        if not used_cards[start_card]:
            # Mark the current card as used
            used_cards[start_card] = True
            # Recurse with the current letter added to the word
            take_word, take_score =  find_words(0, current_word + cards[start_card], used_cards, best_word, max_score)
            # Backtrack and unmark the card as used
            used_cards[start_card] = False
            # Update the best word if a better score is found
            if take_score > max_score:
                max_score = take_score
                best_word = take_word

        # Skip the current card and move to the next one
        not_take_word, not_take_score = find_words(start_card + 1, current_word, used_cards, best_word, max_score)

        # Compare results and return the better scoring word
        if take_score > not_take_score:
            return take_word, take_score
        else:
            return not_take_word, not_take_score

    # create used_cards to keep track of which letters are used
    used_cards = [False] * len(cards)
    # Start the recursive search for the best word
    best_word, max_score = find_words(0, "", used_cards, "", 0)
    return best_word
