def divide_pancakes_extended(pancakes, total_size):
    """
    Determines the maximum number of diners using given pancakes,
     that each diner gets a plate with an equal total size.
    :param pancakes:List of integers representing pancake sizes.
    :param total_size:Integer representing the required size of each plate.
    :return:Integer representing the maximum number of diners that can be served.
    """
    def find_diners(start_pancake, current_plate_size, used_pancakes, current_diners):
        """
        Recursively checks combinations of pancakes to create plates that match to total size
        :param start_pancake: Index to start checking pancakes.
        :param current_plate_size: Current size of the plate being formed.
        :param used_pancakes: List of indices of pancakes already used.
        :param current_diners:Number of diners so far.
        :return: Maximum number of diners that can be served.
        """
        # if the current plate size matches the total size, count one diner.
        if current_plate_size == total_size:
            return current_diners + 1
        #If the size is more then the total size or no more pancakes are available, stop.
        if current_plate_size > total_size or start_pancake == len(pancakes):
            return current_diners
        # Option 1: Skip the current pancake and move to the next one.
        not_take = find_diners(start_pancake + 1, current_plate_size, used_pancakes, current_diners)
        # Option 2: Include the current pancake if it hasn't been used.
        if start_pancake not in used_pancakes:
            used_pancakes.append(start_pancake)
            # If to add this pancake completes a plate, reset plate size and increment diners.
            if current_plate_size + pancakes[start_pancake] == total_size:
                take = find_diners(0, 0, used_pancakes, current_diners + 1)
            else:# Otherwise, continue adding pancakes to the current plate.
                take = find_diners(start_pancake + 1, current_plate_size + pancakes[start_pancake], used_pancakes, current_diners)
            # Go back to explore other combinations.
            used_pancakes.remove(start_pancake)
            return max(not_take, take)
        # Return the result of skipping the current pancake.
        return not_take
    # Start the recursive search.
    return find_diners(0, 0, [], 0)
