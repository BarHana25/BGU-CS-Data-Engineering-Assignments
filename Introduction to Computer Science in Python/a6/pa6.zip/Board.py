from Cell import Cell

class Board:

    def __init__(self, board_width=5, board_height=5, snakes_ladders= {'L':{3:9, 5:11, 6:24},'S':{20:4, 16:2, 18:10}}):
        #board_width
        if board_width < 4:
            raise ValueError("Invalid value")
        if not isinstance(board_width, int):
            raise TypeError("Invalid type for one of the following argument: board_width, board_height, snakes_ladders")
        self.board_width = board_width
        #board_height
        if board_height < board_width:
            raise ValueError("Invalid type for one of the following argument: board_width, board_height, snakes_ladders")
        if not isinstance(board_height, int):
            raise TypeError ("Invalid type for one of the following argument: board_width, board_height, snakes_ladders")
        self.board_height = board_height
        #snakes_ladders
        if not isinstance(snakes_ladders, dict):
            raise TypeError("Invalid type for one of the following argument: board_width, board_height, snakes_ladders")
        if not snakes_ladders:
            raise TypeError("Invalid type for one of the following argument: board_width, board_height, snakes_ladders")
        if set(snakes_ladders.keys()) != {"S", "L"} or len(snakes_ladders) != 2:
            raise ValueError("Invalid value")
        for key, pairs in snakes_ladders.items():
            for start, end in pairs.items():
                if not isinstance(pairs, dict):
                    raise TypeError("Invalid type for one of the following argument: board_width, board_height, snakes_ladders")
                if key == "L" and start > end:
                    raise ValueError("Invalid value")
                if key == "S" and end > start:
                    raise ValueError("Invalid value")
                if end > self.board_width*board_height:
                    raise ValueError("Invalid value")
                if start < 1:
                    raise ValueError("Invalid value")
        self.snakes_ladders = snakes_ladders
        #size
        self.__size = board_width * board_height
        self.cells =[]
        self.create_grid()
        self.__grid = self.cells[0]
        self.current_cell_position = 0


    def create_grid(self):
        for i in range(1, self.__size +1):
            cell = Cell(i,'R')
            self.cells.append(cell)
        for i in range(0, len(self.cells)-1):
            self.cells[i].update_next(self.cells[i+1])

        ladders = self.snakes_ladders['L']
        for key, val in ladders.items():
            self.check_cell_type(val)
            for i in range(len(self.cells)-1):
                if self.cells[i].position == key:
                    self.cells[i].cell_type = 'L'
                    self.cells[i].update_leap(self.cells[val-1])
                    break

        snakes = self.snakes_ladders['S']
        for key, val in snakes.items():
            self.check_cell_type(val)
            for i in range(len(self.cells)-1):
                if self.cells[i].position == key:
                    self.cells[i].cell_type = 'S'
                    self.cells[i].update_leap(self.cells[val-1])
                    break

    def check_cell_type(self, position):
        return self.cells[position].cell_type

    def __iter__(self):
        self.current_cell_position = 0
        return self


    def __next__(self):
        if self.current_cell_position >= self.__size:
            raise StopIteration
        current_cell = self.cells[self.current_cell_position]
        self.current_cell_position = self.current_cell_position + 1
        return current_cell


    def __repr__(self):
        board_repr = ""
        ladder_snake_positions = {}  # Dictionary to map ladders and snakes to their destinations

        # Collect ladder and snake positions
        for cell in self:
            if cell.cell_type in {"L", "S"}:
                ladder_snake_positions[cell.position] = (
                    cell.leap.position,
                    cell.cell_type,
                )

        for row in range(self.board_height):
            row_repr = ""
            for col in range(self.board_width):
                cell_num = row * self.board_width + col + 1
                if cell_num in ladder_snake_positions:
                    target, cell_type = ladder_snake_positions[cell_num]
                    if cell_type == "L":
                        row_repr += f"[L{cell_num:02d}->{target:02d}]"
                    elif cell_type == "S":
                        row_repr += f"[S{cell_num:02d}->{target:02d}]"
                else:
                    row_repr += f"[{cell_num:02d}]"
            board_repr = row_repr + "\n" + board_repr  # Reverse row order to mimic game style
        return board_repr


    def get_grid(self):
        return self.__grid


    def __len__(self):
        return self.__size

