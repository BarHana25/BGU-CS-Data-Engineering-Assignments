
from Board import Board
from Dice import Dice
from Player import Player
from ADTs import MyQueue

class Game:
    def __init__(self, board_width = 5, board_height = 5, snakes_ladders = {'L':{3:9, 5:11, 6:24},'S':{20:4, 16:2, 18:10}}, game_players = ["Omri", "Tal"]):
        self.__dice = Dice()
        try:
            self.board = Board(
                board_width,
                board_height,
                snakes_ladders if snakes_ladders else {'L': {3: 9, 5: 11, 6: 24}, 'S': {20: 4, 16: 2, 18: 10}}
            )
        except (ValueError,TypeError) as e:
            print(f"{e} Invalid type for one of the following argument: board_width, board_height, snakes_ladders")
            print("Using default board arguments")
            self.board = Board(5, 5, snakes_ladders = {'L':{3:9, 5:11, 6:24},'S':{20:4, 16:2, 18:10}})

        try:
            if not isinstance(game_players, list):
                raise TypeError("game_players must be a list.")
            if len(game_players)<2:
                raise ValueError("game_players must contain at least 2 players.")
            if not all(isinstance(player, str) and player.isalpha() for player in game_players):
                raise ValueError("All players in game_players must be alphabetic strings.")
            self.__players = self.crate_players_list(game_players)

        except ValueError as e:
            print(e)
            print("Using default game_players arguments")
            self.__players = self.crate_players_list(["Omri", "Tal"])

        self.winner = None


    def crate_players_list(self, game_players):
        players = []
        for player in game_players:
            players.append(Player(player, self.board))
        return players

    def play_turn(self):
        for player in self.__players:
            roll = self.__dice.roll()
            print(f"{player.name} rolled a {roll}.")
            if player.move(roll):
                self.winner = player
                print(f"{player.name} reached the end and wins!")
                return True
        return False

    
    def run_game(self):
        print("Starting the game!")
        while not self.winner:
            if self.play_turn():
                break
        return self.winner, self.winner.num_turns


    def solve(self): #BFS
        queue = MyQueue()
        queue.enqueue((1, 0))
        visited = set()

        while not queue.is_empty():
            current_position, steps = queue.dequeue()
            if current_position >= len(self.board):
                print(f"Shortest path found in {steps} steps.")
                return steps
            if current_position in visited:
                continue
            visited.add(current_position)

            for roll in range(1, 7):
                next_position = current_position + roll
                if next_position >= len(self.board):
                    print(f"Player wins by rolling to position {next_position}.")
                    return steps + 1
                cell = self.board.cells[next_position - 1]
                if cell.leap:
                    next_position = cell.leap.position
                queue.enqueue((next_position, steps + 1))
        return None
            
    def __repr__(self):
        return f"Game(players={self.__players},\nboard={self.board}\n****winner={self.winner if self.winner else 'game is still going on….'}****)"


    

        
