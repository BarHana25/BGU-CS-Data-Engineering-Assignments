from Board import Board

class Player:
    def __init__(self, name, board):
        if not name:
            raise TypeError("name can't be empty")
        if not isinstance(name, str):
            raise TypeError("name must be form str type")
        if not name.isalpha():
            raise ValueError("name has non alphabet types")
        self.name = name

        if not isinstance(board, Board):
            raise TypeError("board must be from board type")
        self.board = board

        self.position = None
        self.num_turns = 0

    def __repr__(self):
        return f"Player(name={self.name}, position={self.position})"

    def move(self, roll):
        if not isinstance(roll, int):
            raise TypeError("roll must be an int")
        if roll > 6 or roll < 1:
            raise ValueError("roll must be between 1 to 6")
        if self.position is None:
            self.position = self.board.get_grid()
            print(f"Player initialized at position {self.position.position}")

        for _ in range(roll):
            print(self.position.next)
            if self.position.next:
                self.position = self.position.next
                print(f"Player moved to position {self.position.position}")
            else:
                print("Player reached the end of the board!")
                return True

        if self.position.leap:
            print(f"Player leaps to position {self.position.leap.position}")
            self.position = self.position.leap

        self.num_turns += 1
        print(f"Turn {self.num_turns} completed. Current position: {self.position.position}")
        return False
