import CellUpdateError
class Cell:

    def __init__(self, position, cell_type="R"):
        if not isinstance(position, int):
            raise TypeError("position must be from type int")
        self.position = position

        if not isinstance(cell_type, str):
            raise TypeError("cell_type must be from type str")
        if cell_type not in {"L", "S", "R"}:
            raise ValueError("cell_type must be one of the following: L,S,R")
        self.cell_type = cell_type

        self.next = None
        self.leap = None

    def update_next(self, next_cell):
        if self.next is not None:
            raise CellUpdateError
        if not isinstance(next_cell, Cell):
            raise TypeError("next_cell must be from type Cell")
        if next_cell.position != self.position + 1:
            raise ValueError("next_cell.position is smaller or bigger then self.position")
        self.next = next_cell


    def update_leap(self, leap):
        if not isinstance(leap, Cell):
            raise TypeError("leap must be from type Cell")
        if self.cell_type == 'R':
            raise CellUpdateError
        if self.cell_type == 'L' and leap.position <= self.position:
            raise CellUpdateError
        if self.cell_type == 'S' and leap.position >= self.position:
            raise CellUpdateError
        if leap.cell_type != 'R':
            raise CellUpdateError
        self.leap = leap

    def __repr__(self):
        if self.cell_type == 'R':
            return f"{self.position}:{self.cell_type}->"
        return f"{self.position}:{self.cell_type}->{self.leap or ' '}"


