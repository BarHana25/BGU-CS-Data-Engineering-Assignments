
def flip(pile, index):
  '''
   This function flips the pancakes in the pile from the start to the given index.
  :param pile: A list of numbers that shows the pancake sizes
  :param index: The place (index) to stop the flip (included).
  :return:
      list: A pile with the flipped pancakes.
      str: "invalid index" if the index is not correct
  '''

  if index < 0 or index > len(pile) - 1:  # Check if the index is valid
      return "invalid index"
  else:
      pile = pile[index::-1] + pile[index + 1:]  # Flip the pancakes
      return pile


def find_largest_pancake(pile, index):
    '''
    This function finds the biggest pancake in the pile until a given index.
    :param pile:A list of numbers that shows the pancake sizes.
    :param index:The limit (not included) to search the biggest pancake.
    :return:
        int: The position (index) of the biggest pancake.
        str: "invalid index" if the index is not correct.
        str: "pile is empty" if the pile has no pancakes.
    '''
    if index < 1 or index > len(pile):  # Check if the index is valid
        return "invalid index"
    elif not pile:  # Check if the pile is empty
        return "pile is empty"
    else:
        return pile.index(max(pile[:index]))  # Find the biggest pancake index


def pancake_sort(pile):
    '''
    This function sorts a pile of pancakes by size using the pancake flipping method.
    :param pile:  A list of numbers that shows the pancake sizes.
    :return:
         list: A new list with the pancakes sorted from smallest to largest.
    '''
    counter = 0
    for pancake in range(len(pile) - 2):
        idx_largest_pancake = find_largest_pancake(pile, len(pile) - pancake)  # Find the largest pancake
        max_first = flip(pile, idx_largest_pancake)  # Flip the largest pancake to the top
        counter += 1
        max_last = flip(max_first, len(pile) - counter)  # Flip the largest pancake to its correct position
        pile = max_last  # Update the pile
    return pile
