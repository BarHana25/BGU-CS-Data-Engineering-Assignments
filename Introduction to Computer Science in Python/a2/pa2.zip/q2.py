from q1 import *


def take_pancakes(pile, index_list):
    '''
     This function takes specific pancakes from the pile based on the given indices.
    :param pile: A list of numbers representing the pancake sizes.
    :param index_list: A list of indices specifying which pancakes to take
    :return:
        list: A list of pancakes taken from the pile in the specified order.
        str: "invalid index" if an index in index_list is not valid.
        str: "invalid pile" if the pile is empty.
    '''
    for i in index_list:
        if i < 0 or i > len(pile) - 1:  # Check if indices are valid
            return "invalid index"
    if pile == []:  # Check if the pile is empty
        return "invalid pile"
    else:
        index_list = pancake_sort(index_list)  # Sort indices
        index_list = index_list[::-1]  # Reverse indices
        pancakes_out = []
        for i in index_list:  # Take pancakes based on reversed indices
            val = pile.pop(i)
            pancakes_out.insert(0, val)  # Insert taken pancakes at the beginning
    return pancakes_out

def insert_pancakes(pile, pancakes):
    '''
    This function inserts pancakes from one list into another list while maintaining order.
    :param pile:A sorted list of pancake sizes.
    :param pancakes:A list of pancake sizes to insert into the pile.
    :return:
        list: The updated pile with all pancakes inserted in the correct order.
    '''
    pancakes = pancake_sort(pancakes)  # Sort the pancakes
    for p in pancakes:
        for pancake in range(len(pile)):  # Find the correct position in the pile
            if p <= pile[pancake]:  # Insert the pancake if it's smaller
                pile.insert(pancake, p)
                break
        else:
            pile.append(p)  # If no smaller position is found, append to the end

    return pile


def divide_pancakes(pile, total_size):
    '''
    This function divides a pile of pancakes into pairs such that the sum of
    each pair equals the given total size.
    :param pile: A list of numbers representing pancake sizes.
    :param total_size: The target sum for each pair
    :return:
        list: A list of pairs where the sum of each pair equals total_size.
        str: "invalid size" if the total_size is odd.
    '''
    if total_size % 2 != 0:  # Check if the total_size is valid
        return "invalid size"
    else:
        pile = pancake_sort(pile)  # Sort the pile for easier pairing
        new_piles = []
        used_pancakes = []
        for p in range(len(pile)):# skips what already used
          if p in used_pancakes:
            continue

          val_pancake = pile[p]
          partner = total_size - val_pancake

          for pancake in range(len(pile)): #finds the partner
              if pancake != p and pancake not in used_pancakes and pile[pancake]==partner:
                  new_piles.append([val_pancake, partner])
                  used_pancakes.append(p)
                  used_pancakes.append(pancake)
                  break

        return new_piles


