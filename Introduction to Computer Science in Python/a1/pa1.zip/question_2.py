# ************************ HOMEWORK 1 QUESTION 2 **************************
def question_2(tier, yearly_purchases, payment):
    # checks "Gold" tier and calculate the discount
    if tier == "Gold" and yearly_purchases >= 10 and payment > 1000:
        print(int(payment*0.7))
    elif tier == "Gold" and yearly_purchases > 5:
        print(int(payment*0.75))
    elif tier == "Gold":
        print(int(payment*0.8))
    # checks "Silver" tier and calculate the discount
    elif tier == "Silver" and yearly_purchases >= 15 and payment > 800:
        print(int(payment*0.8))
    elif tier == "Silver":
        print(int(payment*0.85))
    # checks "Bronze" tier and calculate the discount
    elif tier == "Bronze" and yearly_purchases >= 5 and payment >= 1200:
        print(int(payment*0.85))
    elif tier == "Bronze":
        print(int(payment*0.9))
    # checks no tier and calculate the discount
    elif tier == "" and payment > 1200:
        print(int(payment*0.95))
    # In case the client does not meet any criteria
    else:
        print(payment)
