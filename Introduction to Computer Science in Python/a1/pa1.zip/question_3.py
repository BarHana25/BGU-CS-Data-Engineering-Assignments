# ************************ HOMEWORK 1 QUESTION 3 **************************
def question_3(input_num):
    if input_num % 2 == 0 or input_num < 1:
        print("not a diamond")
    else:
        # Prints the top part of the diamond
        for i in range(input_num + 1):
            if i % 2 != 0:
              print(((input_num - i)//2)* " " + i*"*")
        for i in range(input_num - 2, 0, -1):
            if i % 2 != 0:
                print(((input_num - i)//2)* " " + i*"*")

