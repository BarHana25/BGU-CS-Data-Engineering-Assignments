def question_2(tier, yearly_purchases, payment):
    # Checks the customer type and other parameters and Calculates the discount that this club member is entitled to
    discounted_Price = 0
    # if tier == "Gold" and yearly_purchases >= 10 and payment > 1000:
    #     print(int(payment * 0.7))
    # elif tier == "Gold" and yearly_purchases > 5:
    #     print(int(payment * 0.75))
    # elif tier == "Gold":
    #     print(int(payment * 0.8))
    if tier == "Gold":
        discounted_Price = int(payment * 0.8)
        if yearly_purchases > 5:
            discounted_Price = int(payment * 0.75)
            if yearly_purchases >= 10 and payment > 1000:
                discounted_Price = int(payment * 0.7)

    elif tier == "Silver" and yearly_purchases >= 15 and payment > 800:
        print(int(payment * 0.8))
    elif tier == "Silver":
        print(int(payment * 0.85))
    elif tier == "Bronze" and yearly_purchases >= 5 and payment >= 1200:
        print(int(payment * 0.85))
    elif tier == "Bronze":
        print(int(payment * 0.9))
    elif tier == "" and payment > 1200:
        print(int(payment * 0.95))
    else:  # In case the client does not meet any criteria
        print(payment)
