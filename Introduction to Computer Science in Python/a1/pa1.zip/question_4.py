# ************************ HOMEWORK 1 QUESTION 4 **************************
def question_4(input_list):
    bomb_counter = 0
    safe_area_counter = 0
    for j in range(len(input_list)):
        for i in range(len(input_list[j])):
            if input_list[j][i] % 2 != 0:  # checks if the cell is a safe area
                safe_area_counter += 1
                # checks if the neighbors are bombs and makes sure that the indices are valid
                if j - 1 >= 0 and i - 1 >= 0 and input_list[j - 1][i - 1] % 2 == 0:
                    bomb_counter += 1
                if j - 1 >= 0 and input_list[j - 1][i] % 2 == 0:
                    bomb_counter += 1
                if j - 1 >= 0 and i + 1 < len(input_list[j]) and input_list[j - 1][i + 1] % 2 == 0:
                    bomb_counter += 1
                if i - 1 >= 0 and input_list[j][i - 1] % 2 == 0:
                    bomb_counter += 1
                if i + 1 < len(input_list[j]) and input_list[j][i + 1] % 2 == 0:
                    bomb_counter += 1
                if j + 1 < len(input_list) and i - 1 >= 0 and input_list[j + 1][i - 1] % 2 == 0:
                    bomb_counter += 1
                if j + 1 < len(input_list) and input_list[j + 1][i] % 2 == 0:
                    bomb_counter += 1
                if j + 1 < len(input_list) and i + 1 < len(input_list[j]) and input_list[j + 1][i + 1] % 2 == 0:
                    bomb_counter += 1

    if safe_area_counter == 0:
        print(safe_area_counter)
    else:
        average_bomb = bomb_counter / safe_area_counter
        result = round(average_bomb, 2)
        print(result)
