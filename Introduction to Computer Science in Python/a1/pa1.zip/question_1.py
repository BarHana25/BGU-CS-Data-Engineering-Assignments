# ************************ HOMEWORK 1 QUESTION 1 **************************
def question_1(x, a):
    # Calculates the numerator and denominator, divides between them and round the result to two digits after the point
    numerator = (a**2)*x+2*x-7
    denominator = x**(a%3)+3
    result = round(numerator/denominator, 2)
    print(result)
