import math

# Example Sequence Corpus
seq_corpus = {
    1: 'GCTTA_tGC:GXATC  CGTAGACffx:TYAGgytACGTMA',
    2: 'AGG. Ddfe::wscv',
    3: 'cl_yuCATGATGCGTACCAGGCTqwAGCATGCGTbbAGCTAxzvGCATGAC'
}


# Helper function
def codon_translator(codon):
    RNA_to_protien = {'UUU': 'F', 'UUC': 'F', 'UUA': 'L', 'UUG': 'L', 'UCU': 'S', 'UCC': 'S', 'UCA': 'S', 'UCG': 'S',
                      'UAU': 'Y', 'UAC': 'Y',
                      'UGU': 'C', 'UGC': 'C', 'UGG': 'W', 'CUU': 'L', 'CUC': 'L', 'CUA': 'L', 'CUG': 'L', 'CCU': 'P',
                      'CCC': 'P', 'CCA': 'P',
                      'CCG': 'P', 'CAU': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q', 'CGU': 'R', 'CGC': 'R', 'CGA': 'R',
                      'CGG': 'R', 'AUU': 'I',
                      'AUC': 'I', 'AUA': 'I', 'AUG': 'M', 'ACU': 'T', 'ACC': 'T', 'ACA': 'T', 'ACG': 'T', 'AAU': 'N',
                      'AAC': 'N', 'AAA': 'K',
                      'AAG': 'K', 'AGU': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R', 'GUU': 'V', 'GUC': 'V', 'GUA': 'V',
                      'GUG': 'V', 'GCU': 'A',
                      'GCC': 'A', 'GCA': 'A', 'GCG': 'A', 'GAU': 'D', 'GAC': 'D', 'GAA': 'E', 'GAG': 'E', 'GGU': 'G',
                      'GGC': 'G', 'GGA': 'G',
                      'GGG': 'G'}
    decoding = RNA_to_protien.get(codon, "stop")
    return decoding


####### Part A #########
def remove_punctuation(seq):
    """
    Removes punctuation marks from a given sequence.

    :param seq: A string representing a DNA/RNA sequence.
    :return: A string with punctuation marks replaced by spaces.
    """
    punctuation_narks = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    for char in seq:
        if char in punctuation_narks:
            seq = seq.replace(char, ' ') # Replace punctuation with a space
    return seq


def remove_invalid_letters(seq):
    """
    Removes invalid letters that are not part of DNA bases (A, T, G, C) from the sequence.

    :param seq: A string representing a DNA/RNA sequence.
    :return: A cleaned string with invalid letters removed.
    """
    new_seq = ""
    valid_letters = "ATGCatgc"
    for char in seq:
        if char in valid_letters and char.isalpha():
            new_seq += char # Add the valid letter to the result
        else:
            new_seq += " "
    return new_seq


def remove_spaces(seq):
    """
    Removes all spaces from the given sequence.

    :param seq: A string representing a DNA/RNA sequence.
    :return: A string with all spaces removed.
    """
    seq = seq.replace(" ", "")
    return seq


def capitalize_letters(seq):
    """
    Converts all letters in the sequence to uppercase.

    :param seq: A string representing a DNA/RNA sequence.
    :return: An uppercase version of the sequence.
    """
    seq = seq.upper()
    return seq


def proofreading(seq):
    """
    Splits a DNA sequence into codons (triplets), ensuring it starts with 'ATG'
    and ends with a stop codon ('TAA', 'TAG', or 'TGA').

    :param seq: A string representing a DNA sequence.
    :return: A list of codons (triplets) representing the processed sequence.
    """
    seq_list = []

    if "ATG" not in seq: # If the sequence doesn't have a start codon return an empty list
        return seq_list
    # Finds the first start codon and get the sequence after it
    for i in range(len(seq) - 2):
        if seq[i:i + 3] == "ATG":
            seq_list.append(seq[i:i + 3])
            remaining_seq = seq[i + 3:]
            break
    # Split the remaining sequence into triplets
    divided_seq_list = [seq_list[0]]
    for i in range(0, len(remaining_seq), 3):
        triple = remaining_seq[i:i + 3]
        if len(triple) == 3:
            divided_seq_list.append(triple)
    # Check for stop codons and delete what remains after it
    for t in range(len(divided_seq_list)):
        if divided_seq_list[t] == "TAA" or divided_seq_list[t] == "TAG" or divided_seq_list[t] == "TGA":
            divided_seq_list = divided_seq_list[:t + 1]
            break
    #if there is no stop codon add in the end TAA
    stop_codon = divided_seq_list[-1]
    if stop_codon != "TAA" and stop_codon != "TAG" and stop_codon != "TGA":
        divided_seq_list.append("TAA")

    return divided_seq_list


def transcript(func_seq):
    """
    Transcribes a DNA sequence into RNA by replacing 'T' with 'U'.

    :param func_seq: A list of DNA codons (e.g., ['ATG', 'GGC']).
    :return: A list of RNA codons (e.g., ['AUG', 'GGC']).
    """
    rna_seq = []
    for triple in func_seq:
        rna_seq.append(triple.replace("T", "U")) #  replace all 'T' with 'U'

    return rna_seq


def translate(rna_seq):
    """
    Translates an RNA sequence into its corresponding protein sequence.

    :param rna_seq: A list of RNA codons (e.g., ['AUG', 'GGC']).
    :return: A list of amino acids corresponding to the RNA sequence.
    """
    translate_seq = []
    for triple in rna_seq[:len(rna_seq) - 1]: #convert the RNA to a seq of amino acids
        translate_seq.append(codon_translator(triple))

    return translate_seq


def preprocessing(seq):
    """
    Cleans and processes a DNA sequence into a list of translated amino acids.

    :param seq: A string representing a DNA sequence.
    :return: A list of amino acids corresponding to the sequence.
    """
    #combines all the cleaning helpers to one function
    seq = remove_punctuation(seq)
    seq = remove_invalid_letters(seq)
    seq = remove_spaces(seq)
    seq = capitalize_letters(seq)
    seq = proofreading(seq)
    seq = transcript(seq)
    seq = translate(seq)
    return seq


###### Part B #######
def get_sequences_data(sequence_corpus):
    """
    Processes a sequence corpus to calculate the count of amino acids in each sequence.

    :param sequence_corpus: A dictionary where keys are sequence IDs and values are raw DNA sequences.
    :return: A dictionary where keys are sequence IDs and values are the count of amino acids.
    """
    sequences_data = {}
    amino_acids = ["F", "L", "I", "M", "V", "S", "P", "T", "A", "Y", "H", "Q", "N", "K", "D", "E", "C", "W", "R", "G"]

    for key, value in sequence_corpus.items():
        amino_list = preprocessing(value)

        counter_amino_acids = 0
        for amino in amino_list:
            if amino in amino_acids:
                counter_amino_acids += 1

        sequences_data[key] = counter_amino_acids

    return sequences_data


def create_inverted_index(sequence_corpus):
    """
    Creates an inverted index mapping amino acids to the sequences they appear in, along with their counts.

    :param sequence_corpus: A dictionary where keys are sequence IDs and values are raw DNA sequences.
    :return: A dictionary where keys are amino acids and values are dictionaries of sequence IDs and their counts.
    """
    inverted_index = {}
    amino_acids = ["F", "L", "I", "M", "V", "S", "P", "T", "A", "Y", "H", "Q", "N", "K", "D", "E", "C", "W", "R", "G"]

    for key, value in sequence_corpus.items():
        amino_list = preprocessing(value)

        amino_counter = {}
        for amino in amino_list:
            if amino in amino_acids:
                amino_counter[amino] = amino_counter.get(amino, 0) + 1

        for amino, amount in amino_counter.items():
            if amino not in inverted_index:
                inverted_index[amino] = {}
            inverted_index[amino][key] = amount

    return inverted_index


def add_to_data(inverted_index, sequences_data, seq_id, seq):
    """
    Adds a new sequence to the sequence corpus, updating both the inverted index and sequences data.

    :param inverted_index: A dictionary mapping amino acids to sequences and their counts.
    :param sequences_data: A dictionary mapping sequence IDs to amino acid counts.
    :param seq_id: An integer representing the ID of the new sequence.
    :param seq: A string representing the new DNA sequence.
    :return: Updated inverted index and sequences data.
    """
    seq = preprocessing(seq)
    amino_acids = ["F", "L", "I", "M", "V", "S", "P", "T", "A", "Y", "H", "Q", "N", "K", "D", "E", "C", "W", "R", "G"]

    for amino in seq:
        if amino in amino_acids:
            if amino not in inverted_index:
                inverted_index[amino] = {}
            inverted_index[amino][seq_id] =+ 1

    counter_amino_acids = 0
    for amino in seq:
        if amino in amino_acids:
            counter_amino_acids += 1
    sequences_data[seq_id] = counter_amino_acids

    return inverted_index, sequences_data


def remove_from_data(inverted_index, sequences_data, seq_id):
    """
    Removes a sequence from the sequence corpus, updating both the inverted index and sequences data.

    :param inverted_index: A dictionary mapping amino acids to sequences and their counts.
    :param sequences_data: A dictionary mapping sequence IDs to amino acid counts.
    :param seq_id: An integer representing the ID of the sequence to remove.
    :return: Updated inverted index and sequences data.
    """

    for amino in list(inverted_index.keys()):
        if seq_id in inverted_index[amino]: # Check if in the sequence ID there is the amino acid
            del inverted_index[amino][seq_id] # removes it
        if inverted_index[amino] == {}:
            del inverted_index[amino]

    if seq_id in sequences_data:
        del sequences_data[seq_id] # Remove the sequence ID from the sequence data
    return inverted_index, sequences_data


def preprocess_query(query):
    """
    Processes a query string into a tuple of amino acids.

    :param query: A string of amino acids separated by commas.
    :return: A tuple of amino acids.
    """

    new_query = tuple(query.split(",")) # Split the string by commas and converts it to a tuple
    return new_query


###### Part C #######
def calculate_aaf_isf(amino_acid, seq_id, inverted_index, sequences_data):
    """
    Calculates the AAF-ISF score for a specific amino acid in a given sequence.

    :param amino_acid: A string representing the amino acid.
    :param seq_id: An integer representing the sequence ID.
    :param inverted_index: A dictionary mapping amino acids to sequences and their counts.
    :param sequences_data: A dictionary mapping sequence IDs to amino acid counts.
    :return: A float representing the AAF-ISF score rounded to 3 decimal places.
    """
    total_num_of_seq = len(sequences_data)

    if amino_acid in inverted_index:  # Counts how many sequences contain this amino acid
        num_of_seq_containing_amino = len(inverted_index[amino_acid])
    else:
        num_of_seq_containing_amino = 0
    # Counts how many times the amino acid appears in the specific sequence
    if seq_id in inverted_index[amino_acid]:
        num_of_amino_in_seq = inverted_index[amino_acid][seq_id]
    else:
        num_of_amino_in_seq = 0

    total_num_os_amino_in_seq = sequences_data[seq_id]

    aaf = math.log2(total_num_of_seq / num_of_seq_containing_amino) # calculate the AFF
    isf = num_of_amino_in_seq / total_num_os_amino_in_seq # calculate the ISF
    aff_isf = aaf * isf #calculate the AFF-ISF

    return round(aff_isf, 3)


def get_scores_of_relevance_sequences(query, inverted_index, sequences_data):
    """
    Calculates relevance scores for all sequences based on a query of amino acids.

    :param query: A tuple of amino acids to search for.
    :param inverted_index: A dictionary mapping amino acids to sequences and their counts.
    :param sequences_data: A dictionary mapping sequence IDs to amino acid counts.
    :return: A dictionary where keys are sequence IDs and values are their relevance scores.
    """
    dict_of_scores = {}
    for amino_acid in query:
        if amino_acid not in inverted_index: # If the amino acid is not in the index, skip it
            continue
        for seq_id in inverted_index[amino_acid]: # Checks all sequences that contain this amino acid
            score = calculate_aaf_isf(amino_acid, seq_id, inverted_index, sequences_data) # Calculate the relevance score for the amino acid
            dict_of_scores[seq_id] = round(dict_of_scores.get(seq_id, 0) + score, 3)  # Add the score to the sequence's total
    return dict_of_scores


###### Part D #######
def menu(sequence_corpus):
    """
    Displays a menu for the user to interact with the sequence corpus,
    allowing for querying, adding, calculating scores, and deleting sequences.

    :param sequence_corpus: A dictionary where keys are sequence IDs and values are raw DNA sequences.
    :return: None
    """
    inverted_index = create_inverted_index(sequence_corpus)
    sequences_data = get_sequences_data(sequence_corpus)
    # Main menu loop
    while True:
        # Shows menu options to the user
        choice = input('Choose an option from the menu:\n\t(1) Insert a query.\n\t(2) Add sequence to sequence_corpus.\n\t(3) Calculate AAF-ISF Score for an amino acid in a sequence.\n\t(4) Delete a sequence from the sequence_corpus.\n\t(5) Exit.\nYour choice: ')

        if choice == "1":
            your_query = input("Write your query here: ")
            query = preprocess_query(your_query)
            while True:
                query_choice = input(
                    'Choose the type of results you would like to retrieve:\n\t(A) All relevant sequences.\n\t(B) The most relevant sequence.\n\t(C) Back to the main menu.\nYour choice: ')
                if query_choice == "A":
                    scores = get_scores_of_relevance_sequences(query, inverted_index, sequences_data)
                    for seq_id, score in scores.items():
                        print(f"{seq_id} : {score}")
                elif query_choice == "B":
                    scores = get_scores_of_relevance_sequences(query, inverted_index, sequences_data)
                    max_score = max(scores.values())
                    for key, value in scores.items():
                        if value == max_score:
                            seq_id = key
                            break
                    print("The most relevant sequence is", seq_id, "with a score of", max_score)
                elif query_choice == "C":
                    break
                else:
                    print("Invalid choice. Please select a valid option.")


        elif choice == "2":
            # Add a new sequence to the dataset
            while True:
                seq_id = int(input("Insert the sequence ID: "))
                if seq_id in sequences_data:
                    print("The sequence ID", seq_id, "is already in sequence_corpus.")
                else:
                    break
            seq = input("Insert the sequence itself: ")
            updated_inverted_index, updated_sequences_data = add_to_data(inverted_index, sequences_data, seq_id, seq)
            inverted_index = updated_inverted_index
            sequences_data = updated_sequences_data
            print("Sequence", seq_id, "was successfully added!")


        elif choice == "3":
            # Calculate a score for a specific sequence and amino acid
            while True:
                seq_id = int(input("Insert the sequence ID: "))
                if seq_id not in sequences_data:
                    print("The sequence ID",seq_id,"is not in sequence_corpus.")
                else:
                    break

            while True:
                amino_acid = input("Insert an amino acid: ")
                if amino_acid not in inverted_index:
                    print("The amino acid", amino_acid, "is not in sequence_corpus.")
                else:
                    break

            score = calculate_aaf_isf(amino_acid, seq_id, inverted_index, sequences_data)
            print("AAF-ISF of the amino acid", amino_acid, "in sequence", seq_id, "is:", score)

        elif choice == "4":
            # Remove a sequence from the dataset
            while True:
                seq_id = int(input("Insert the sequence ID: "))
                if seq_id in sequences_data:
                    inverted_index, sequences_data = remove_from_data(inverted_index, sequences_data, seq_id)
                    print("Sequence", seq_id, "was successfully deleted.")
                    break
                else:
                    print("The sequence ID", seq_id, "is not in sequence_corpus.")
        # Exit from the program
        elif choice == "5":
            break
        # Handle invalid input
        else:
            print("Invalid choice. Please select a valid option.")

