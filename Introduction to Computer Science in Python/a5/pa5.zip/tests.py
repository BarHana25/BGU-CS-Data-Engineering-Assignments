import unittest
import time
from Angry import Angry
from Mood import Mood
from Personality import Personality
from Angry import Angry
from Explosive import Explosive
from Furious import Furious
from Calm import Calm
from Chill import Chill
from TypeB import TypeB
from TypeA import TypeA
from Customer import Customer
from Dish import Dish
from LeastPatienceCustomerServingStrategy import LeastPatienceCustomerServingStrategy
from LongestWaitingTimeServingStrategy import LongestWaitingTimeServingStrategy
from ArrivalTimeServingStrategy import ArrivalTimeServingStrategy

class TestsForSmallClasses(unittest.TestCase):

    def setUp(self):
        self.Cust1 = Customer("1",mood = Angry(),personality= TypeB(),initial_patience=90, arrive_time=0)
        self.Cust2 = Customer("2", mood=Calm(), personality=TypeA(), initial_patience=70, arrive_time=10)
        self.Cust3 = Customer("3", mood=Explosive(), personality=TypeA(), initial_patience=100, arrive_time=5)
        self.Cust4 = Customer("4", mood=Furious(), personality=TypeB(), initial_patience=90, arrive_time=0)
        self.Cust5 = Customer("5", mood=Chill(), personality=TypeB(), initial_patience=100, arrive_time=3)
        self.Cust6 = Customer("1", mood=Angry(), personality=TypeB(), initial_patience=100, arrive_time=0)
        self.Cust7 = Customer("2", mood=Calm(), personality=TypeA(), initial_patience=100, arrive_time=0)
        self.Cust8 = Customer("3", mood=Explosive(), personality=TypeA(), initial_patience=100, arrive_time=0)
        self.Cust9 = Customer("4", mood=Furious(), personality=TypeB(), initial_patience=100, arrive_time=0)
        self.Cust10 = Customer("5", mood=Chill(), personality=TypeB(), initial_patience=100, arrive_time=0)

    def test_get_waiting_time(self):
        current_time = 10
        self.assertEqual(self.Cust1.get_waiting_time(current_time),10)
        self.assertEqual(self.Cust2.get_waiting_time(current_time), 0)
        self.assertEqual(self.Cust3.get_waiting_time(current_time), 5)
        self.assertEqual(self.Cust4.get_waiting_time(current_time), 10)
        self.assertEqual(self.Cust5.get_waiting_time(current_time), 7)

    def test_get_mood(self):
        waiting_time = 130
        self.Cust1.update(waiting_time)
        self.Cust2.update(waiting_time)
        self.Cust3.update(waiting_time)
        self.Cust4.update(waiting_time)
        self.Cust5.update(waiting_time)
        self.assertIsInstance(self.Cust1.get_mood(),Furious)
        #self.assertIsInstance(self.Cust2.get_mood(),Angry)
        self.assertIsInstance(self.Cust3.get_mood(),Explosive)
        self.assertIsInstance(self.Cust4.get_mood(),Explosive)
        self.assertIsInstance(self.Cust5.get_mood(),Calm)

    def test_get_patience(self):
        waiting_time = 20
        self.Cust6.update(waiting_time)
        self.Cust7.update(waiting_time)
        self.Cust8.update(waiting_time)
        self.Cust9.update(waiting_time)
        self.Cust10.update(waiting_time)
        self.assertEqual(self.Cust6.get_patience(),94.29)
        self.assertEqual(self.Cust7.get_patience(),97.57)
        self.assertEqual(self.Cust8.get_patience(), 91.84)
        self.assertEqual(self.Cust9.get_patience(), 88.58)
        self.assertEqual(self.Cust10.get_patience(), 98.78)

    def test_select_select_next_order(self):
        Cust11 = Customer("1", mood=Angry(), personality=TypeB(), initial_patience=90)
        time.sleep(1)
        Cust12 = Customer("2", mood=Calm(), personality=TypeA(), initial_patience=89)
        time.sleep(1)
        Cust13 = Customer("3", mood=Explosive(), personality=TypeA(), initial_patience=100)
        time.sleep(1)
        Cust14 = Customer("4", mood=Furious(), personality=TypeB(), initial_patience=90)
        time.sleep(1)
        Cust15 = Customer("5", mood=Chill(), personality=TypeB(), initial_patience=60)
        time.sleep(1)
        Dish11 = Dish()
        Dish12 = Dish()
        Dish13 = Dish()
        Dish14 = Dish()
        Dish15 = Dish()
        orders1 = {1: (Cust11, Dish11), 3: (Cust13, Dish13), 4: (Cust14, Dish14), 2: (Cust12, Dish12),
                   5: (Cust15, Dish15)}
        strategy1 = LeastPatienceCustomerServingStrategy()
        strategy2 = LongestWaitingTimeServingStrategy()
        strategy3 = ArrivalTimeServingStrategy()
        self.assertEqual(strategy1.select_next_order(orders1),5)
        self.assertEqual(strategy2.select_next_order(orders1), 1)
        self.assertEqual(strategy3.select_next_order(orders1), 1)

if __name__ == '__main__':
    unittest.main()


