from abc import ABC, abstractmethod
class Personality:
    @abstractmethod
    def adjust_mood(self, mood, waiting_time):
        pass

    @abstractmethod
    def __repr__(self):
        pass
