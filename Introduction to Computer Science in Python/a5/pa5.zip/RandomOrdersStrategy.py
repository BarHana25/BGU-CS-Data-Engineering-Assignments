from random import choices

from Explosive import Explosive
from Calm import Calm
from Chill import Chill
from Angry import Angry
from Furious import Furious
from TypeA import TypeA
from TypeB import TypeB
from OrdersStrategy import OrdersStrategy
import random
from Customer import Customer
from Dish import Dish
class RandomOrdersStrategy(OrdersStrategy):
    def __init__(self, max_dishes, max_ingredients, ingredients, n_orders=-1):
        self.current = 0
        self.n_orders = n_orders
        self.max_dishes = max_dishes
        self.ingredients = ingredients
        self.max_ingredients = max_ingredients


    def __iter__(self):
        self.current = 0
        return self

    def __next__(self):
        if self.n_orders >= self.current:
            raise StopIteration
        orders = []
        num_of_dishes = random.randint(0, self.max_dishes)
        for d in range(num_of_dishes):
            num_of_ingredients = random.randint(1, self.max_ingredients)
            dish_ingredient = random.choices(self.ingredients, k =num_of_ingredients)
            dish = Dish(dish_ingredient)
            customers_mood = random.choice([Explosive, Calm, Chill, Angry, Furious])
            customer_personality = random.choice([TypeA, TypeB])
            customer = Customer(f"customer_{self.current + 1}", customers_mood, customer_personality)
            client = (customer, dish)
            orders.append(client)
        self.current +=1
        return orders




