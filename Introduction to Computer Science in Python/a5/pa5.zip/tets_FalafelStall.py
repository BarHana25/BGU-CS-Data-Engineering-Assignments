import unittest
import time
from Angry import Angry
from Mood import Mood
from Personality import Personality
from Angry import Angry
from Explosive import Explosive
from Furious import Furious
from Calm import Calm
from Chill import Chill
from TypeB import TypeB
from TypeA import TypeA
from Customer import Customer
from Dish import Dish
from LeastPatienceCustomerServingStrategy import LeastPatienceCustomerServingStrategy
from LongestWaitingTimeServingStrategy import LongestWaitingTimeServingStrategy
from ArrivalTimeServingStrategy import ArrivalTimeServingStrategy
from FalafelStall import FalafelStall
from exceptions import NoSuchIngredientException
from exceptions import NotCustomerDishException
from exceptions import NoSuchOrderException
from exceptions import OrderOutOfBoundsException

class TestFalafelStall(unittest.TestCase):

    def setUp(self):
        self.Cust11 = Customer("1", mood=Angry(), personality=TypeB(), initial_patience=90)
        time.sleep(1)
        self.Cust12 = Customer("2", mood=Calm(), personality=TypeA(), initial_patience=89)
        time.sleep(1)
        self.Cust13 = Customer("3", mood=Explosive(), personality=TypeA(), initial_patience=100)
        time.sleep(1)
        self.Cust14 = Customer("4", mood=Furious(), personality=TypeB(), initial_patience=90)
        time.sleep(1)
        self.Cust15 = Customer("5", mood=Chill(), personality=TypeB(), initial_patience=60)
        time.sleep(1)
        self.Dish11 = Dish()
        self.Dish12 = Dish()
        self.Dish13 = Dish()
        self.Dish14 = Dish()
        self.Dish15 = Dish()
        self.Dish11.ingredients = ["pita", "falafel", "falafel", "falafel", "hazil"]
        self.Dish12.ingredients = ["pita", "falafel", "hazil"]
        self.Dish13.ingredients = ["pita", "tahini", "falafel", "falafel"]
        self.Dish14.ingredients = ["pita", "tahini", "harif", "falafel","falafel"]
        self.Dish15.ingredients = ["falafel", "falafel"]
        self.Dish_for_serving = Dish()
        self.Dish_for_serving.ingredients = ["pita", "falafel", "falafel", "falafel", "hazil"]
        self.Dish_for_serving2 = Dish()
        self.Dish_for_serving2.ingredients = ["falafel", "falafel"]
        ingredient_prices1 = {"pita": 10, "humus": 5, "tahini": 3, "hazil": 3, "salat": 5, "harif": 3, "falafel": 5}
        # orders1 = {1: (Cust11, Dish11),2: (Cust12, Dish12), 3: (Cust13, Dish13),4:(Cust15, Dish15)}
        self.falafelstall1 = FalafelStall(LeastPatienceCustomerServingStrategy(), ingredient_prices1)

    def test_order(self):
        self.assertEqual(self.falafelstall1.order(self.Cust11,self.Dish11),1)
        self.assertEqual(self.falafelstall1.order(self.Cust12, self.Dish12), 2)
        self.assertEqual(self.falafelstall1.order(self.Cust13, self.Dish13), 3)
        self.assertEqual(self.falafelstall1.order(self.Cust15, self.Dish15), 4)

    def test_get_next_order_id(self):
        self.falafelstall1.order(self.Cust11, self.Dish11)
        self.falafelstall1.order(self.Cust12, self.Dish12)
        self.falafelstall1.order(self.Cust13, self.Dish13)
        self.falafelstall1.order(self.Cust15, self.Dish15)
        self.assertEqual(self.falafelstall1.get_next_order_id(),4)

    def test_get_earning(self):
        self.falafelstall1.order(self.Cust11, self.Dish11)
        self.falafelstall1.order(self.Cust12, self.Dish12)
        self.falafelstall1.order(self.Cust13, self.Dish13)
        self.falafelstall1.order(self.Cust15, self.Dish15)
        self.falafelstall1.serve_dish(1,self.Dish_for_serving)
        self.falafelstall1.serve_dish(4, self.Dish_for_serving2)
        self.assertEqual(self.falafelstall1.get_earning(),38)


if __name__ == '__main__':
    unittest.main()
