from ServingStrategy import ServingStrategy
from exceptions import OrderOutOfBoundsException


class LeastPatienceCustomerServingStrategy(ServingStrategy):
    def select_next_order(self, orders):
        super().select_next_order(orders)
        patience_dict  = {order_id: customer.get_patience() for order_id, (customer, dish) in orders.items()}
        return min(patience_dict, key= patience_dict.get)