from Mood import Mood


class Calm(Mood):
    def __init__(self, strength=2):
        self.strength = strength

    def get_patience_factor(self, waiting_time):
        return round((1.05 ** (waiting_time / 5)) * self.strength, 2)

    def __repr__(self):
        return "Calm"



