from ServingStrategy import ServingStrategy
from exceptions import OrderOutOfBoundsException


class LongestWaitingTimeServingStrategy(ServingStrategy):
    def select_next_order(self, orders):
        super().select_next_order(orders)
        waiting_dict = {order_id: customer.get_waiting_time() for order_id, (customer, dish) in orders.items()} #לסדר את המילון
        return max(waiting_dict, key= waiting_dict.get)


