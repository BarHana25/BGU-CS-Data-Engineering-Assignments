from OrdersStrategy import OrdersStrategy


class FixedOrdersStrategy(OrdersStrategy):
    def __init__(self, lst_orders):
        self.lst_orders = lst_orders
        self.index = 1

    def __iter__(self):
        self.index = 1
        return self

    def __next__(self):
        if self.index >= len(self.lst_orders):
            raise StopIteration
        order = self.lst_orders[self.index -1]
        self.index += 1
        return order
