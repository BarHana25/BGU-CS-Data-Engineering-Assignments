from exceptions import NoSuchIngredientException, NoSuchOrderException, NotCustomerDishException, \
    OrderOutOfBoundsException
from Dish import Dish


class FalafelStall:
    def __init__(self, strategy, ingredient_prices):
        self.__orders = {}
        self.strategy = strategy
        self.ingredient_prices = ingredient_prices
        self.__money = 0
        self.order_counter = 0


    def order(self, customer, dish):
        for ingredient in dish.get_ingredients():
            if ingredient not in self.ingredient_prices:
                raise NoSuchIngredientException(ingredient)
        self.order_counter += 1
        self.__orders[self.order_counter] = (customer, dish)


    def get_next_order_id(self):
        if not self.__orders:
            raise OrderOutOfBoundsException
        return self.strategy.select_next_order(self.__orders)

    def serve_dish(self, order_id, dish):
        if order_id not in self.__orders.keys():
            raise NoSuchOrderException(order_id)

        customers_dish = self.__orders[order_id][1]
        if dish == customers_dish:
            self.__money =+ self.calculate_cost(dish)
        else:
            raise NotCustomerDishException(dish, customers_dish)

    def remove_order(self, order_id):
        if order_id not in self.__orders:
            raise NoSuchOrderException(order_id)
        else:
            del self.__orders[order_id]

    def get_order(self, order_id):
        if order_id not in self.__orders:
            raise NoSuchOrderException(order_id)
        return self.__orders.get(order_id)

    def calculate_cost(self, dish):
        dish_cost = 0
        for ingredient in dish.get_ingredients():
            if ingredient in self.ingredient_prices:
                dish_cost =+ self.ingredient_prices[ingredient]
            else:
                raise NoSuchIngredientException(ingredient)

    def get_orders(self):
        return self.__orders

    def get_earning(self):
        return self.__money
