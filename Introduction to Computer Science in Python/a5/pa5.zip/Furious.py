from Mood import Mood


class Furious(Mood):

    def __init__(self, strength=2):
        self.strength = strength

    def get_patience_factor(self, waiting_time):
        return round((1.3 ** (waiting_time / 5)) * self.strength * 2, 2)

    def __repr__(self):
        return "Furious"

