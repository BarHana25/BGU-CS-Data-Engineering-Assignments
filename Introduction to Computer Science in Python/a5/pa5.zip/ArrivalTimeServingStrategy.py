
from ServingStrategy import ServingStrategy


class ArrivalTimeServingStrategy(ServingStrategy):
    def select_next_order(self, orders):
        super().select_next_order(orders)

        return min(orders.keys())




