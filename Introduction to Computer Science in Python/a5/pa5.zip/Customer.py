import time




class Customer:
    def __init__(self, name, mood, personality, initial_patience=100, arrive_time=None):
        self.name = name
        self.__mood = mood
        self.personality = personality
        self.__patience = initial_patience
        self.initial_patience = initial_patience
        if arrive_time is None:
            self.arrive_time = int(time.time())
        else:
            self.arrive_time = arrive_time

    def get_mood(self):
        return self.__mood

    def get_waiting_time(self, current_time=None):
        if current_time is None:
            current_time = int(time.time())
        return current_time - self.arrive_time

    def get_patience(self):
        return round(self.__patience, 2)

    def update(self, waiting_time=None):
        if waiting_time is None:
           waiting_time =  self.get_waiting_time()
        self.__patience =- self.__mood.get_patience_factor(waiting_time)
        self.__mood = self.personality.adjust_mood(self.__mood, waiting_time)

    def __repr__(self):
        customer_name = f"name: {self.name}"
        customer_mood = f"mood: {self.__mood}"
        customer_personality = f"personality: {self.personality}"
        customer_patience = f"patience: {self.__patience}"

        max_len = max(len(customer_name), len(customer_mood), len(customer_personality), len(customer_patience))
        asterisk_row = "*" * (max_len + 4)

        return f"{asterisk_row}\n* {customer_name}{' ' * (max_len - len(customer_name) + 1)}*\n* {customer_mood}{' ' * (max_len - len(customer_mood) + 1)}*\n* {customer_personality}{' ' * (max_len - len(customer_personality) + 1)}*\n* {customer_patience}{' ' * (max_len - len(customer_patience) + 1)}*\n{asterisk_row}"


