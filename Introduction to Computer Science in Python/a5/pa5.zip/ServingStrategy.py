from abc import ABC, abstractmethod
from exceptions import OrderOutOfBoundsException


class ServingStrategy:
    @abstractmethod
    def select_next_order(self, orders):
        if not orders:
            raise OrderOutOfBoundsException
