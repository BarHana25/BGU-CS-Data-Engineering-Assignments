from unittest import TestCase
from TypeA import TypeA
from Calm import Calm
from Angry import Angry
from Furious import Furious
from Explosive import Explosive

class TestTypeA(TestCase):
    def setUp(self):
        self.type_a = TypeA()

class TestAdjustMood(TestTypeA):
    def test_adjust_mood_to_explosive(self):
        mood = Calm()
        new_mood = self.type_a.adjust_mood(mood, 42)
        self.assertIsInstance(new_mood, Explosive, "Mood should change to Explosive after 42 seconds")

    def test_adjust_mood_to_furious(self):
        mood = Calm()
        new_mood = self.type_a.adjust_mood(mood, 33)
        self.assertIsInstance(new_mood, Furious, "Mood should change to Furious after 33 seconds")

    def test_adjust_mood_to_angry(self):
        mood = Calm()
        new_mood = self.type_a.adjust_mood(mood, 21)
        self.assertIsInstance(new_mood, Angry, "Mood should change to Angry after 21 seconds")

    def test_no_mood_change(self):
        mood = Calm()
        new_mood = self.type_a.adjust_mood(mood, 10)
        self.assertIs(new_mood, mood, "Mood should not change for waiting time of 10 seconds")

class TestRepr(TestTypeA):
    def test_repr(self):
        self.assertEqual(repr(self.type_a), "TypeA")






