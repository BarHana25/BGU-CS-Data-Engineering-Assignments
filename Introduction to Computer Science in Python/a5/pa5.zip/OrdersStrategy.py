from abc import ABC, abstractmethod

class OrdersStrategy:
    @abstractmethod
    def __init__(self, lst_orders):
        pass
    @abstractmethod
    def __iter__(self):
        pass
    @abstractmethod
    def __next__(self):
        pass