import copy
import time
from Dish import Dish
from FalafelStall import FalafelStall
from exceptions import NoSuchIngredientException, NotCustomerDishException, NoSuchOrderException


class Game:
    def __init__(self, orders_strategy, serving_strategy, ingredient_prices):
        self.orders_strategy = orders_strategy
        self.serving_strategy = serving_strategy
        self.ingredient_prices  = ingredient_prices
        self.__game_start = int(time.time())
        self.__lives = 3
        self.ingredient_dictionary = { 0: "green salad",
                                       1: "falafel",
                                       2: "french fries",
                                       3: "coleslaw",
                                       4: "fried eggplants",
                                       5: "tachina",
                                       6: "humus" }

    def get_lives(self):
        return self.__lives

    def get_game_duration(self, current_time=None):
        if current_time is None:
            current_time = int(time.time())
        return current_time - self.__game_start

    def run(self):
        falafel_stall = FalafelStall(self.serving_strategy, self.ingredient_prices)
        for orders in self.orders_strategy:
            for order in orders:
                if self.__lives <= 0:
                    break
                customer, dish = order
                falafel_stall.order(customer, dish)

                if falafel_stall.get_orders():
                    current_order_id = falafel_stall.get_next_order_id()
                    current_order = falafel_stall.get_order(current_order_id)
                    succeed = False
                    while not succeed:
                        print("Customer:")
                        print(current_order[0])
                        print ("Dish:", current_order[1])

                        print("Insert ingredients: ")
                        for i, ingredient in self.ingredient_dictionary.items():
                            print(f"{i}: {ingredient}")
                        try:
                            choice_of_ingredients = input().split(' ')
                        except StopIteration:
                            print(f"Game Over\n score: {falafel_stall.get_earning()}")
                            break
                        dish_ingredients = [self.ingredient_dictionary.get(int(i),"") for i in choice_of_ingredients]
                        the_served_dish = Dish(dish_ingredients)
                        try:
                            falafel_stall.serve_dish(current_order_id, the_served_dish)
                            falafel_stall.remove_order(current_order_id)
                            succeed = True
                        except NoSuchIngredientException as e:
                            print(f"Failed to create a Dish\n,{e},\nplease retry.")
                        except NotCustomerDishException as e:
                            print(f"Failed to serve a Dish to customer\n{e}")
                        except NoSuchOrderException as e:
                            print(e)

                        orders_copy = copy.copy(falafel_stall.get_orders())
                        for order_id, (customer, dish) in orders_copy.items():
                             customer.update()
                             customer_patience = customer.get_patience()
                             if customer_patience <= 0:
                                 falafel_stall.remove_order(current_order_id)
                                 self.__lives =- 1
        print(f"Game Over\n score: {falafel_stall.get_earning()}")

















