from unittest import TestCase
from Dish import Dish

class TestDish(TestCase):
    def setUp(self):
        self.dish_1 = Dish(["falafel", "humus", "green salad"])
        self.dish_2 = Dish(["falafel", "humus", "green salad"])
        self.dish_3 = Dish(["falafel", "humus"])

class TestGetIngredients(TestDish):
    def get_ingredients(self):
        self.assertEqual(self.dish_1.get_ingredients(), ["falafel", "humus", "green salad"])

class TestAddIngredients(TestDish):
    def test_add_ingredient(self):
        self.dish_3.add_ingredient("salad")
        self.assertEqual(self.dish_3.get_ingredients(), ["falafel", "humus", "salad"])

class TestEQ(TestDish):
    def test_eq(self):
        self.assertNotEqual(self.dish_1, self.dish_3)

class TestRepr(TestDish):
    def test_repr(self):
        self.assertEqual(repr(self.dish_1), "* falafel, humus, salad *")



