class Dish:
    def __init__(self, ingredients=None):
        self.__ingredients = ingredients

    def add_ingredient(self, ingredient):
        self.__ingredients.append(ingredient)

    def get_ingredients(self):
        return self.__ingredients

    def __eq__(self, other):
        if not isinstance(other, Dish):
            return False
        if len(self.__ingredients) != len(other.__ingredients):
            return False
        is_eq = [False]*len(self.__ingredients)
        for i in self.__ingredients:
            for j in other.__ingredients:
                if self.__ingredients[i] == other.__ingredients[j]:
                    is_eq[i] = True
        if all(is_eq):
            return True
        else:
            return False

    def __repr__(self):
        return f"* {', '.join(self.__ingredients)} *"
