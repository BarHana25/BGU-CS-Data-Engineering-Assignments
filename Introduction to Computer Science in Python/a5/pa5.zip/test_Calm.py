import unittest
from symtable import Class
from unittest import TestCase

from Calm import Calm


class TestCalm(TestCase):
    def setUp(self):
        self.calm = Calm()

class TestInit(TestCalm):
    def test_initial_strength(self):
        self.assertEqual(self.calm.strength, 2, "Strength should default to 2")

    def test_custom_initialization(self):
        calm = Calm(strength=5)
        self.assertEqual(calm.strength, 5, "Strength should be initialized to 5")

class TestGetPatience(TestCalm):
    def test_get_patience_factor_depends_on_waiting_time(self):
        expected_factor = round((1.05 ** (10 / 5)) * 2, 2)
        self.assertEqual(self.calm.get_patience_factor(10), expected_factor)

    def test_get_patience_factor_when_zero_waiting_time(self):
        self.assertEqual(self.calm.get_patience_factor(0), 2)

class TestRepr(TestCalm):
    def test_repr(self):
        self.assertEqual(repr(self.calm), "Calm")


